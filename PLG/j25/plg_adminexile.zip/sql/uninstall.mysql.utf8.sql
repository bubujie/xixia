DROP TABLE IF EXISTS `#__plg_system_adminexile`;
DROP TABLE IF EXISTS `#__plg_system_adminexile_tmpwhitelist`;