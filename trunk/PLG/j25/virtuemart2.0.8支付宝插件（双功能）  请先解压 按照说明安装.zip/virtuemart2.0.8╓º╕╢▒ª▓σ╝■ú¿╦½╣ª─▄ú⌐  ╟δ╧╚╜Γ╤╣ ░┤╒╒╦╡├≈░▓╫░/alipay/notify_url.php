<?php
/**
 *
 * a special type of 'alipay ':
 *
 * @author sam chen
 * @author apexera company
 * @version v1.0
 * @package VirtueMart
 * @subpackage payment
 * @copyright Copyright (C) 2004-2008 soeren - All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.org
 */
$current_path = dirname(__FILE__).'/../../../path.php';
require_once($current_path);
$config_path = dirname(__FILE__).'/../../../administrator/components/com_virtuemart/helpers/config.php';
require_once($config_path);
        if (!class_exists ('VirtueMartModelOrders')) {
			require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
		}
		if (!class_exists ('AlipayNotify')) {
		require (JPATH_ROOT . DS . 'plugins' . DS . 'vmpayment' . DS . 'alipay' . DS . 'alipay' . DS. 'alipay_notify.class.php');
	    }
		$slipay_data = JRequest::get ('post');
		if (!isset($slipay_data['out_trade_no'])) {
			  echo "fail";
		}
		$order_number = $slipay_data['out_trade_no'];
		if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($slipay_data['out_trade_no']))) {
			  echo "fail";
		}
        
		$q = 'SELECT `payment_params` FROM `#__virtuemart_paymentmethods` WHERE `payment_element`="alipay" ';
		$db = JFactory::getDBO ();
		$db->setQuery ($q);
		$result = $db->loadResult ();
		$temp_array = explode("|",$result);
		$method = array();
		for($i=0;$i < count($temp_array);$i++)
		{
			if(strlen($temp_array[$i]) > 0)
			{
				$item = array();
				$item = explode("=",$temp_array[$i]);
				$key = $item[0];
				$value = substr($item[1],1,strlen($item[1])-2);
				$method[$key] = $value;
			}
		
		}
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//合作身份者id，以2088开头的16位纯数字
$aliapy_config['partner']      = $method['partner'];

//安全检验码，以数字和字母组成的32位字符
$aliapy_config['key']          = $method['key'];

//签约支付宝账号或卖家支付宝帐户
$aliapy_config['seller_email'] = $method['seller_email'];

//页面跳转同步通知页面路径，要用 http://格式的完整路径，不允许加?id=123这类自定义参数
//return_url的域名不能写成http://localhost/create_direct_pay_by_user_php_gb/return_url.php ，否则会导致return_url执行无效
//$aliapy_config['return_url']   = 'http://192.168.202.34'. '/'.'vmpayment/standard/slipay/return_url.php';

//服务器异步通知页面路径，要用 http://格式的完整路径，不允许加?id=123这类自定义参数
$aliapy_config['notify_url']   =   'http://www.example.com/plugins/vmpayment/alipay/notify_url.php';

//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


//签名方式 不需修改
$aliapy_config['sign_type']    = 'MD5';

//字符编码格式 目前支持 gbk 或 utf-8
$aliapy_config['input_charset']= 'utf-8';

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$aliapy_config['transport']    = 'http';
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($aliapy_config);
$verify_result = $alipayNotify->verifyNotify();
$modelOrder = VmModel::getModel ('orders');
$order = array();
/*
Pending P
Confirmed by shopper U
confired C
Cancelled X
Refunded R
Shipped  S
*/
if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	if($slipay_data['trade_status'] == 'WAIT_BUYER_PAY') {
	//该判断表示买家已在支付宝交易管理中产生了交易记录，但没有付款
	
		//判断该笔订单是否在商户网站中已经做过处理（可参考“集成教程”中“3.4返回数据处理”）
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
			if($order['order_status'] != $method['status_pending']){
			$order['customer_notified'] = 1;
			$order['order_status'] = $method['status_pending'];
			$order['comments'] = '等买家付款' ;
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			}
        echo "success";		//请不要修改或删除

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	else if($slipay_data['trade_status'] == 'WAIT_SELLER_SEND_GOODS') {
	//该判断表示买家已在支付宝交易管理中产生了交易记录且付款成功，但卖家没有发货
	
		//判断该笔订单是否在商户网站中已经做过处理（可参考“集成教程”中“3.4返回数据处理”）
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
			if($order['order_status'] != $method['status_success']){
			$order['customer_notified'] = 1;
			$order['order_status'] = $method['status_success'];
			$order['comments'] = '买家已付款，等卖家发货' ;
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			}
        echo "success";		//请不要修改或删除

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	else if($slipay_data['trade_status'] == 'WAIT_BUYER_CONFIRM_GOODS') {
	//该判断表示卖家已经发了货，但买家还没有做确认收货的操作
	
		//判断该笔订单是否在商户网站中已经做过处理（可参考“集成教程”中“3.4返回数据处理”）
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
		if($order['order_status'] != 'S'){
			$order['customer_notified'] = 1;
			$order['order_status'] = 'S';
			$order['comments'] = '卖家已发货，等买家签收' ;
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			}
        echo "success";		//请不要修改或删除

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	else if($slipay_data['trade_status'] == 'TRADE_FINISHED') {
	//该判断表示买家已经确认收货，这笔交易完成
	
		//判断该笔订单是否在商户网站中已经做过处理（可参考“集成教程”中“3.4返回数据处理”）
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
			if($order['order_status'] != 'U'){
			$order['customer_notified'] = 1;
			$order['order_status'] = 'U';
			$order['comments'] = '交易成功' ;
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			}
        echo "success";		//请不要修改或删除

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	else if($slipay_data['trade_status'] == 'REFUND_SUCCESS') {
	//该判断退款是否成功
	
		
			if($order['order_status'] != 'R'){
			$order['customer_notified'] = 1;
			$order['order_status'] = 'R';
			$order['comments'] = '退款成功' ;
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
			}
        echo "success";		//请不要修改或删除

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
    else {
		//其他状态判断
        echo "success";

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult ("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	
	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
$order['customer_notified'] = 0;
			$order['order_status'] = $method['status_canceled'];
			$order['comments'] = '验证信息不一致 ';
			/** @var $modelOrder array() */
			$modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
    //验证失败
    echo "fail";

    //调试用，写文本函数记录程序运行情况是否正常
    //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
}
 
 

 


		
?>