var t3lang = "en";
var langObj = {
   "en": {
      "Block infomation": "Block information",
      "Blank positions": "Blank positions",
      "All blocks": "All blocks",
      "Content": "Content",
      "ON": "ON",
      "OFF": "OFF"
   },
   "es": {
      "Block infomation": "adf  dsfsdfsdfsdfsd",
      "Blank positions": "Bsdf dfs sdf s",
      "All blocks": "Alsdf sdfl blocks",
      "Content": "Cofsd dfntent",
      "ON": "ON",
      "OFF": "OFF"
   }
}