<?php
/**
 * @copyright	Copyright (C) 2012 Daniel Calviño Sánchez
 * @license		GNU Affero General Public License version 3 or later; see LICENSE.txt
 */

require_once dirname(dirname(dirname(__FILE__))).'/SeleniumJoomlaTestCase.php';

class SimpleCustomRouterTest extends SeleniumJoomlaTestCase {

    public function setUp() {
        parent::setUp();

        $output = file_get_contents($this->baseUrl().'tests/system/backupRestore.php?action=backup');
        if ($output != 'Backup done') {
            echo 'Configuration or database backup failed!', PHP_EOL;
            die();
        }

        echo 'Configuration and database backup done', PHP_EOL;
    }

    public function tearDown() {
        $output = file_get_contents($this->baseUrl().'tests/system/backupRestore.php?action=restore');
        if ($output != 'Restored') {
            echo 'Restore configuration or database failed!', PHP_EOL;
            die();
        }

        echo 'Configuration and database restored', PHP_EOL;
        
        parent::tearDown();
    }
    
    public function testParsingAddingAndRemovingRoute() {
        echo 'Ensure that cache is disabled', PHP_EOL;
        $this->gotoAdmin();
        $this->doAdminLogin();
        $this->setCache('off');
        $this->setSimpleCustomRouterCache('off', 'off');
        
        echo 'Add dummy article for the menu item', PHP_EOL;
        $this->addArticle('Dummy article for the menu item', 'Dummy article for the menu item text');
        
        echo 'Add menu item to be assigned in the route', PHP_EOL;
        $this->addMenuItemForArticle('Simple custom router test menu item', 'Dummy article for the menu item');
        $itemId = $this->getMenuItemIdByTitle('Simple custom router test menu item');
        
        echo 'Ensure that there is no page with the path that will be added', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 before adding route');
        
        echo 'Add article for the route', PHP_EOL;
        $this->gotoAdmin();
        $this->addArticle('Simple custom router test', 'Simple custom router test text');
        $id = $this->getArticleIdByTitle('Simple custom router test');
        
        echo 'Add route', PHP_EOL;
        $this->goToSimpleCustomRouterComponent();
        $this->clickToolbar('New');
        $this->setRouterData('simpleCustomRouterTest', 'option=com_content&view=article&id='.$id);
        $this->clickToolbar('Save & Close');
        
        echo 'Check path again after adding route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after adding route');
        //As no item id was assigned, the title will be the site title
        $this->assertTitle($this->cfg->site_name, 'Page title after adding route');
        
        echo 'Edit route to set the Itemid', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->selectRouteByPath('simpleCustomRouterTest');
        $this->clickToolbar('Edit');
        $this->setRouterData('simpleCustomRouterTest', 'option=com_content&view=article&id='.$id, $itemId);
        $this->clickToolbar('Save & Close');
        
        echo 'Check path again after editing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after editing route');
        //As the item id assigned belongs to a menu item article, the page title
        //will be set to the article being shown (not the one assigned to the
        //menu item).
        $this->assertTitle('Simple custom router test', 'Page title after editing route');
        
        echo 'Remove route', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->selectRouteByPath('simpleCustomRouterTest');
        $this->clickToolbar('Delete');
        
        echo 'Check path again after removing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 after removing route');
        
        echo 'Ensure article is available', PHP_EOL;
        $this->open($this->baseUrl().'index.php?option=com_content&view=article&id='.$id);
        $this->assertTextPresent('Simple custom router test text', 'Article text after adding route');
    }
    
    public function testParsingAddingAndRemovingRouteWithCache() {
        //Use plugin cache instead of global cache to ensure that there are no
        //problems due to other components cache (for example, the title in
        //article pages is cached when the page is first shown, and it won't
        //change even if the page is loaded with another Itemid).
        echo 'Ensure that cache is enabled', PHP_EOL;
        $this->gotoAdmin();
        $this->doAdminLogin();
        $this->setCache('off');
        $this->setSimpleCustomRouterCache('on', 'on');
        
        echo 'Add dummy article for the menu item', PHP_EOL;
        $this->addArticle('Dummy article for the menu item', 'Dummy article for the menu item text');
        
        echo 'Add menu item to be assigned in the route', PHP_EOL;
        $this->addMenuItemForArticle('Simple custom router test menu item', 'Dummy article for the menu item');
        $itemId = $this->getMenuItemIdByTitle('Simple custom router test menu item');
        
        echo 'Ensure that there is no page with the path that will be added', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 before adding route');
        
        echo 'Add article for the route', PHP_EOL;
        $this->gotoAdmin();
        $this->addArticle('Simple custom router test', 'Simple custom router test text');
        $id = $this->getArticleIdByTitle('Simple custom router test');
        
        echo 'Add route', PHP_EOL;
        $this->goToSimpleCustomRouterComponent();
        $this->clickToolbar('New');
        $this->setRouterData('simpleCustomRouterTest', 'option=com_content&view=article&id='.$id);
        $this->clickToolbar('Save & Close');
        
        //This will add the path to the cache
        echo 'Check path again after adding route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after adding route');
        //As no item id was assigned, the title will be the site title
        $this->assertTitle($this->cfg->site_name, 'Page title after adding route');

        //This should use the cache
        echo 'Check path again after adding route (cache)', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after adding route (cache)');
        $this->assertTitle($this->cfg->site_name, 'Page title after adding route (cache)');
        
        //This should clean the cache
        echo 'Edit route to set the Itemid', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->selectRouteByPath('simpleCustomRouterTest');
        $this->clickToolbar('Edit');
        $this->setRouterData('simpleCustomRouterTest', 'option=com_content&view=article&id='.$id, $itemId);
        $this->clickToolbar('Save & Close');
        
        //This will add the path to the cache again
        echo 'Check path again after editing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after editing route');
        //As the item id assigned belongs to a menu item article, the page title
        //will be set to the article being shown (not the one assigned to the
        //menu item).
        $this->assertTitle('Simple custom router test', 'Page title after editing route');

        //This should use the cache
        echo 'Check path again after editing route (cache)', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTextPresent('Simple custom router test text', 'Article text after editing route (cache)');
        $this->assertTitle('Simple custom router test', 'Page title after editing route (cache)');
        
        //This should clean the cache
        echo 'Edit route path', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->selectRouteByPath('simpleCustomRouterTest');
        $this->clickToolbar('Edit');
        $this->setRouterData('simpleCustomRouterTestNew', 'option=com_content&view=article&id='.$id, $itemId);
        $this->clickToolbar('Save & Close');
        
        //The old path should have been removed from cache
        echo 'Check old path again after editing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 for old path after editing route');

        //This will add the new path to the cache
        echo 'Check new path after editing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTestNew');
        $this->assertTextPresent('Simple custom router test text', 'Article text for new path after editing route');
        //As the item id assigned belongs to a menu item article, the page title
        //will be set to the article being shown (not the one assigned to the
        //menu item).
        $this->assertTitle('Simple custom router test', 'Page title for new path after editing route');

        //This should use the cache
        echo 'Check new path after editing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTestNew');
        $this->assertTextPresent('Simple custom router test text', 'Article text for new path after editing route (cache)');
        $this->assertTitle('Simple custom router test', 'Page title for new path after editing route (cache)');
        
        //This should clean the cache
        echo 'Remove route', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->selectRouteByPath('simpleCustomRouterTestNew');
        $this->clickToolbar('Delete');
        
        //The new path should have been removed from cache
        echo 'Check new path again after removing route', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTestNew');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 for new path after removing route');
        
        echo 'Ensure article is available', PHP_EOL;
        $this->open($this->baseUrl().'index.php?option=com_content&view=article&id='.$id);
        $this->assertTextPresent('Simple custom router test text', 'Article text after removing route');
    }
    
    public function testTestRoute() {
        echo 'Ensure that cache is disabled', PHP_EOL;
        $this->gotoAdmin();
        $this->doAdminLogin();
        $this->setCache('off');
        $this->setSimpleCustomRouterCache('off', 'off');
        
        echo 'Ensure that there is no page with the paths that will be added', PHP_EOL;
        $this->open($this->baseUrl().'simpleCustomRouterTest-42');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 before adding route');
        $this->open($this->baseUrl().'simpleCustomRouterTestNew');
        $this->assertTrue(strpos($this->getTitle(), '404') === 0, 'Error 404 before adding route');
        
        echo 'Test route not added', PHP_EOL;
        $this->gotoAdmin();
        $this->goToSimpleCustomRouterComponent();
        $this->clickToolbar('Test routes');
        $this->testParse('simpleCustomRouterTest-42');
        $this->assertEquals('', $this->getText('id=generated-query'), 'Generated query for route not added');
        $this->testBuild('option=com_content&view=article&id=42');
        $this->assertEquals('', $this->getText('id=generated-path'), 'Generated path for route not added');
        $this->clickToolbar('Close');
        
        echo 'Add first route', PHP_EOL;
        $this->clickToolbar('New');
        $this->setRouterData('simpleCustomRouterTest-(\d+)', 'option=com_content&view=article&id={1}');
        $this->clickToolbar('Save & Close');
        
        echo 'Test after adding first route', PHP_EOL;
        $this->clickToolbar('Test routes');
        $this->testParse('simpleCustomRouterTest-42');
        $this->assertEquals('option=com_content&view=article&id=42', $this->getText('id=generated-query'), 'Generated query after adding first route');
        $this->testBuild('option=com_content&view=article&id=42');
        $this->assertEquals('simpleCustomRouterTest-42', $this->getText('id=generated-path'), 'Generated path after adding first route');
        $this->clickToolbar('Close');

        //The second route will override the first when building with id=42
        echo 'Add second route', PHP_EOL;
        $this->clickToolbar('New');
        $this->setRouterData('simpleCustomRouterTestNew', 'option=com_content&view=article&id=42');
        $this->clickToolbar('Save & Close');
        
        echo 'Test after adding second route', PHP_EOL;
        $this->clickToolbar('Test routes');
        $this->testParse('simpleCustomRouterTestNew');
        $this->assertEquals('option=com_content&view=article&id=42', $this->getText('id=generated-query'), 'Generated query for second route after adding second route');
        $this->testParse('simpleCustomRouterTest-42');
        $this->assertEquals('option=com_content&view=article&id=42', $this->getText('id=generated-query'), 'Generated query for first route after adding second route');
        //Check that the second route overrides the first
        $this->testBuild('option=com_content&view=article&id=42');
        $this->assertEquals('simpleCustomRouterTestNew', $this->getText('id=generated-path'), 'Generated path for second route after adding second route');
        //Check that the first route is still working
        $this->testBuild('option=com_content&view=article&id=108');
        $this->assertEquals('simpleCustomRouterTest-108', $this->getText('id=generated-path'), 'Generated path for first route after adding second route');
        $this->clickToolbar('Close');
    }
    
    //TODO How to test building routes?
    
    private function baseUrl() {
        $configuration = new SeleniumConfig();
        return $configuration->host . $configuration->path;
    }
    
    private function setSimpleCustomRouterCache($overrideGlobalCache, $enableCache) {
        $this->click('link=Plug-in Manager');
        $this->waitForPageToLoad('30000');
        $this->type('filter_search', 'Simple Custom Router');
        $this->click('//button[@type="submit"]');
        $this->waitForPageToLoad('30000');
        $this->click('//table[@class="adminlist"]/tbody//tr/td[position() = 2]//a');
        $this->waitForPageToLoad('30000');
        
        if ($overrideGlobalCache == 'on') {
            $this->click('jform_params_overrideDefaultConfiguration1');
        } else {
            $this->click('jform_params_overrideDefaultConfiguration0');
        }
        
        if ($enableCache == 'on') {
            $this->click('jform_params_enableCache1');
        } else {
            $this->click('jform_params_enableCache0');
        }
        
        $this->clickToolbar('Save & Close');
    }
    
    private function addArticle($title, $text) {
        $this->click('link=Add New Article');
        $this->waitForPageToLoad('30000');
        $this->type('jform_title', $title);
        $this->click('link=Toggle editor');
        $this->type('jform_articletext', $text);
        $this->clickToolbar('Save & Close');
    }
    
    private function clickToolbar($action) {
        $this->click('//div[@id="toolbar"]//li/a/text()[normalize-space() = "'.$action.'"]/../span');
        $this->waitForPageToLoad('30000');
    }
    
    private function getArticleIdByTitle($title) {
        $this->type('filter_search', $title);
        $this->click('//button[@type="submit"]');
        $this->waitForPageToLoad('30000');
        return $this->getText('//table[@class="adminlist"]/tbody//tr/td[position() = 12]');
    }
    
    private function addMenuItemForArticle($title, $articleTitle) {
        $this->click('link=Main Menu');
        $this->waitForPageToLoad('30000');
        $this->clickToolbar('New');
        
        //Select the menu item type
        $this->click('//input[@value="Select"]');
        $this->waitforElement('//div[contains(@id, "sbox-content")]');
        $this->click('link=Single Article');
        $this->waitForPageToLoad('30000');
        
        //Set menu item title
        $this->type('jform_title', $title);
        
        //Set article for the menu item
        $this->click('link=Select / Change');
        $this->waitforElement('//iframe[contains(@src, "jSelectArticle")]');
        if ($this->getSelectedLabel('limit') != 'All') {
            $this->select('limit', 'All');
            $this->waitForPageToLoad('30000');
        }
        $this->click('link='.$articleTitle);

        $this->clickToolbar('Save & Close');
    }
    
    private function getMenuItemIdByTitle($title) {
        $this->type('filter_search', $title);
        $this->click('//button[@type="submit"]');
        $this->waitForPageToLoad('30000');
        return $this->getText('//table[@class="adminlist"]/tbody//tr/td[position() = 9]');
    }
    
    private function goToSimpleCustomRouterComponent() {
        $this->click('link=Simple Custom Router');
        $this->waitForPageToLoad('30000');
    }
    
    private function setRouterData($path, $query, $itemId = '') {
        $this->type('jform_path', $path);
        $this->type('jform_query', $query);
        $this->select('jform_itemId', 'value='.$itemId);
    }
    
    private function selectRouteByPath($path) {
        if ($this->getSelectedLabel('limit') != 'All') {
            $this->select('limit', 'All');
            $this->waitForPageToLoad('30000');
        }
        $this->click('//table[@class="adminlist"]/tbody//tr/td/a[normalize-space(text()) = "'.$path.'"]/../../td[position() = 2]/input');
    }
    
    private function testParse($path) {
        $this->type('path', $path);
        $this->click('//form[@id="test-path-form"]//input[@type="submit"]');
        $this->waitForPageToLoad('30000');
    }
    
    private function testBuild($query) {
        $this->type('query', $query);
        $this->click('//form[@id="test-query-form"]//input[@type="submit"]');
        $this->waitForPageToLoad('30000');
    }
}
