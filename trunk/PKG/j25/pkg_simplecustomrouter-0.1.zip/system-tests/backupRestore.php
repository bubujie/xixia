<?php
/**
 * @copyright	Copyright (C) 2012 Daniel Calviño Sánchez
 * @license		GNU Affero General Public License version 3 or later; see LICENSE.txt
 */

// Define expected Joomla constants.
define('_JEXEC', 1);
define('DS', DIRECTORY_SEPARATOR);

define('JPATH_BASE', dirname(dirname(dirname(__FILE__))));

// Include relative constants, JLoader and the jimport and jexit functions.
require_once JPATH_BASE.'/includes/defines.php';
require_once JPATH_LIBRARIES.'/import.php';

//Needed to get the proper configuration file, as "config.php" is used by
//default by JFactory
JFactory::getConfig(JPATH_BASE."/configuration.php");

jimport('joomla.environment.request');

$action = JRequest::getVar('action');

if ($action === 'backup') {
    backup();
} else if ($action === 'restore') {
    restore();
}

function backup() {
    $output = shell_exec('cp -f '.JPATH_BASE.'/configuration.php configuration.php.bak && echo OK');
    if (empty($output)) {
        echo "Configuration backup error";
        return;
    }

    $conf = JFactory::getConfig();

    //Use mysqldump instead of copying and renaming tables as it does not
    //preserve things like foreign keys (at least, not automatically). Even
    //primary keys are not preserved if not copied using
    //"CREATE TABLE ... LIKE" syntax.
    $output = shell_exec('mysqldump -u '.$conf->get('user').' -p'.$conf->get('password').' '.$conf->get('db').' > '.JPATH_BASE.'/tests/system/dump.sql && echo OK');
    if (empty($output)) {
        echo "Database backup error";
        return;
    }

    echo "Backup done";
}

function restore() {
    $output = shell_exec('cp -f configuration.php.bak '.JPATH_BASE.'/configuration.php && echo OK');
    if (empty($output)) {
        echo "Configuration restore error";
        return;
    }

    $conf = JFactory::getConfig();
    
    $output = shell_exec('mysql -u '.$conf->get('user').' -p'.$conf->get('password').' '.$conf->get('db').' < '.JPATH_BASE.'/tests/system/dump.sql && echo OK');
    if (empty($output)) {
        echo "Database restore error";
        return;
    }

    echo "Restored";
}
