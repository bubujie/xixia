<?php
##*HEADER*##

/**
 * ECR_COM_NAME library.
 *
 */
class ECR_COM_NAME
{
}//class
