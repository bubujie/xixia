<?php
##*HEADER*##

/**
 * ECR_ELEMENT_NAME controller
 *
 * @package    ECR_COM_NAME
 * @subpackage Controllers
 */
class ECR_COM_NAMEControllerECR_ELEMENT_NAME extends JControllerLegacy
{
    public function __construct($config = array())
    {
        $foo = 'Do something here..';

        parent::__construct($config);
    }

    public function display()
    {
        $foo = 'Do something here..';

        parent::display();
    }
}
