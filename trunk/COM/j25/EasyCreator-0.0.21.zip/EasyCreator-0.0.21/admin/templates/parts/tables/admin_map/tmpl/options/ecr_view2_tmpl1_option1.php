		<tr>
			<td valign="top" align="right" class="key">
				<?php echo JText::_('Published'); ?>:
			</td>
			<td colspan="2">
				<?php echo $this->lists['published']; ?>
			</td>
		</tr>