<?php
/**
 * CHANGELOG
 *
 * This is the changelog for ECR_COM_NAME.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id$
 * @package    ECR_COM_NAME
 * @subpackage Documentation
 * @author     ECR_AUTHORNAME {@link ECR_AUTHORURL}
 * @author     Created on ECR_ACT_DATE
 */

//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for ECR_COM_NAME

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

 * -> Security Fix
 # -> Bug Fix
 + -> Addition
 ^ -> Change
 - -> Removed
 ! -> Note
______________________________________________

ECR_ACT_DATE ECR_AUTHORNAME
 ! Startup

*/
}//--This is the END
