<?php
##*HEADER*##

/**
 * ECR_ELEMENT_NAME model.
 *
 * @package    ECR_COM_NAME
 * @subpackage Models
 */
class ECR_COM_NAMEModelECR_ELEMENT_NAME extends JModelLegacy
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        // Additional work
        $foo = 'Bar';

        parent::__construct();
    }
}
