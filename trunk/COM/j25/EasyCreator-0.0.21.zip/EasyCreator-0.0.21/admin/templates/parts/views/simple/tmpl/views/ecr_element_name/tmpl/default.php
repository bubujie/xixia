<?php
##*HEADER*##

echo 'default template for ECR_ELEMENT_NAME view';
