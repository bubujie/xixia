<?php
##*HEADER*##

jimport('joomla.application.component.view');

/**
 * ECR_ELEMENT_NAME view.
 *
 * @package    ECR_COM_NAME
 * @subpackage Views
 */
class ECR_COM_NAMEViewECR_ELEMENT_NAME extends JView
{
    /**
     * ECR_COM_NAMEECR_LIST_POSTFIX view display method.
     *
     * @param string $tpl The name of the template file to parse;
     *
     * @return void
     */
    public function display($tpl = null)
    {
        $foo = 'Do something here..';

        parent::display($tpl);
    }//function
}//class
