<?php
##*HEADER*##

jimport('joomla.application.component.model');

/**
 * ECR_ELEMENT_NAME model.
 *
 * @package    ECR_COM_NAME
 * @subpackage Models
 */
class ECR_COM_NAMEModelECR_ELEMENT_NAME extends JModel
{
    /**
     * Constructor.
     */
    public function __construct()
    {
        // Additional work
        $foo = 'Bar';

        parent::__construct();
    }//function
}//class
