        <tr>
            <td width="100" align="right" class="key">
                <label for="lbl__ECR_KEY_">
                    <?php echo JText::_('_ECR_KEY_'); ?> :
                </label>
            </td>
            <td>
                <input type="text" class="text_area" name="_ECR_KEY_" id="lbl__ECR_KEY_"
                 size="32" maxlength="250" value="<?php echo $this->item->_ECR_KEY_; ?>" />
            </td>
        </tr>
