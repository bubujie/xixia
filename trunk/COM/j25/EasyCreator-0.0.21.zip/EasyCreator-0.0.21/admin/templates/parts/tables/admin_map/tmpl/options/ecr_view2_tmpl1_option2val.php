		<tr>
			<td width="100" align="right" class="key">
				<label for="greeting">
					<?php echo JText::_('_ECR_FIELDVALUE_1_'); ?> :
				</label>
			</td>
			<td>
				<input class="text_area" type="_ECR_FIELDVALUE_2_" name="_ECR_FIELDVALUE_1_"
				id="_ECR_FIELDVALUE_1_" size="32" maxlength="250" value="<?php echo $this->item->_ECR_FIELDVALUE_1_;?>" />
			</td>
		</tr>