<?php
##*HEADER*##

$greeting = 'Hello World =;)';

?>
<p>
   <?php echo $greeting; ?>
</p>
