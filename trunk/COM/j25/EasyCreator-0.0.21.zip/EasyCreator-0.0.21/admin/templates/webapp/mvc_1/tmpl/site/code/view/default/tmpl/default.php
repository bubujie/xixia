<?php
##*HEADER*##

?>
<h1>ECR_COM_NAME</h1>
<p>Welcome <tt>=;)</tt> ...</p>
<p class="alert alert-block">Please remember to <a href="index.php?do=install">install the database</a> for the first
    time !</p>

