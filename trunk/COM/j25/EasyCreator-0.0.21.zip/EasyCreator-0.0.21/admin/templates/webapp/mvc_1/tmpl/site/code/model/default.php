<?php
##*HEADER*##
/**
 * ECR_COM_NAME default model.
 *
 * @package     ECR_COM_NAME
 * @subpackage  Model
 */
class ECR_CLASS_PREFIXModelDefault extends JModelBase
{
}
