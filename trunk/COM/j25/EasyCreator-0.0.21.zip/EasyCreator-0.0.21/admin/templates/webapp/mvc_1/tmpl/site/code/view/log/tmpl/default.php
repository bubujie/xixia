<?php
##*HEADER*##

?>
<h1>ECR_COM_NAME Log</h1>

<pre><?= $this->escape($this->log) ?></pre>
