<?php
##*HEADER*##

/**
 * Html default view class.
 */
class ECR_CLASS_PREFIXViewDefaultView extends JViewHtml
{
}
