<?php
##*HEADER*##
/**
 * ECR_COM_NAME default controller.
 *
 * @package     ECR_COM_NAME
 * @subpackage  Controller
 */
class ECR_CLASS_PREFIXControllerDefault extends JControllerBase
{
    /**
     * Execute the controller.
     *
     * @return  boolean  True if controller finished execution, false if the controller did not
     *                   finish execution. A controller might return false if some precondition for
     *                   the controller to run has not been satisfied.
     *
     * @since            12.1
     * @throws  LogicException
     * @throws  RuntimeException
     */
    public function execute()
    {
    }
}
