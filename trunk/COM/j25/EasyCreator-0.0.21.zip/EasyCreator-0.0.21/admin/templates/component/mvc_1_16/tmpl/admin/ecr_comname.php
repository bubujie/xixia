<?php
##*HEADER*##

?>
<h1>I am just a dummy :~|</h1>

<p>
    Please visit the <a href="../index.php?option=ECR_COM_COM_NAME">frontpage view of ECR_COM_NAME</a>.
</p>
