<?php
##*HEADER*##

//-- Import the class JControllerForm
jimport('joomla.application.component.controllerform');

/**
 * ECR_COM_NAME Controller.
 *
 * @package    ECR_COM_NAME
 * @subpackage Controllers
 */
class ECR_COM_NAMEControllerECR_COM_NAME extends JControllerForm
{
    /**
     * !!!
     * If our controller does not follow the standard pluralisation
     * we have to provide the name here
     *
     * @var string
     */
    protected $view_list = 'ECR_COM_NAMEECR_LIST_POSTFIX';
}//class
