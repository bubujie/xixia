<?php
##*HEADER*##

?>
<tr>
  <td colspan="#_ECR_ADMIN_LIST_COLSPAN_#">
  	<?php echo $this->pagination->getListFooter(); ?>
  </td>
</tr>
