<?php
##*HEADER*##

?>
<tr>
	<th width="5">
        <?php echo JText::_('ECR_UPPER_COM_COM_NAME_ECR_UPPER_COM_NAME_HEADING_EDIT'); ?>
	</th>
	<th width="20">
		<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
	</th>
<!--admin.viewlist.table.ECR_COM_TBL_NAME.header-->
</tr>
