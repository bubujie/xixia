<?php defined('_JEXEC') || die('=;)');
/**
 * @package    EasyCreator
 * @subpackage Views
 * @author     Nikolai Plath
 * @author     Created on 30-Sep-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */
?>

<h2><?php echo jgettext('Run a Web application'); ?></h2>

<a href="<?php echo $this->href; ?>" target="_blank">
    <?php echo $this->href; ?>
</a>
