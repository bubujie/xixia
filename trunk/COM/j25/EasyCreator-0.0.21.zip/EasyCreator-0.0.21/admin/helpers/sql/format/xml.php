<?php defined('_JEXEC') || die('=;)');
/**
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     Nikolai Plath
 * @author     Created on 18-Jan-2012
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

/**
 * This is just a dummy file...
 */

$foo = 'bar';
