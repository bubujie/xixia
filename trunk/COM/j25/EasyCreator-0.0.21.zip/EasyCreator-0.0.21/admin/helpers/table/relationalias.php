<?php defined('_JEXEC') || die('=;)');
/**
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     Nikolai Plath
 * @author     Created on 19-Aug-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */


/**
 * EcrTableRelationalias class.
 */
class EcrTableRelationalias
{
    public $alias;

    public $aliasField;
}//class
