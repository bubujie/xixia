<?php
/**
 * User: elkuku
 * Date: 08.06.12
 * Time: 14:16
 */

/**
 * Release class.
 */
class EcrProjectUpdateserverRelease
{
    public $state = 'release';

    public $description = '';

    public $downloads = array();
}
