<?php
/**
 * User: elkuku
 * Date: 07.06.12
 * Time: 13:08
 */

/**
 * Feed item class.
 */
class EcrProjectFeedItem
{
    public $title = '';

    public $link = '';

    public $summary = '';

    public $description;

    public $content = '';

    public $updated = '';

    public $id = '';

    public $author = '';
}
