This directory holds the project sunchronization information files.
