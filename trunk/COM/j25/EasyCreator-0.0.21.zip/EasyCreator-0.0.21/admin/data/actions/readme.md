You may add your custom actions inside this folder

Documentation: @todo
