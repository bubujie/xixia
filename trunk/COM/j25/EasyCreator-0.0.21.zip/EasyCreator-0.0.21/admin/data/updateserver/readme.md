## Updateserver
This directory contains the update server files.

You may adjust the ```template.html``` and the ```template_extension.html``` file to suite your needs.

The following elements will be replaced :

```
<div id="ECR_EXTENSION_LIST"/>

ECR_CHANNEL_TITLE
ECR_CHANNEL_URL

ECR_EXTENSION_TITLE
ECR_EXTENSION_NAME

ECR_RELEASE_URL
ECR_DEVELOPMENT_URL
```
