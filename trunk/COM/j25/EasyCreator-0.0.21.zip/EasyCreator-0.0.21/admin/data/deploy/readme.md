This directory contains the deploy credentials and information about your project.
