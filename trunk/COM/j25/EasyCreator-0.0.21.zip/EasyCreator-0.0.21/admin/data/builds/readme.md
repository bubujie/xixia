This directory contains the built project package files.
