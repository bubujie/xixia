This directory contains the log files.
