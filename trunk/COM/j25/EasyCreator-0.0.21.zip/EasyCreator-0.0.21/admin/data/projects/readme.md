This directory contains the project configuration files.
