This directory contains the exported project template files.
