
		JSubMenuHelper::addEntry(
			JText::_('##Firstname##'),
			'index.php?option=com_##component##&view=##firstname##',
			($vName == '##firstname##')
		);
