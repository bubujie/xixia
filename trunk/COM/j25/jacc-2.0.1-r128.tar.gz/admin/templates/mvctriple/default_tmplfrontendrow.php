	<div>
		##Field##: ##codestart## echo $this->item->##field##; ##codeend##
	</div>
