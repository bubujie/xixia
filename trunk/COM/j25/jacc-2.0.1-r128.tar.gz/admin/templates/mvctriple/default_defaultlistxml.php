<<?php echo '?'?>xml version="1.0" encoding="utf-8"##codeend##
<metadata>
	<layout title="##Name##list">
		<help
			key = "##Name##LIST_DESC"
		/>
		<message>
			<![CDATA[##Name##LIST_DESC]]>
		</message>
	</layout>
	<state>
	<name>##Name## List Layout</name>
		<description>##Name## List Layout_DESC</description>	
		<params>
		</params>
	</state>
	<!-- Add fields to the parameters object for the layout. -->
	<fields name="params">
	</fields>
</metadata>