##codestart##xml version="1.0" encoding="utf-8"##codeend##
<metadata>
	<view title="##Name##">
		<message><![CDATA[##Name##]]></message>
	</view>
</metadata>