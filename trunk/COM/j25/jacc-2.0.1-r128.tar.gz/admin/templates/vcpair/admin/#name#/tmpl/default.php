<?php

// no direct access
defined('_JEXEC') or die('Restricted access');
?>
<div class="contentpane">
	<div><h4>Some interesting informations</h4></div>
	##Name##
</div>
