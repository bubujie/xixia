DROP TABLE IF EXISTS #__jacc;
DROP TABLE IF EXISTS #__jacc_modules;
DROP TABLE IF EXISTS #__jacc_plugins;
DROP TABLE IF EXISTS #__jacc_packages;
DROP TABLE IF EXISTS #__jacc_templates;
