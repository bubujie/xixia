<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plg##Plugtype####Plugin## extends JPlugin
{
	
    //Just an example
    
    /**
    public function on##Plugtype##BeforeSave($item, $one, $two)
	{
		$app = JFactory::getApplication();
	    //do something
	    		
	}
	
	**/
    
}