<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plg##Plugtype####Plugin## extends JPlugin
{
	
    //Just an example
    
    /**
	function onUserAuthenticate($credentials, $options, &$response)
	{
	}
	
	**/
    
}