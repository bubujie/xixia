<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.plugin.plugin');

class plg##Plugtype####Plugin## extends JPlugin
{
	
    //Just examples
    
    /**

    public function onAfterInitialise()
    {
        //Do something 
    }
    public function onAfterRoute()
    {
        //Do something 
    }
    
    public function onAfterDispatch()
    {
        //Do something         
    }

    public function onAfterRender()
    {
        //Do something         
    }	
    
    public function onUserLoginFailure($response) {
    	print $response['error_message'];
    	print $response['status'];
    	print $response['username'];
    	print $response['type'];
    }
    
	public function onUserLogout($user, $options = array())
	{
	  //Do something   
		return true;
	}    
	**/
    
}