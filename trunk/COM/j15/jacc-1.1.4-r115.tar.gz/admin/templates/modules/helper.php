<?php
/**
 * @version		$Id: helper.php 96 2011-08-11 06:59:32Z michel $
 * @copyright	Copyright (C) ##year## Open Source Matters, Inc. All rights reserved.
 * @license		##license##
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class mod##Module##Helper
{
    static public function getItem($params) {
        $css_class = $params->get('classname');
        return "";
    }
}