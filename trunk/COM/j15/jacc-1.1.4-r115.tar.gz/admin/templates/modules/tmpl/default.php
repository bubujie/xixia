<?php defined('_JEXEC') or die('Restricted access'); ?>
<div class="##module##<?php echo $params->get( 'moduleclass_sfx' ) ?>">
	Add some Content here
</div>