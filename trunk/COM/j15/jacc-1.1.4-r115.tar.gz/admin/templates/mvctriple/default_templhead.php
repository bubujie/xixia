<?php defined('_JEXEC') or die('Restricted access'); ?>
				<th class="title">
					##codestart## echo JHTML::_('grid.sort', '##Field##', 'a.##field##', $this->lists['order_Dir'], $this->lists['order'] ); ##codeend##
				</th>				