DROP TABLE IF EXISTS `#__contactmap_marqueurs`;
