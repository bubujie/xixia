/***************************************************************|
| If you have a license key, paste it between the quotes below. |
| To obtain a new license key, please visit                     |
| http://randomous.com/floatbox/register                        |
|***************************************************************/
fb.licenseKey = "f65ThbwSc6Ak";