<?php
    /*
    * ContactMap Component Google Map for Joomla! 1.5.x
    * Version 3.7
    * Creation date: Septembre 2010
    * Author: Fabrice4821 - www.gmapfp.org
    * Author email: webmaster@gmapfp.org
    * License GNU/GPL
    */

defined('_JEXEC') or die('Restricted access');

print_r($this->params);
print_r('<br />___________________________________________________________________________________<br />');
print_r($this->rows);
die;
