<?php
##*HEADER*##

?>

<?php foreach($this->greetings as $greeting) : ?>

<h1><?php echo $greeting->greeting; ?></h1>

<?php endforeach;