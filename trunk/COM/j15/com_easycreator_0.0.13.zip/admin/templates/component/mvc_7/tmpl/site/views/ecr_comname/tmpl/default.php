<?php
##*HEADER*##

?>
<h1><?php echo $this->data->greeting; ?></h1>

<?php echo $this->data->content; ?>

<br />
<br />
<a href="<?php echo $this->editlink; ?>">Edit</a>