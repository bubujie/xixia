<?php
##*HEADER*##

?>

<h1><?php echo $this->greeting_model; ?></h1>
<h1><?php echo $this->greeting_view; ?></h1>
