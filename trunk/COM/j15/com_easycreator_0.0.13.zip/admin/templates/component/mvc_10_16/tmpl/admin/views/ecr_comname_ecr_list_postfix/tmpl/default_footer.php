<?php
##*HEADER*##

?>
<tr>
	<td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>
