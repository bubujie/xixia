<?php
##*HEADER*##

// import Joomla controller library
jimport('joomla.application.component.controller');


/**
 * // inherit the JController class
 *
 * @package _ECR_COM_NAME_
 */
class _ECR_COM_NAME_Controller extends JController
{

}//class
