<?php
##*HEADER*##

//-- Import Joomla controllerform library
jimport('joomla.application.component.controllerform');

/**
 * _ECR_COM_NAME_ item Controller
 *
 * @package _ECR_COM_NAME_
 */
class _ECR_COM_NAME_Controller_ECR_COM_NAME_ extends JControllerForm
{
    protected $view_list = '_ECR_COM_NAME__ECR_LIST_POSTFIX_';

    /**
     * Constructor.
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }//function

}//class
