<?php
##*HEADER*##

//-- Import the Joomla! view library
jimport('joomla.application.component.view');

/**
 *
 *
 * @package _ECR_COM_NAME_
 */
class _ECR_COM_NAME_View_ECR_COM_NAME_ extends JView
{
    /**
     * The item
     *
     * @var object
     */
    protected $item = null;

    /**
     * The category.
     *
     * @var object
     */
    protected $category = null;


    /**
     * HTML View class for the _ECR_COM_NAME_ Component
     *
     * @param $tpl
     */
    public function display($tpl = null)
    {
        //-- Get the record
        $this->item = $this->get('Item');

        //-- Get the category
        $this->category = $this->get('Category');

        //-- Display the view
        parent::display($tpl);
    }//function

}//class
