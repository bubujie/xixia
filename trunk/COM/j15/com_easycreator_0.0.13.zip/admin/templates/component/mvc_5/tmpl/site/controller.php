<?php
##*HEADER*##

jimport('joomla.application.component.controller');

/**
 * _ECR_COM_NAME_ default Controller
 *
 * @package    _ECR_COM_NAME_
 * @subpackage Controllers
 */
class _ECR_COM_NAME_Controller extends JController
{
    /**
     * Method to display the view
     *
     * @access	public
     */
    function display()
    {
        parent::display();
    }//function

}//class
