window.addEvent('domready', function() {
	new Sortables($('mySortablesDemo'));
});
