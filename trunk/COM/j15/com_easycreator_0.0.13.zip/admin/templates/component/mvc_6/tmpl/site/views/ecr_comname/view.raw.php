<?php
##*HEADER*##

jimport( 'joomla.application.component.view');

/**
 * HTML View class for the _ECR_COM_NAME_ Component
 *
 * @package    _ECR_COM_NAME_
 * @subpackage Views
 */
class _ECR_COM_NAME_View_ECR_COM_NAME_ extends JView
{
    /**
     * _ECR_COM_NAME_ view display method
     * @return void
     **/
    function display($tpl = null)
    {
        $random = $this->get('random');
        $this->assignRef('random', $random);

        $this->setLayout('raw');

        parent::display($tpl);
    }//function

}//class
