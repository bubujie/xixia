<?php
##*HEADER*##

?>

<h1><?php echo $this->greeting; ?></h1>
