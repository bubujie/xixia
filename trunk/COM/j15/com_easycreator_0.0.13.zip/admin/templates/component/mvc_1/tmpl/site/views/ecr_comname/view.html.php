<?php
##*HEADER*##

jimport('joomla.application.component.view');

/**
 * HTML View class for the _ECR_COM_NAME_ Component
 *
 * @package    _ECR_COM_NAME_
 */
class _ECR_COM_NAME_View_ECR_COM_NAME_ extends JView
{
    function display($tpl = null)
    {
        $greeting = "Hello World!";
        $this->assignRef('greeting', $greeting);

        parent::display($tpl);
    }//function

}//class
