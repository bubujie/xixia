<?php
##*HEADER*##

foreach($this->data as $data) :
?>

<h1><?php echo $data->greeting; ?></h1>

<?php
endforeach;