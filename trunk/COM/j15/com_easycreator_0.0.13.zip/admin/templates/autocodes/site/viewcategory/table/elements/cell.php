<?php
/**
 * @version $Id: cell.php 1142 2010-03-28 04:34:10Z elkuku $
 * @package		EasyCreator
 * @subpackage	AutoCodes
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author		Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeSiteViewCategoryTableElementCell
{
    /**
     * Gets the HTML code.
     *
     * @param EasyTableField $field
     *
     * @return string HTML
     */
    public function getCode(EasyTable $table, $indent = '')
    {
        $ret = '';

        foreach ($table->getFields() as $field)
        {
            if( ! $field->display)
            {
                continue;
            }

            $ret .= $indent.'<td>'.NL;
            $ret .= $indent.'    <?php echo $item->'.$field->name.' ; ?>'.NL;
            $ret .= $indent.'</td>'.NL;
        }//foreach

        return $ret;
    }//function

}//class
