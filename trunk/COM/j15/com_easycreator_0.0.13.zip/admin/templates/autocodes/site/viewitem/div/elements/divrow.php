<?php
/**
 * @version $Id: divrow.php 1142 2010-03-28 04:34:10Z elkuku $
 * @package		EasyCreator
 * @subpackage	AutoCodes
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author		Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeSiteViewitemDivElementDivrow
{
    /**
     * Gets the HTML code.
     *
     * @param EasyTableField $field
     *
     * @return string HTML
     */
    public function getCode(EasyTable $table, $indent = '')
    {
        $ret = '';

        foreach ($table->getFields() as $field)
        {
            if( ! $field->display)
            {
                continue;
            }

            $ret .= $indent.'<div class="title">'.$field->label.'</div>'.NL;
            $ret .= $indent.'<div class="cell"><?php echo $row->'.$field->name.'; ?></div>'.NL;
        }//foreach

        return $ret;
    }//function

}//class
