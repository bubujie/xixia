<?php
/**
 * @version $Id: autocode.php 1156 2010-04-08 02:20:23Z elkuku $
 * @package    EasyCreator
 * @subpackage AutoCodes
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminSqlInsert extends EasyAutoCode
{
    protected $tags = array('start' => '#', 'end' => '#');

    protected $enclose = false;

    private $indent = '  ';

    /**
     * Constructor.
     *
     * @param string $group
     * @param string $name
     * @param string $element
     * @param string $scope
     */
    public function __construct($scope, $group, $name, $element)
    {
        parent::__construct($scope, $group, $name, $element);
    }//function

    public function getCode($type, EasyTable $table)
    {
        $element = $this->getElement($type, dirname(__FILE__));

        if( ! $element)
        {
            return false;
        }

        return $element->getCode($table, $this->indent);
    }//function

}//class
