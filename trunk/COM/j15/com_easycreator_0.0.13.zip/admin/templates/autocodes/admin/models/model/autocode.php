<?php
/**
 * @version SVN: $Id: autocode.php 1155 2010-04-04 20:51:17Z elkuku $
 * @package    EasyCreator
 * @subpackage	AutoCodes
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 22-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminModelsModel extends EasyAutoCode
{
    protected $tags = array('start' => '/*', 'end' => '*/');

    protected $enclose = true;

    private $indent = '        ';

    /**
     * Constructor.
     *
     * @param string $group
     * @param string $name
     * @param string $element
     * @param string $scope
     */
    public function __construct($scope, $group, $name, $element)
    {
        parent::__construct($scope, $group, $name, $element);
    }//function

    public function getCode($type, EasyTable $table)
    {
        $element = $this->getElement($type, dirname(__FILE__));

        if( ! $element)
        {
            return false;
        }

        return $element->getCode($table, $this->indent);
    }//function

}//class
