<?php
/**
 * @version SVN: $Id: buildquery.php 1155 2010-04-04 20:51:17Z elkuku $
 * @package
 * @subpackage
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath {@link http://www.nik-it.de}
 * @author		Created on 22.03.2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminModelsModelElementBuildquery
{
    public function getCode(EasyTable $table, $indent = '')
    {
        $ret = '';
        $fields = array();
        $aliases = '';
        $relations = '';
        $fields = '';
        $charCode = 98;// b

        foreach ($table->getFields() as $field)
        {
            if( ! $field->display)
            {
                continue;
            }

            $fields[] = 'a.'.$field->name;
        }//foreach

        $fields = implode(', ', $fields);

        if(count($table->getRelations()))
        {
            foreach ($table->getRelations() as $relation)
            {
                $relations .= $indent.".' ".$relation->type.' #__'.$relation->onTable
                .' AS '.chr($charCode).' ON '.chr($charCode).'.'.$relation->onField.' = a.'.$relation->field."'";

                if(count($relation->aliases))
                {
                    foreach ($relation->aliases as $alias)
                    {
                        $aliases .= ', '.chr($charCode).'.'.$alias->aliasField.' AS '.$alias->alias;
                    }//foreach
                }

                $charCode ++;
            }//foreach

            $relations .= NL;
        }

        $ret .= $indent.'$query = \' SELECT '.$fields.$aliases."'".NL
        .$indent.'.\' FROM #__'.$table->name.' AS a \''.NL
        .$relations.';';

        $ret .= NL;

        return $ret;
    }//function

}//class
