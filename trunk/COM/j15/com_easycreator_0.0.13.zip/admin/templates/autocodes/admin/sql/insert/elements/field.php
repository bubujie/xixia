<?php
/**
 * @version $Id: field.php 1130 2010-03-23 15:04:01Z elkuku $
 * @package    EasyCreator
 * @subpackage AutoCodes
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminSqlInsertElementField
{
    /**
     * Gets the HTML code.
     *
     * @param EasyTableField $field
     *
     * @return string HTML
     */
    public function getCode(EasyTable $table, $indent = '')
    {
        $ret = '';

        $started = false;

        foreach ($table->getFields() as $field)
        {
            $ret .=($started) ? $indent.', ' : $indent.'  ';
            $started = true;
            $ret .= EasyTableHelper::formatSqlField($field);
            $ret .= NL;
        }//foreach

        return $ret;
    }//function

}//class
