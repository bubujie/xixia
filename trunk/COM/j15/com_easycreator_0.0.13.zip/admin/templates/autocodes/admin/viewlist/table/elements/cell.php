<?php
/**
 * @version $Id: cell.php 1158 2010-04-09 14:50:25Z elkuku $
 * @package		EasyCreator
 * @subpackage	AutoCodes
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author		Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminViewlistTableElementCell
{
    /**
     * Gets the HTML code.
     *
     * @param EasyTableField $field
     *
     * @return string HTML
     */
    public function getCode(EasyTable $table, $indent = '')
    {
        $ret = '';

        foreach ($table->getFields() as $field)
        {
            if( ! $field->display
            || $field->display === 'off')
            {
                continue;
            }

            $ret .= $indent.'<td>'.NL;
            $ret .= $indent.'    <?php echo $row->'.$field->name.'; ?>'.NL;
            $ret .= $indent.'</td>'.NL;
        }//foreach

        return $ret;
    }//function

}//class
