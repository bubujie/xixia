<?php
/**
 * @version $Id: var.php 1130 2010-03-23 15:04:01Z elkuku $
 * @package		EasyCreator
 * @subpackage	AutoCodes
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author		Created on 07-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class AutoCodeAdminTableclassClassvarElementVar
{
    public function getCode(EasyTable $table)
    {
        $ret = '';

        foreach ($table->getFields() as $field)
        {
            $ret .= EasyTableHelper::formatTableVar($field->name, $field->type, array($field->label));
            $ret .= NL;
        }//foreach

        return $ret;
    }//function

}//class
