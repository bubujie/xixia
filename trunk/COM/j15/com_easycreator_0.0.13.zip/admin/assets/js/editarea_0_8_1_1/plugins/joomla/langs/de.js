editArea.add_lang("de",{
joomla_select: "Joomla! Konstanten",
joomla_trans_select: "JText::"
});
