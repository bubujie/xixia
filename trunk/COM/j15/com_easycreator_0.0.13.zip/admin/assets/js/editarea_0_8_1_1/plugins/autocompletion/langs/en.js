editArea.add_lang("en",{
autocompletion_but: "Autovervollständigung",
autocompletion_title: "Sonderzeichenxxx",
_autocompletion: "Sonderzeichenxxx"
});