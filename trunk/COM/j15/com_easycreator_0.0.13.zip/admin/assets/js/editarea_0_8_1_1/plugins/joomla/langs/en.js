editArea.add_lang("en",{
joomla_select: "Joomla! Constants",
joomla_trans_select: "JText::"
});
