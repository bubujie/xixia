editArea.add_lang("de",{
autocompletion_but: "Autovervollständigung",
autocompletion_title: "Sonderzeichenxxx",
_autocompletion: "Sonderzeichenxxx"
});