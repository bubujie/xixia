editArea.add_lang("en",{
html_select: "HTML tag"
});
