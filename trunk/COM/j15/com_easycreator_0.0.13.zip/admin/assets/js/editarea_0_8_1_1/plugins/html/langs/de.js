editArea.add_lang("de",{
html_select: "HTML Tag"
});
