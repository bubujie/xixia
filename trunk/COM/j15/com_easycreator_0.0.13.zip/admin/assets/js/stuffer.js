/**
 * @version SVN: $Id: stuffer.js 1223 2010-06-04 15:59:44Z elkuku $
 * @package    EasyCreator
 * @subpackage Javascript
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 31-May-2010
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

function createFile(type1, type2)
{
    $('type1').value = type1;
    $('type2').value = type2;
    
    submitbutton('create_install_file');
}//function
