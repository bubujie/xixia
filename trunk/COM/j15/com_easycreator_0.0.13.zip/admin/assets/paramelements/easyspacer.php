<?php
/**
 * @version SVN: $Id: easyspacer.php 1108 2010-02-22 17:20:47Z elkuku $
 * @package    EasyCreator
 * @subpackage Paramelements
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 08-Dec-2008
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Renders a spacer element.
 *
 * @package 	EasyCreator
 * @subpackage	Parameter
 */
class JElementEasySpacer extends JElement
{
    /**
     * Element name
     *
     * @access	protected
     * @var		string
     */
    var	$_name = 'EasySpacer';

    function fetchTooltip($label, $description, &$node, $control_name, $name)
    {
        return '&nbsp;';
    }//function

    function fetchElement($name, $value, &$node, $control_name)
    {
        if ($value)
        {
            return '<div align="center" style="background-color: #E5FF99; font-size: 1.2em;">'.JText::_($value).'</div>';
        }
        else
        {
            return '<hr />';
        }
    }//function

}//class
