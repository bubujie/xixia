<?php
/**
 * @version SVN: $Id: checkbox.php 1148 2010-03-31 10:24:19Z elkuku $
 * @package    EasyCreator
 * @subpackage Paramelements
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 12-Aug-2009
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Draws a checkbox.
 *
 * @package 	EasyCreator
 * @subpackage	Parameter
 */
class JElementCheckbox extends JElement
{
    /**
     * Element name
     *
     * @access   protected
     * @var      string
     */
    var $_name = 'Checkbox';

    function fetchElement($name, $value, &$node, $control_name)
    {
#        $size =( $node->attributes('size') ? ' size="'.$node->attributes('size').'"' : '' );
        $class =($node->attributes('class')) ? ' class="'.$node->attributes('class').'"' : ' class="text_area"';
#        $text =( $node->attributes('default') ? $node->attributes('default') : '' );
        $checked =($value == 'on') ? ' checked="checked"' : '';

        return '<input type="checkbox" name="'.$control_name.'['.$name.']" id="'.$control_name.$name.'"'.$class.$checked.' />';
    }//function

}//class
