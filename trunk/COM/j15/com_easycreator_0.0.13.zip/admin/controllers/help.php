<?php
/**
 * @version SVN: $Id: help.php 1144 2010-03-29 13:38:58Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 23-Sep-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerHelp extends JController
{
    /**
     * Constructor.
     *
     * @param array $config
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }// function

    /**
     * Standard display method.
     */
    function display()
    {
        JRequest::setVar('view', 'help');
        parent::display();
    }// function

}//class
