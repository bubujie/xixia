<?php
/**
 * @version $Id: languages.php 1172 2010-04-25 15:18:26Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 24-Sep-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller.
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerLanguages extends JController
{
    /**
     * Constructor.
     *
     * @param array $config Configuration.
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }// function

    /**
     * Standard display method.
     */
    function display()
    {
        JRequest::setVar('view', 'languages');

        parent::display();
    }// function

    function save_lang_corrected()
    {
        $ecr_project = JRequest::getCmd('ecr_project');
        $project = EasyProjectHelper::getProject($ecr_project);

        if( ! $project)
        {
            JError::raiseWarning(100, JText::sprintf('Unable to load the project %s', $ecr_project));
            ecrHTML::easyFormEnd();

            return;
        }

        //--Read vars from request
        $scope = JRequest::getVar('scope', 'admin');
        if( ! $scope)
        {
            $scope = 'admin';
        }

        $hideLangs = JRequest::getVar('hide_langs', array());

        if( count($project->langs))
        {
            ecrLoadHelper('language');
            $easyLanguage = new EasyLanguage($project, $scope, $hideLangs);
            $sel_language = JRequest::getVar('sel_language', '');
            $langfile = JRequest::getVar('langfile', array(), 'post', 'array', JREQUEST_ALLOWRAW);
            $easyLanguage->saveFile($sel_language, $langfile);
        }

        JRequest::setVar('task', 'languages');
        JRequest::setVar('view', 'languages');

        parent::display();
    }//function

    function save_deflang_corrected()
    {
        $ecr_project = JRequest::getCmd('ecr_project');
        $project = EasyProjectHelper::getProject($ecr_project);

        if( ! $project)
        {
            JError::raiseWarning(100, JText::sprintf('Unable to load the project %s', $ecr_project));
            ecrHTML::easyFormEnd();

            return;
        }

        //--read vars from request
        $scope = JRequest::getVar('scope', 'admin');
        if( ! $scope)
        {
            $scope = 'admin';
        }

        $hideLangs = JRequest::getVar('hide_langs', array());

        if( ! count($project->langs))
        {
            $easyLanguage = false;
        }
        else
        {
            ecrLoadHelper('language');
            $easyLanguage = new EasyLanguage($project, $scope, $hideLangs);
            $langfile = JRequest::getVar('langfile', array(), 'post', 'array', JREQUEST_ALLOWRAW);
            $easyLanguage->saveFile('en-GB', $langfile);
        }

        JRequest::setVar('task', 'languages');
        JRequest::setVar('view', 'languages');
        parent::display();
    }//function

    function create_langfile()
    {
        ecrLoadHelper('language');

        $ecr_project = JRequest::getCmd('ecr_project');
        if(EasyLanguage::createFileFromRequest())
        {
            $msg = JText::_('The file has been created');
            $type = '';
        }
        else
        {
            $msg = JText::_('Unable to create language file');
            $type = 'error';
        }

        $oldTask = JRequest::getCmd('old_task');
        $task =( $oldTask ) ? $oldTask : 'languages';

        $this->setRedirect('index.php?option=com_easycreator&controller=languages&task='.$task.'&ecr_project='.$ecr_project, $msg, $type);

        parent::display();
    }//function


    function remove_bom()
    {
        ecrLoadHelper('language');

        $fileName = JRequest::getVar('file');
        if( ! $fileName )
        {
            ecrHTML::displayMessage('No filename set', 'error');
        }
        else
        {
            if( EasyLanguage::removeBOM_utf8($fileName) )
            {
                ecrHTML::displayMessage(JText::_('The BOM has been removed'));
            }
            else
            {
                ecrHTML::displayMessage(JText::_('Unable to remove the BOM'), 'error');
            }
        }

        JRequest::setVar('view', 'languages');
        JRequest::setVar('task', 'languages');

        parent::display();
    }//function

    function do_convert()
    {
        ecrLoadHelper('languageconverter');
        ecrLoadHelper('file');

        JRequest::setVar('task', 'convert');

        $options = JArrayHelper::toObject(JRequest::getVar('options', array()), 'JObject');

        $project = EasyProjectHelper::getProject(JRequest::getCmd('ecr_project'));

        if( ! $project)
        {
            JError::raiseWarning(100, 'Invalid project');

            parent::display();

            return;
        }

        $languages = JFactory::getLanguage()->getKnownLanguages();

        $converter = new ECRLanguageConverter($options);
        $converter->prefix = strtoupper($project->comName);

        $selLanguage = JRequest::getCmd('sel_language');
        $selectedFile = JRequest::getVar('selected_file');
        $fileErrors = JRequest::getVar('file_errors', array());
        $scope = JRequest::getCmd('scope');

        $selectedErrors = JRequest::getVar('selected_errors', array());

        /*
         * Clean language files
         */
        $paths = $project->getLanguagePaths();

        foreach($languages as $tag => $language)
        {
            $path = $paths[$scope].DS.'language'.DS.$tag;

            $fileName = $tag.'.'.$project->getLanguageFileName($scope);

            if(JFile::exists($path.DS.$fileName))
            {
                $fileContents = JFile::read($path.DS.$fileName);
            }
            else
            {
                continue;
            }

            $lines = explode("\n", $fileContents);

            $newLines = $converter->cleanLines($lines);
            $newLines = $converter->cleanLangFileErrors($newLines, array_keys($selectedErrors));

            $newFileContents = implode("\n", $newLines);

            EasyFile::saveVersion($path.DS.$fileName);
            JFile::write($path.DS.$fileName, $newFileContents);
        }//foreach

        if($selectedFile && count($selectedErrors))
        {
            /*
             * Clean PHP file
             */
            $origCode = JFile::read(JPATH_ROOT.DS.$selectedFile);

            $errors = $converter->findPHPErrors($origCode, array_keys($selectedErrors));

            $newCode = $origCode;

            foreach($errors as $errorKey => $errorJText)
            {
                $newJText = str_replace($errorKey, $converter->cleanKey($errorKey), $errorJText);
                $newCode = str_replace($errorJText, $newJText, $newCode);
            }//foreach

            if($newCode != $origCode)
            {
                EasyFile::saveVersion(JPATH_ROOT.DS.$selectedFile);
                JFile::write(JPATH_ROOT.DS.$selectedFile, $newCode);
            }
        }

        parent::display();
    }//function

}//class
