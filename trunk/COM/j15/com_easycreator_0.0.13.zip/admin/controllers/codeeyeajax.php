<?php
/**
 * @version SVN: $Id: codeeyeajax.php 1218 2010-05-29 04:28:27Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 02-Oct-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerCodeEyeAjax extends JController
{
    /**
     * Constructor.
     *
     * @param array $config
     */
    public function __construct($config = array())
    {
        parent::__construct($config);
    }//function

    /**
     * Executes a PHPUnit test.
     *
     * @return string JSON response
     */
    public function phpunit()
    {
        ecrLoadHelper('pearhelpers.phpunit');

        $response = array();

        $folder = JRequest::getString('folder');
        $test = JRequest::getString('test');
        $time_stamp = JRequest::getCmd('time_stamp');
        $resultsBase = JRequest::getVar('results_base');

        $arguments = array();

        //-- Joomla! bootstrap
        $arguments[] = '--bootstrap '.JPATH_ROOT.DS.'bootstrap.php';

        if( ! JFolder::exists(JPATH_ROOT.DS.$resultsBase))
        {
            JFolder::create(JPATH_ROOT.DS.$resultsBase);
        }

        //-- JUnit XML log file
        $logName = JPATH_ROOT.DS.$resultsBase.DS.$time_stamp.'_'.JFile::getName($test).'.xml';
        $arguments[] = '--log-junit '.$logName;

        //-- @todo: Test Name
        $arguments[] = 'KuKuTest';

        $arguments[] =($folder) ? JPATH_ROOT.DS.$folder.DS.$test : JPATH_ROOT.DS.$test;

        $phpUnit = new EasyPHPUnit();

        ob_start();
        $results = $phpUnit->test($arguments);
        $add = ob_get_contents();
        ob_end_clean();

        if(JFile::exists($logName))
        {
            $response['text'] = $add.BR.$phpUnit->showFormattedLog($logName);
            $response['status'] = 1;
        }
        else
        {
            $response['text'] = $add.BR.'ERROR writing: '.$logName;
            $response['status'] = 0;
        }

        $response['console'] = htmlentities($results);

        echo json_encode($response);
    }//function

    public function selenium()
    {
        ecrLoadHelper('pearhelpers.selenium');

        $response = array();

        $folder = JRequest::getString('folder');
        $test = JRequest::getString('test');
        $time_stamp = JRequest::getCmd('time_stamp');
        $resultsBase = JRequest::getVar('results_base');

        $arguments = array();

        //-- Joomla! bootstrap
        $arguments[] = '--bootstrap '.JPATH_ROOT.'/tests/system/servers/config-def.php';
#$arguments[] = '--singleWindow';
        if( ! JFolder::exists(JPATH_ROOT.DS.$resultsBase))
        {
       #     JFolder::create(JPATH_ROOT.DS.$resultsBase);
        }

        //-- JUnit XML log file
//        $logName = JPATH_ROOT.DS.$resultsBase.DS.$time_stamp.'_'.JFile::getName($test).'.xml';
//        $arguments[] = '--log-junit '.$logName;

        //-- @todo: Test Name
//        $arguments[] = 'KuKuTest';

        $arguments[] =($folder) ? JPATH_ROOT.DS.$folder.DS.$test : JPATH_ROOT.DS.$test;

        $seleniumTest = new EasySeleniumTest();

        ob_start();
        $results = $seleniumTest->test($arguments);
        $add = ob_get_contents();
        ob_end_clean();

//        if(JFile::exists($logName))
//        {
//            $response['text'] = $add.BR.$phpUnit->showFormattedLog($logName);
//            $response['status'] = 1;
//        }
//        else
//        {
//            $response['text'] = $add.BR.'ERROR writing: '.$logName;
//        }
            $response['status'] = 0;

        $response['console'] = htmlentities($results);

        echo json_encode($response);
    }//function

    public function create_skeleton()
    {
        ecrLoadHelper('pearhelpers.phpunit');

        $folder = JRequest::getString('folder');
        $file = JRequest::getString('file');
        $ecr_project = JRequest::getCmd('ecr_project');

        $path = JPATH_ROOT.DS.$folder.DS.$file;

        $arguments = array();
        $response = array();

        $response['status'] = 0;

        if( ! JFile::exists($path))
        {
            $response['text'] = JText::_('File not found');
        }
        else
        {
            if(JFile::getExt($path) != 'php')
            {
                $response['text'] = JText::_('Only PHP files are allowed');
                $response['console'] = $response['text'];
            }
            else
            {
                $classes = get_declared_classes();

                include $path;
                ob_start();
                $includedOutput = ob_get_contents();
                ob_end_clean();

                $foundClasses = array_diff(get_declared_classes(), $classes);

                if( ! count($foundClasses))
                {
                    $response['text'] = JText::_('No classes found');
                    $response['console'] = $response['text'];
                }
                else
                {
                    $class = array_pop($foundClasses);
                    $resultPath = JPATH_ROOT.DS.$folder.DS.$class.'Test.php';

                    //-- Joomla! bootstrap
                    $arguments[] = '--bootstrap '.JPATH_ROOT.DS.'bootstrap.php';
                    $arguments[] = '--skeleton-test '.$class.' '.$path;

                    $phpUnit = new EasyPHPUnit();

                    ob_start();
                    $results = $phpUnit->skeleton($arguments);
                    $add = ob_get_contents();
                    ob_end_clean();

                    $subFolder = '';

                    if(JFile::exists($resultPath))
                    {
                        $scope =(strpos($resultPath, JPATH_ADMINISTRATOR) === false) ? 'site' : 'admin';

                        $test = str_replace(DS.JFile::getName($resultPath), '', $resultPath);

                        if(strpos($test, JPATH_ADMINISTRATOR) === false)
                        {
                            if($test != JPATH_SITE.DS.'components'.DS.$ecr_project)
                            {
                                //-- Subfolder
                                $subFolder = str_replace(JPATH_SITE.DS.'components'.DS.$ecr_project.DS, '', $test);
                            }
                        }
                        else
                        {
                            if($test != JPATH_ADMINISTRATOR.DS.'components'.DS.$ecr_project)
                            {
                                //-- Subfolder
                                $subFolder = str_replace(JPATH_ADMINISTRATOR.DS.'components'.DS.$ecr_project.DS, '', $test);
                            }
                        }

                        $destFolder = JPATH_ADMINISTRATOR.DS.'components'.DS.$ecr_project.DS.'tests'.DS.$scope;
                        $destFolder .=($subFolder) ? DS.$subFolder : '';

                        $destFileName = $class.'Test.php';


                        if( ! JFolder::exists($destFolder))
                        {
                            JFolder::create($destFolder);
                        }

                        if( JFile::move($resultPath, $destFolder.DS.$destFileName))
                        {
                            $response['status'] = 1;
                        }
                        else
                        {

                        }

                    }
                    else
                    {

                    }

                    $response['text'] = $add.$includedOutput;
                    $response['console'] = htmlentities($results);
                }
            }
        }

        echo json_encode($response);
    }//function

    public function draw_test_dir()
    {
        ecrLoadHelper('php_file_tree');
        $ecr_project = JRequest::getCmd('ecr_project');
        $this->testsBase = 'administrator'.DS.'components'.DS.$ecr_project.DS.'tests';

        $timeStamp = date('Ymd_his');
        $jsFile = '';
        $jsFile .= " onclick=\"doPHPUnit('[link]', '[file]', '$timeStamp', '[id]');\"";

        $jsFolder = '';

        $fileTree = new phpFileTree(JPATH_ROOT.DS.$this->testsBase, '', $jsFile, $jsFolder);

        $arguments = array();
        $response = array();

        //-- Joomla! bootstrap
        $arguments[] = '--bootstrap '.JPATH_ROOT.DS.'bootstrap.php';

        $results = print_r($_REQUEST, true);

        $response['text'] = $fileTree->drawFullTree();;
        $response['console'] = htmlentities($results);
        $response['status'] = 1;

        echo json_encode($response);
    }//function

    /**
     * Executes a 'sniff'.
     *
     * @return string JSON response.
     */
    function load_sniff()
    {
        ecrLoadHelper('pearhelpers.CodeSniffer');

        $path = JRequest::getVar('path');
        $file = JRequest::getVar('file');

        $response = array();

        $response['status'] = 0;
        $response['text'] = '';
        $response['console'] = '';

        if( ! $file)
        {
            if( ! JFolder::exists(JPATH_ROOT.DS.$path))
            {
                $response['text'] = '<b style="color: red">'.JText::_('Folder not found').'</b>';

                echo json_encode($response);
                return;
            }

            $fullPath = JPATH_ROOT.DS.$path;
        }
        else
        {
            $ext = JFile::getExt($file);

            $sniffExtensions = array('php', 'js');

            if( ! in_array($ext, $sniffExtensions))
            {
                $response['text'] = '<b style="color: red">Sniffeable extensions:<br />'.implode(',', $sniffExtensions).'</b>';

                echo json_encode($response);
                return;
            }

            $fullPath = JPATH_ROOT.DS.$path.DS.$file;

            if( ! JFile::exists($fullPath))
            {
                $response['text'] = '<b style="color: red">'.JText::_('File not found').'</b>';

                echo json_encode($response);
                return;
            }
        }

        $fullPath = str_replace('/', DS, $fullPath);

        ob_start();

        $sniffer = new EasyCodeSniffer();

        $standard = JRequest::getVar('sniff_standard');

        if($standard)
        {
            $sniffer->setStandard($standard);
        }

        $format = JRequest::getVar('sniff_format');

        if($format)
        {
            $sniffer->setFormat($format);
        }

        $verbose = JRequest::getCmd('sniff_verbose');
        $sniffer->verboseLevel =( $verbose == 'true' ) ? '-v' : '';

        $sniffs = JRequest::getVar('sniff_sniffs');

        if($sniffs)
        {
            if(substr($sniffs, strlen($sniffs)-1) == ',')
            {
                $sniffs = substr($sniffs, 0, strlen($sniffs)-1);
            }

            $sniffer->sniffs = explode(',', $sniffs);
        }

        $results = $sniffer->sniffFile($fullPath);
        $response['text'] = ob_get_contents();
        ob_end_clean();

        $response['console'] = htmlentities($results);
        $response['status'] = 1;

        echo json_encode($response);
    }//function

    /**
     * Runs PHP Copy & Paste detector.
     *
     * @return string JSON response.
     */
    public function phpcpd()
    {
        ecrLoadHelper('pearhelpers.phpcpd');

        $path = JRequest::getVar('path');

        $arguments = array();
        $arguments['min-lines'] = (int)JRequest::getInt('min-lines', 5);
        $arguments['min-tokens'] = (int)JRequest::getInt('min-tokens', 70);

        $response = array();

        if( ! $path )
        {
            $response['status'] = 0;
            $response['text'] = JText::_('No path set');
            $response['console'] = '';

            echo json_encode($response);

            return;
        }

        ob_start();
        $phpcpd = new EasyPHPCPD();

        $results = $phpcpd->detect($arguments, $path);

        $response['text'] = ob_get_contents();
        ob_end_clean();

        $response['console'] = htmlentities($results);
        $response['status'] = 1;

        echo json_encode($response);
    }//function

    /**
     * Runs PHPDocumentor.
     *
     * @return string JSON response.
     */
    public function phpdoc()
    {
        ecrLoadHelper('pearhelpers.phpdoc');

        $response = array();

        $parseDirs = JRequest::getVar('parse_dirs');
        $parseFiles = JRequest::getVar('parse_files');
        $targetDir = JRequest::getVar('target_dir');
        $converter = JRequest::getVar('converter');
        $options = JRequest::getVar('options');

        $phpDoc = new EasyPHPDoc();

        if($converter)
        {
            $cs = explode(':', $converter);
            $phpDoc->outputFormat = $cs[0];
            $phpDoc->converter = $cs[1];
            $phpDoc->template = $cs[2];
        }

        $parseDirs = explode(',', $parseDirs);
        $a = array();

        foreach ($parseDirs as $n)
        {
            $a[] = JPATH_ROOT.DS.$n;
        }//foreach

        $parseDirs = implode(',', $a);

        $parseFiles = explode(',', $parseFiles);
        $a = array();

        foreach ($parseFiles as $n)
        {
            $a[] = JPATH_ROOT.DS.$n;
        }//foreach

        $parseFiles = implode(',', $a);

        $phpDoc->parseDirs = $parseDirs;
        $phpDoc->parseFiles = $parseFiles;

        $phpDoc->targetDir = JPATH_ROOT.DS.$targetDir;

        ob_start();
        $results = $phpDoc->process($options);
        $add = ob_get_contents();
        ob_end_clean();

        $response['console'] = htmlentities($results);

        if( ! JFile::exists(JPATH_ROOT.DS.$targetDir.DS.'index.html'))
        {
            $response['status'] = 0;
            $response['text'] = JText::_('Something went wrong...');
            echo json_encode($response);

            return;
        }

        $response['status'] = 1;
        $response['text'] = '';
        $response['text'] .= '<h1>'.JText::_('Documentation has been created').'</h1>';
        $response['text'] .= '<a class="external" href="'.JURI::root(true).'/'.str_replace(DS, '/', $targetDir).'">'.JText::_('View Documentation').'</a>'.BR;
        $response['text'] .= '<a class="external" href="'.JURI::root(true).'/'.str_replace(DS, '/', $targetDir.'/errors.html').'">'.JText::_('View Errors').'</a>'.BR;
        $response['text'] .= $add;

        echo json_encode($response);
    }//function

    /**
     * Checks for installed PEAR packages.
     *
     * @return string JSON response
     */
    public function check_environment()
    {
        ecrLoadHelper('pearhelpers.consolehelper');

        $response = array();

        $pearConsole = new EasyPearConsole();

        ob_start();
        $pearPackages = $pearConsole->getPackages();
        $notFound = '<strong style="color: red;">'.JText::_('Not found').'</strong>';

        if( ! count($pearPackages))
        {
            echo '<h2 style="color: red;">'.JText::_('No PEAR packages found - Please check your Paths').'</h2>';
        }
        else
        {
            ?>

<h3>Installed PEAR Packages</h3>
<table class="adminlist">

	<thead>
		<tr>
			<th><?php echo JText::_('Package'); ?></th>
			<th><?php echo JText::_('Version'); ?></th>
			<th><?php echo JText::_('Recommended'); ?></th>
			<th><?php echo JText::_('Info'); ?></th>
		</tr>
	</thead>

	<tbody>
		<tr class="row0">
			<td>PHP_CodeSniffer</td>
			<td><?php echo (array_key_exists('PHP_CodeSniffer', $pearPackages)) ? $pearPackages['PHP_CodeSniffer'] : $notFound; ?>
			</td>
			<td>1.2.0</td>
			<td><a href="http://pear.php.net/package/PHP_CodeSniffer"
				class="external">PHP_CodeSniffer</a> tokenises PHP, JavaScript and
			CSS files and detects violations of a defined set of coding
			standards.</td>
		</tr>

		<tr class="row1">
			<td>phpcpd</td>
			<td><?php echo $pearConsole->testVersion('phpcpd', '1.2.0'); ?></td>
			<td>1.1.1</td>
			<td><a href="http://github.com/sebastianbergmann/phpcpd"
				class="external">phpcpd</a> is a Copy/Paste Detector (CPD) for PHP
			code.</td>
		</tr>

		<tr class="row0">
			<td>PhpDocumentor</td>
			<td><?php echo (array_key_exists('PhpDocumentor', $pearPackages)) ? $pearPackages['PhpDocumentor'] : $notFound; ?>
			</td>
			<td>1.4.3</td>
			<td><a href="http://www.phpdoc.org/" class="external">PhpDocumentor</a>
			is the world standard auto-documentation tool for PHP.</td>
		</tr>

		<tr class="row1">
			<td>PhpUnit</td>
			<td><?php  echo $pearConsole->testVersion('phpunit', '3.4.0'); ; ?></td>
			<td>3.4.0</td>
			<td><a href="http://www.phpunit.de/" class="external">PhpUnit</a>
			provides both a framework that makes the writing of tests easy as
			well as the functionality to easily run the tests and analyse their
			results.</td>
		</tr>

	</tbody>

</table>
            <?php
        }
        $response['text'] = ob_get_contents();
        ob_end_clean();

        ob_start();
        echo '<h3>System</h3>';
        echo 'PHP: '.PHP_VERSION.BR;
        echo 'memory_limit: '.ini_get('memory_limit').BR;
        echo 'max_execution_time: '.ini_get('max_execution_time').BR.BR;
        echo 'PHP include_path: '.BR.get_include_path().BR.BR;
        echo 'System PATH: '.BR.shell_exec('echo $PATH').BR;
        echo '<hr />';
        echo '<h3>All PEAR packages - FYI only.. =;)</h3>';
        print_r($pearPackages);

        $response['console'] = ob_get_contents();
        ob_end_clean();

        $response['status'] = 1;

        echo json_encode($response);
    }//function

    /**
     *
     */
    public function get_stats()
    {
        JRequest::setVar('view', 'codeeye');
        JRequest::setVar('layout', 'stats2_table');
        parent::display();

        return;
    }//function

    /**
     *
     */
    public function get_chart()
    {
        error_reporting(E_ALL);

        include(JPATH_COMPONENT.DS.'helpers'.DS.'pchart'.DS.'pData.class.php');
        include(JPATH_COMPONENT.DS.'helpers'.DS.'pchart'.DS.'pChart.class.php');

        JFactory::getDocument()->setMimeEncoding('image/jpg');

        $data = JRequest::getVar('data', '');
        $labels = JRequest::getVar('labels', '');

        $colorChart = JRequest::getInt('color', 8);

        $colorPath = JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'pchart'.DS.'colours'.DS.'tones-'.$colorChart.'.txt';

        $DataSet = new pData;


        if($data)
        {
            $data = explode(',', $data);
            $labels = explode(',', $labels);

            $DataSet->AddPoint($data, 'Serie1');
            $DataSet->AddPoint($labels, 'Serie2');
        }
        else
        {
            $DataSet->AddPoint(array(10,2,3,5,3),"Serie1");
            $DataSet->AddPoint(array("Jan","Feb","Mar","Apr","May"),"Serie2");
        }

        $DataSet->AddAllSeries();
        $DataSet->SetAbsciseLabelSerie("Serie2");

        //-- Initialise the graph
        $chart = new pChart(380, 200);

        if(JFile::exists($colorPath))
        {
            $chart->loadColorPalette($colorPath);
        }

        #      $chart->drawFilledRoundedRectangle(7, 7, 373, 193, 5, 240, 240, 240);
        #       $chart->drawRoundedRectangle(5, 5, 375, 195, 5, 230, 230, 230);

        //-- Draw the pie chart
        $chart->setFontProperties(JPATH_COMPONENT.DS.'helpers'.DS.'pchart/Fonts/MankSans.ttf', 10);
        $chart->drawPieGraph($DataSet->GetData(), $DataSet->GetDataDescription(), 150, 90, 110, PIE_PERCENTAGE, true, 50, 20, 5);
        $chart->drawPieLegend(290, 15, $DataSet->GetData(), $DataSet->GetDataDescription(), 250, 250, 250);

        //-- Spit it out
        $chart->Stroke();

        return;
    }//function

}//class
