<?php
/**
 * @version SVN: $Id: templates.php 1146 2010-03-30 19:35:55Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 23-Sep-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerTemplates extends JController
{
    /**
     * Constructor
     *
     * @param array $config
     */
    public function __construct($config = array())
    {
        parent::__construct($config);
    }// function

    /**
     * Standard display method.
     */
    public function display()
    {
        JRequest::setVar('view', 'templates');
        parent::display();
    }// function

    /**
     * Save a file.
     */
    public function save()
    {
        ecrLoadHelper('file');

        $retVal = EasyFile::saveFile();

        if($retVal === true)
        {
            JError::raiseNotice(100, 'fine');
        }
        else
        {
            JError::raiseNotice(100, $retVal);
        }

        JRequest::setVar('view', 'templates');
        JRequest::setVar('task', 'templates');

        parent::display();
    }// function

    /**
     * Delete a file.
     */
    public function delete()
    {
        ecrLoadHelper('file');

        $retVal = EasyFile::deleteFile();

        if($retVal === true)
        {

            JFactory::getApplication()->enqueueMessage(JText::_('Template has been deleted.'));
        }
        else
        {
            JError::raiseWarning(100, $retVal);
        }

        JRequest::setVar('view', 'templates');
        JRequest::setVar('task', 'export');

        parent::display();
    }//function

    /**
     * Export EasyCreator extension templates.
     */
    public function do_export()
    {
        ecrLoadHelper('easytemplatehelper');

        $exports = (array)JRequest::getVar('exports');

        if($exports)
        {
            if(EasyTemplateHelper::exportTemplates($exports))
            {
                JFactory::getApplication()->enqueueMessage(JText::_('Templates have been exported.'));
            }
            else
            {
                JError::raiseWarning(100, JText::_('Unable to export templates'));
            }
        }
        else
        {
            JError::raiseWarning(100, JText::_('No templates selected'));
        }

        JRequest::setVar('view', 'templates');
        JRequest::setVar('task', 'export');

        parent::display();
    }//function

    /**
     * Installs EasyCreator extension templates.
     */
    public function do_install()
    {
        ecrLoadHelper('easytemplatehelper');

        if(EasyTemplateHelper::installTemplates())
        {
            JError::raiseNotice(100, JText::_('Templates have been installed.'));
        }
        else
        {
            JError::raiseWarning(100, JText::_('Unable to install templates.'));
        }

        JRequest::setVar('view', 'templates');
        JRequest::setVar('task', 'templates');

        parent::display();
    }//function

}//class
