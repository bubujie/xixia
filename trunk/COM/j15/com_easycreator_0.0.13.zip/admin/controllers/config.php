<?php
/**
 * @version SVN: $Id: config.php 1174 2010-04-26 14:51:33Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 12-Okt-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerConfig extends JController
{
    /**
     * Constructor.
     *
     * @param array $config
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }//function

    /**
     * Standard display method.
     */
    function display()
    {
        JRequest::setVar('view', 'config');
        parent::display();
    }//function

    /**
     * Save the configuration.
     */
    public function save_config()
    {
        switch(ECR_JVERSION)
        {
            case '1.5':
                $table = JTable::getInstance('component');
                $table->loadByOption('com_easycreator');
                break;
            case '1.6':
                $component = JComponentHelper::getComponent('com_easycreator');
                $table = JTable::getInstance('extension');
                $table->load($component->id);
                break;

            default:
                JError::raiseWarning(100, JText::_('Unsupported Joomla version in EasyCreatorViewConfig->display'));

                ecrHTML::easyFormEnd();
                return;
                break;
        }//switch

        $this->parameters = new JParameter($table->params, JPATH_COMPONENT.DS.'config.xml');

        $ecr_project = JRequest::getCmd('ecr_project');

        $post = JRequest::get('post');
        $table->bind($post);

        //-- Pre-save checks
        if( ! $table->check())
        {
            JError::raiseWarning(500, $table->getError());
            return false;
        }

        //-- Save the changes
        if( ! $table->store())
        {
            JError::raiseWarning(500, $table->getError());
            return false;
        }

        $adds =($ecr_project) ? '&view=stuffer&ecr_project='.$ecr_project : '';

        $this->setRedirect('index.php?option=com_easycreator'.$adds, JText::_('Configuration has been saved'));
    }//function

}//class
