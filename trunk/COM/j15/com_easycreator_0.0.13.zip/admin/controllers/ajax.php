<?php
/**
 * @version SVN: $Id: ajax.php 1172 2010-04-25 15:18:26Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 20-Apr-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller.
 *
 * @todo in which type of controller will i place the ajax methods ??
 *
 * @package EasyCreator
 */
class EasyCreatorControllerAjax extends JController
{
    /**
     * Constructor.
     *
     * @param array $config Configuration.
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }//function

    /**
     * Shows a part from templates/parts folder.
     * Calls the 'getOptions' function in part class.
     *
     * @return void
     */
    function show_part()
    {
        $group = JRequest::getCmd('group');
        $part = JRequest::getCmd('part');
        $element = JRequest::getCmd('element');
        $scope = JRequest::getCmd('scope');

        if( ! $EasyPart = EasyProjectHelper::getPart($group, $part, $element, $scope))
        {
            return;
        }

        if(method_exists($EasyPart, 'info'))
        {
            $info = $EasyPart->info();

            if( ! get_class($info) == 'EasyPart')
            {
                echo 'Part info must be a EasyPart class.. not : ';
                echo get_class($info);
                return;
            }

            echo $info->format('erm', 'add');
        }
        else
        {
            echo '<div style="color: blue; font-weight: bold; text-align:center;">'.ucfirst($group).' - '.ucfirst($part).'</div>';
        }

        //--Additional request vars
        echo '<input type="hidden" name="group" value="'.$group.'" />';
        echo '<input type="hidden" name="part" value="'.$part.'" />';

        //--Additional options from part file
        echo $EasyPart->getOptions();
    }//function

    /**
     * Calls the 'edit' function in part class.
     *
     * @return void
     */
    function edit_part()
    {
        $EasyProject = EasyProjectHelper::getProject(JRequest::getCmd('ecr_project'));

        $group = JRequest::getCmd('group');
        $part = JRequest::getCmd('part');
        $element = JRequest::getCmd('element');
        $scope = JRequest::getCmd('scope');

        if( ! $EasyPart = EasyProjectHelper::getPart($group, $part, $element, $scope, true))
        {
            echo '<h4 style="color: red;">PART not found</h4>';
            return;
        }

        if( ! method_exists($EasyPart, 'edit'))
        {
            echo '<h4 style="color: red;">EDIT function not found</h4>';
            return;
        }

        if( ! isset($EasyPart->key)
        || ! isset($EasyProject->autoCodes[$EasyPart->key]))
        {
            echo '<h4 style="color: red;">No AutoCode found</h4>';
            return;
        }

        if(method_exists($EasyPart, 'info'))
        {
            $info = $EasyPart->info();
            if( ! get_class($info) == 'EasyPart')
            {
                echo 'Part info must be a EasyPart class.. not : ';
                echo get_class($info);
                return;
            }

            echo $info->format('erm', 'edit');
        }
        else
        {
            echo '<div style="color: blue; font-weight: bold; text-align:center;">'.ucfirst($group).' - '.ucfirst($part).'</div>';
        }

        //--Additional request vars
        echo '<input type="hidden" name="group" value="'.$group.'" />';
        echo '<input type="hidden" name="part" value="'.$part.'" />';

        echo $EasyPart->edit($EasyProject->autoCodes[$EasyPart->key]);
    }//function

    /**
     * For JHelp.
     *
     * @return void
     */
    function show_source()
    {
        $rClass = JRequest::getCmd('class');
        $rMethod = JRequest::getCmd('method');

        $classlistPath = JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'jclasslists';
        $fName = 'jclasslist_'.str_replace('.', '_', JVERSION);

        if( ! JFile::exists($classlistPath.DS.$fName.'.php'))
        {
            echo JText::sprintf('The class file for your Joomla version %s has not been build yet.', JVERSION);
            echo BR.$classlistPath.DS.$fName.'.php';

            return;
        }

        JLoader::import($fName, $classlistPath);

        $cList = getJoomlaClasses();

        if( ! class_exists($rClass))
        {
            if(array_key_exists($rClass, $cList))
            {
                $path = JPATH_LIBRARIES.DS.'joomla'.DS.$cList[$rClass][1];

                if( ! JFile::exists($path))
                {
                    echo '<strong style="color: red">'.JText::_('File not found').'</strong>'.BR;

                    return;
                }

                ecrLoadHelper('reflection');
                fakeClasses(JFile::getName($cList[$rClass][1]));

                require_once $path;
            }

            if( ! class_exists($rClass))
            {
                echo '<strong style="color: red">'.JText::sprintf('Class %s NOT FOUND', $rClass).'</strong>'.BR;

                var_dump($cList);

                return;
            }
        }

        $class = new ReflectionClass($rClass);
        $methods = $class->getMethods();

        if($rMethod != 'NULL')
        {
            foreach ($methods as $method)
            {
                if($method->name != $rMethod)
                {
                    continue;
                }

                $fileContents = file($method->getFileName());
                $code = '';

                for ($i = $method->getStartLine()-1; $i < $method->getEndline(); $i++)
                {
                    $l = rtrim($fileContents[$i]).NL;

                    //-- Strip leading tabs
                    if( substr($l, 0, 1) == "\t")
                    {
                        $l = substr($l, 1);
                    }

                    //-- Convert tabs to three spaces
                    $l = str_replace("\t", '   ', $l);
                    $code .= $l;
                }//for

                $docComment = nl2br(htmlentities($method->getDocComment()));
                $pattern = '#(@[a-z]+)#';
                $docComment = preg_replace($pattern, '<strong>$1</strong>', $docComment);
                echo "<h1>$rClass - $rMethod</h1>";
                echo '<div class="path">';
                echo '<span class="img icon-16-directory" style="font-size: 1.3em; font-weight: bold;">'.str_replace(JPATH_ROOT, '', $method->getFileName()).'</span> - # '.$method->getStartLine().' - '.$method->getEndline();
                echo '</div>';
                echo '<div style="font-size: 1.2em;">'.$docComment.'</div>';
                $hlCode = highlight_string('<?php'.NL.$code, true);
                $hlCode = str_replace('&lt;?php', '', $hlCode);
                echo '<div style="border: 1px dashed gray; background-color: #eee;">'.$hlCode.'</div>';
            }//foreach
        }
        else
        {
            //-- No method given - output the whole class
            echo "<h1>$rClass</h1>";

            foreach ($methods as $method)
            {
                if($method->getDeclaringClass()->name != $rClass)
                {
                    continue;
                }

                $title = sprintf(
				    "%s%s%s%s%s%s%s function <span style='color: blue;'>%s</span> %s",
                $method->isInternal() ? 'internal' : '',
                $method->isAbstract() ? ' abstract' : '',
                $method->isFinal() ? ' final' : '',
                $method->isPublic() ? ' <span style="color: green;">public</span>' : '',
                $method->isPrivate() ? ' <strong style="color: orange">private</strong>' : '',
                $method->isProtected() ? ' <strong style="color: red">protected</strong>' : '',
                $method->isStatic() ? ' <strong style="color: black">static</strong>' : '',
                $method->getName(),
                $method->isConstructor() ? '<span style="color: green;">Konstruktor</span>' : ''
                );
                $parameters = $method->getParameters();
                $paramString = '';

                foreach( $parameters as $parameter )
                {
                    $s = '';
                    $s .= sprintf("%s<strong style='color: brown;'>$%s</strong>",
                    #					$parameter->isOptional() ? '<strong style="color: blue;">optional</strong> ' : '',
                    $parameter->isPassedByReference() ? '<strong style="color: blue;"> & </strong>' : '',
                    $parameter->getName()
                    );

                    if( $parameter->isDefaultValueAvailable())
                    {
                        $def = $parameter->getDefaultValue();

                        if( $def === null)
                        {
                            $s .= '=null';
                        }
                        else if( $def === false )
                        {
                            $s .= '=false';
                        }
                        else if( $def === true )
                        {
                            $s .= '=true';
                        }
                        else if( $def === array() )
                        {
                            $s .= '=array()';
                        }
                        else if( $def === '' )
                        {
                            $s .= '=\'\'';
                        }
                        else
                        {
                            $s .= '='.$parameter->getDefaultValue();
                        }
                    }

                    $paramString[] = $s;
                }//foreach

                if($paramString)
                {
                    $paramString = implode(', ', $paramString);
                }

                echo JHTML::tooltip(nl2br(htmlentities($method->getDocComment())), $method->getName());
                echo $title.'('.$paramString.')';
                echo BR;
            }//foreach
        }
    }//function

    /**
     * Executes a function inside a 'part' from templates/parts folder
     *
     * @return ?
     */
    function part_task()
    {
        ecrLoadHelper('EasyPart');

        $group = JRequest::getCmd('group');
        $part = JRequest::getCmd('part');
        $element = JRequest::getCmd('element');
        $scope = JRequest::getCmd('scope');

        $partTask = JRequest::getCmd('part_task');

        if( ! $easyPart = EasyProjectHelper::getPart($group, $part, $element, $scope))
        {
            ecrHTML::displayMessage(array(JText::_('Unable to load part').' [group, part]', $group, $part), 'error');

            return;
        }

        if( ! method_exists($easyPart, $partTask))
        {
            ecrHTML::displayMessage(array(JText::_('Function not found'), $partTask), 'error');

            return;
        }

        //--Execute the task
        return $easyPart->$partTask($element);

    }//function

    /**
     * Saves a translation
     *
     * @return void - echoes a JSON encoded string
     */
    function translate()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        $project = EasyProjectHelper::getProject($ecr_project);

        $response = array();

        $response['status'] = 0;

        if( ! $project)
        {
            $response['text'] = JText::sprintf('Unable to load the project %s', $ecr_project);

            echo json_encode($response);
            return;
        }

        //--read vars from request
        $scope = JRequest::getCmd('scope');

        if( ! $scope)
        {
            $response['text'] = JText::_('No scope given');

            echo json_encode($response);
            return;
        }

        if( ! count($project->langs))
        {
            $response['text'] = JText::_('No languages found');

            echo json_encode($response);
            return;
        }

        ecrLoadHelper('language');
        $easyLanguage = new EasyLanguage($project, $scope, array());

        $trans_lang = JRequest::getCmd('trans_lang');
        $trans_key = JRequest::getString('trans_key');

        $translation = JRequest::getVar('translation', '', 'post', 'string', JREQUEST_ALLOWRAW);

        //-- Strip line breaks
        $translation = str_replace("\n", '<br />', $translation);

        if($easyLanguage->saveTranslation($trans_lang, $trans_key, $translation))
        {
            $response['status'] = 1;
        }
        else
        {
            $response['text'] = JText::_('Translation could not be saved');
        }

        echo json_encode($response);
    }//function

    /**
     * Deletes a translation.
     *
     * @return void - echoes a JSON encoded string
     */
    function delete_translation()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        $project = EasyProjectHelper::getProject($ecr_project);

        $response = array();

        $response['status'] = 0;

        if( ! $project)
        {
            $response['text'] = JText::sprintf('Unable to load the project %s', $ecr_project);

            echo json_encode($response);
            return;
        }

        //--read vars from request
        $scope = JRequest::getCmd('scope');

        if( ! $scope)
        {
            $response['text'] = JText::_('No scope given');

            echo json_encode($response);
            return;
        }

        if( ! count($project->langs))
        {
            $response['text'] = JText::_('No languages found');

            echo json_encode($response);
            return;
        }

        ecrLoadHelper('language');
        $easyLanguage = new EasyLanguage($project, $scope, array());

        $trans_lang = JRequest::getCmd('trans_lang');
        $trans_key = JRequest::getString('trans_key');

        if($easyLanguage->deleteTranslation($trans_lang, $trans_key))
        {
            $response['status'] = 1;
        }
        else
        {
            $response['text'] = JText::_('Translation could not be deleted');
        }

        echo json_encode($response);
    }//function

    /**
     * Display contents of a log file
     *
     * @return void - echoes a JSON encoded array
     */
    public function show_logfile()
    {
        $response = array();

        $fileName = JRequest::getCmd('file_name');

        if( ! JFile::exists(ECRPATH_LOGS.DS.$fileName))
        {
            $response['status'] = 0;
            $response['message'] = JText::_('File not found');
        }
        else
        {
            $response['status'] = 1;
            $response['message'] = JText::_('File loaded');
            $response['text'] = JFile::read(ECRPATH_LOGS.DS.$fileName);
        }

        echo json_encode($response);
    }//function

    /**
     * Load a file.
     *
     * @return void - echoes a JSON encoded string
     */
    public function loadFile()
    {
        $response = array();
        $response['status'] = 0;
        $response['text'] = '';

        $filePath = JRequest::getVar('file_path');
        $fileName = JRequest::getVar('file_name');

        $path = JPath::clean(JPATH_ROOT.DS.$filePath.DS.$fileName);

        if( ! JFile::exists($path))
        {
            $response['text'] = '<b style="color: red;">'.JText::_('File not found').'</b> - '.$path;
            echo json_encode($response);
            return;
        }

        if( ! $fileContents = JFile::read($path))
        {
            $response['text'] = JText::sprintf('The file %s is empty', str_replace(JPATH_ROOT, 'JPATH_ROOT', $path));
            echo json_encode($response);
            return;
        }

        $response['status'] = 1;
        $response['text'] = $fileContents;

        echo json_encode($response);
    }//function

    /**
     * Load a picture.
     *
     * @return void - echoes a JSON encoded array
     */
    function loadPic()
    {
        $response = array();
        $response['status'] = 0;
        $response['text'] = '';

        $filePath = JRequest::getVar('file_path');
        $fileName = JRequest::getVar('file_name');

        $test = JPath::clean(JPATH_ROOT.DS.$filePath.DS.$fileName);

        if(JFile::exists($test))
        {
            $fileName = JPath::clean($filePath.DS.$fileName);
            $file = JURI::root().'/'.$fileName;

            $response['status'] = 1;
            $response['text'] = JHTML::_('image', $file, 'Image');
        }
        else
        {
            $response['text'] = '<b style="color: red;">'.JText::_('Invalid file').'</b> - '.$test;
        }

        echo json_encode($response);
    }//function

    /**
     *Save a file.
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function saveFile()
    {
        die('ajaxcontroller::savefile');

        $fileName = JRequest::getVar('file_name');

        if( ! $fileName)
        {
            echo JText::_('Empty file name');
            return;
        }

        $fileName = JPath::clean(JPATH_ROOT.DS.$fileName);
        $insertString = JRequest::getVar('c_insertstring', '', 'post', 'string', JREQUEST_ALLOWRAW );

        if( ! $insertString)
        {
            echo JText::_('Empty value');
            return;
        }

        if( ! JFile::exists($fileName))
        {
            echo 'invalid file '.$fileName;
            return;
        }

        if( ! JFile::exists($fileName))
        {
            echo JText::_('The file must exist for save');
            return;
        }

        if( ! JFile::write($fileName, $insertString))
        {
            echo JText::sprintf('The file could NOT be saved at: %s', $fileName);
            return;
        }

        echo '*OK*';
    }//function

    /**
     * Create a new folder.
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function new_folder()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if(JRequest::getCmd('do_action') == 'new_folder')
        {
            $act_path = JRequest::getVar('act_path');
            $act_name = JRequest::getVar('act_name');
            $act_path = str_replace('/', DS, $act_path);
            $path = JPATH_ROOT.DS.$act_path;
            if( ! JFolder::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('Wrong base folder'), $path), 'error');
                return;
            }

            $path .= DS.$act_name;

            if( JFolder::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('The folder already exists'), $path), 'error');
                return;
            }

            if( ! JFolder::create($path))
            {
                ecrHTML::displayMessage(array(JText::_('Unable to create folder'), $path), 'error');
                return;
            }

            //--Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('New folder'), 'add', JText::_('Create'));
        $this->actProcess('new_folder', $ecr_project, 'folder', 'new', true, true);
    }//function

    /**
     * Create a new file.
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function new_file()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if(JRequest::getCmd('do_action') == 'new_file')
        {
            $act_path = JRequest::getVar('act_path');
            $act_name = JRequest::getVar('act_name');
            $path = JPATH_ROOT.DS.$act_path;

            if( ! JFolder::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('Wrong base folder'), $path), 'error');
                return;
            }

            $path .= DS.$act_name;

            if( JFile::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('The file already exists'), $path), 'error');
                return;
            }

            //@todo file from template
            $template = 'new file';

            if( ! JFile::write($path, $template))
            {
                ecrHTML::displayMessage(array(JText::_('Unable to create file'), $path), 'error');
                return;
            }

            //--Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('New file'), 'add', JText::_('Create'));
        $this->actProcess('new_file', $ecr_project, 'file', 'new', true, true);
    }//function

    /**
     * Delete a folder.
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function delete_folder()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if(JRequest::getCmd('do_action') == 'delete_folder')
        {
            if( ! $act_path = JRequest::getVar('act_path'))
            {
                ecrHTML::displayMessage(JText::_('Empty'), 'error');
                return;
            }

            $path = JPATH_ROOT.DS.$act_path;

            if( ! JFolder::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('Folder does not exist'), $path), 'error');
                return;
            }

            if( ! JFolder::delete($path))
            {
                ecrHTML::displayMessage(array(JText::_('Unable to delete folder'), $path), 'error');
                return;
            }

            //--Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('Delete folder'), 'delete', JText::_('Delete'), false);
        $this->actProcess('delete_folder', $ecr_project, 'folder', 'delete');
    }//function

    /**
     * Delete a file
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function delete_file()
    {
        $ecr_project = JRequest::getCmd('ecr_project', NULL);

        if(JRequest::getCmd('do_action') == 'delete_file')
        {
            $act_path = JRequest::getVar('act_path');
            $act_name = JRequest::getVar('act_name');

            if( ! $act_path
            || ! $act_name)
            {
                ecrHTML::displayMessage(JText::_('Empty'), 'error');
                return;
            }

            $path = JPATH_ROOT.DS.$act_path.DS.$act_name;

            if( ! JFile::exists($path))
            {
                ecrHTML::displayMessage(array(JText::_('File does not exist'), $path), 'error');
                return;
            }

            if( ! JFile::delete($path))
            {
                ecrHTML::displayMessage(array(JText::_('Unable to delete file'), $path), 'error');
                return;
            }

            //--Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('Delete file'), 'delete', JText::_('Delete'), false);
        $this->actProcess('delete_file', $ecr_project, 'file', 'delete', true);
    }//function

    /**
     * Rename a folder.
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function rename_folder()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if(JRequest::getCmd('do_action') == 'rename_folder')
        {
            $act_path = JRequest::getVar('act_path');
            $old_name = JRequest::getVar('old_name');
            $act_name = JRequest::getVar('act_name');
            $path = JPATH_ROOT.DS.$act_path;

            if( ! JFolder::exists($path))
            {
                ecrHTML::displayMessage(JText::_('Wrong base folder'), 'error');
                return;
            }

            $ret = JFolder::move($old_name, $act_name, $path);

            if( $ret !== true)
            {
                $ret .= BR.$act_path.BR.$old_name.BR.$act_name;
                ecrHTML::displayMessage($ret, 'error');
                return;
            }

            //-- Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('Rename folder'), 'rename', JText::_('Rename'), true);
        $this->actProcess('rename_folder', $ecr_project, 'folder', 'rename', true);
    }//function

    /**
     * Rename a file
     *
     * @return void - echo *OK* on success | Error message on failure.
     */
    function rename_file()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if(JRequest::getCmd('do_action') == 'rename_file')
        {
            $act_path = JRequest::getString('act_path');
            $old_name = JRequest::getVar('old_name');
            $act_name = JRequest::getVar('act_name');
            $path = JPATH_ROOT.DS.$act_path;

            if( ! JFile::exists($path.DS.$old_name))
            {
                ecrHTML::displayMessage(JText::_('File not found'), 'error');
                return;
            }

            $ret = JFile::move($old_name, $act_name, $path);

            if( $ret !== true)
            {
                ecrHTML::displayMessage($ret, 'error');
                return;
            }

            //-- Clean the cache
            JFactory::getCache('EasyCreator_'.$ecr_project)->clean();

            echo '*OK*';
            return;
        }

        $this->actForm(JText::_('Rename file'), 'rename', JText::_('Rename'), true);
        $this->actProcess('rename_file', $ecr_project, 'file', 'rename', true);
    }//function

    /**
     * Displays a form for right click menu actions (add/edit/delete..).
     *
     * @param $title
     * @param $icon
     * @param $text
     * @param $hasInput
     *
     * @return void
     */
    function actForm($title, $icon, $text, $hasInput=true)
    {
        $inputType =($hasInput) ? 'text' : 'hidden';
        ?>
<style type="text/css">
body {
   background-color: #f3fbe6;
}
</style>
<h2 class="img icon-16-<?php echo $icon; ?>"><?php echo $title ?></h2>
<div
	style="background-color: #FFFF99; border: 1px solid gray; padding: 0.5em;">
<div id="displ_folder" style="display: inline;"></div>
<input type="<?php echo $inputType; ?>" id="act_name" /></div>
<br />
<div style="text-align: center;"><span
	class="ecr_button img icon-16-<?php echo $icon; ?>"
	onclick="actProcess();"> <?php echo $text ?> </span></div>
<div id="log"></div>
<input type="hidden"
	id="act_folder" />
        <?php
    }//function

    /**
     * Handel right click actions
     *
     * @param $task
     * @param $ecr_project
     * @param $type
     * @param $action
     * @param $hasName
     * @param $isNew
     *
     * @return void
     */
    function actProcess($task, $ecr_project, $type, $action, $hasName=false, $isNew=false)
    {
        $baseLink = 'index.php?option=com_easycreator';

        $hrefLink = $baseLink;
        $hrefLink .= '&ecr_project='.JRequest::getCmd('ecr_project');
        $hrefLink .= '&task='.JRequest::getCmd('old_task', 'stuffer');
        $hrefLink .= '&controller='.JRequest::getCmd('old_controller', 'stuffer');

        $ajaxLink = $baseLink.'&tmpl=component&controller=ajax&format=raw';
        $ajaxLink .= '&task='.$task.'&do_action='.$task;
        ?>

<script>
			var FBPresent = true;
			if(window.console == undefined)
			{
				if(window.parent.console != undefined)
				{
					console = window.parent.console;
				}
				else
				{
					FBPresent = false;
				}
			}
			frm = window.parent.document.adminForm;
			path = frm.act_folder.value;
			act_file = frm.act_file.value;
			if(FBPresent) console.log(path);
			if(FBPresent)console.log('act_file '+act_file);

			//-- No dot found in filename - must be a folder @todo
			if( act_file.indexOf('.') === -1 )
			{
				path += '/'+act_file;
				if( FBPresent ) console.log('no dot found - append filename to path - '.path);
			}
			subPath = path.split('/');
			folderName = subPath[subPath.length-1];

			display = path;
<?php
			switch ($type)
			{
				case 'folder':
					switch ($action)
					{
						case 'delete':
							echo "display = path.replace(folderName, '<strong style=\"color: red;\">'+folderName+'</strong>');".NL;
							echo "$('act_name').value = act_file".NL;
							break;

						case 'rename':
							echo "path = path.replace(folderName, '');".NL;
							echo "display = path;".NL;
							echo "$('act_name').value = act_file".NL;
							break;

						default:
							;
						break;
					}//switch
				break;

				case 'file':
					switch ($action)
					{
						case 'delete':
							echo "display = path+'".DS."<strong style=\"color: red;\">'+act_file+'</strong>';".NL;
							echo "$('act_name').value = act_file".NL;
						break;

						case 'rename':
							echo "$('act_name').value = act_file".NL;
						break;

						default:
							;
						break;
					}//switch
				break;

				default:
					;
				break;
			}//switch
			?>

			$('displ_folder').innerHTML = display;
			$('act_folder').value = path;

			function actProcess()
			{
				post = '';
				post += '&act_path='+$('act_folder').value;
				post += '&ecr_project=<?php echo $ecr_project; ?>';

				uri = '<?php echo $ajaxLink; ?>'+post;

				act_name = $('act_name').value;
				post += '&act_name='+act_name;
				<?php
				if($action == 'rename')
				{
					echo "post += '&old_name='+window.parent.document.adminForm.act_file.value;";
				}

				if($hasName)
				{
					?>
					if( ! act_name)
					{
						$('act_name').setStyle('background-color', 'red');

						return false;
					}
					<?php
				}
				?>

				new Ajax( uri,
				{
					'postBody': post,
					'onComplete': function(result)
					{
						if(result == '*OK*')
						{
							window.parent.location = '<?php echo $hrefLink; ?>';
						}
						else
						{
							$('log').innerHTML = result;
						}
					}
				}).request();
			}//function
		</script>
				<?php
    }//function

    /**
     * Format a file name.
     *
     * @return void
     * @todo error handling
     */
    function update_project_name()
    {
        $project = EasyProjectHelper::getProject(JRequest::getCmd('ecr_project', 'post'));

        $formatted = EasyProjectHelper::formatFileName($project, JRequest::getVar('cst_format', 'post'));

        echo $formatted;
    }//function

    /**
     * Dislays the fields of a given table in a <select> box.
     *
     * @return void - echoes a JSON encoded array
     */
    function get_table_field_selector()
    {
        $response = array();
        $table = JRequest::getCmd('table');
        $fieldName = JRequest::getCmd('field_name');

        if( ! $table)
        {
            $response['text'] = '';
        }
        else
        {
            $db = JFactory::getDBO();
            $dbTables = $db->getTableList();
            $dbPrefix = $db->getPrefix();

            if( ! in_array($dbPrefix.$table, $dbTables))
            {
                $response['text'] = 'Invalid table';
            }
            else
            {
                $fields = $db->getTableFields($dbPrefix.$table);

                $fields = $fields[$dbPrefix.$table];

                $out = '';
                $out .= '<select name="'.$fieldName.'">';
                $out .= '<option value="">'.JText::_('Select...').'</option>';

                foreach (array_keys($fields) as $fieldName)
                {
                    $out .= '<option>'.$fieldName.'</option>';
                }//foreach

                $out .= '</select>';
                $response['text'] = $out;
                $response['status'] = 1;
            }
        }

        echo json_encode($response);
    }//function

}//class
