<?php
/**
 * @version SVN: $Id: ziper.php 1146 2010-03-30 19:35:55Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 24-Sep-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerZIPer extends JController
{
    /**
     * Constructor.
     *
     * @param array $config Configuration.
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }// function

    /**
     * Standard display method.
     */
    function display()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        if( ! $ecr_project)
        {
            //---NO PROJECT SELECTED - ABORT
            ecrHTML::easyFormEnd();
            return;
        }

        JRequest::setVar('view', 'ziper');

        parent::display();
    }//function

    function zipdir()
    {
        JRequest::setVar('view', 'ziper');

        parent::display();
    }//function

    /**
     * Delete a zip file.
     */
    function delete()
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        ecrLoadHelper('file');
        $file = new EasyFile();

        $ret = $file->deleteFile();

        if($ret === true)
        {
            JFactory::getApplication()->enqueueMessage(JText::_('The file has been deleted'));
        }
        else
        {
            JError::raiseWarning(100, $ret);
        }

        JRequest::setVar('view', 'ziper');

        parent::display();
    }// function

}//class
