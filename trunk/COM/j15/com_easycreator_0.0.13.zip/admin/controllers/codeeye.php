<?php
/**
 * @version SVN: $Id: codeeye.php 1218 2010-05-29 04:28:27Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 28-Sep-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerCodeEye extends JController
{
    /**
     * Constructor.
     *
     * @param array $config
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }//function

    function display()
    {
        JRequest::setVar('view', 'codeeye');

        parent::display();
    }// function

    /**
     * Copy the bootstrap.php for UnitTests to the Joomla! root.
     *
     * @return void
     */
    public function copy_bootstrap()
    {
        if(JFile::copy(JPATH_COMPONENT.DS.'helpers'.DS.'bootstrap.php', JPATH_ROOT.DS.'bootstrap.php'))
        {
            ecrHTML::displayMessage(JText::_('The file bootstrap.php has been copied to your Joomla root'));
        }
        else
        {
            ecrHTML::displayMessage(JText::sprintf('Can not copy file %s', 'bootstrap.php'), 'error');
        }

        JRequest::setVar('view', 'codeeye');
        JRequest::setVar('task', 'phpunit');

        parent::display();
    }//function

    public function create_test_dir_unit()
    {
    	$this->create_test_dir('unit');
        JRequest::setVar('task', 'phpunit');
    	parent::display();
    }//function

    public function create_test_dir_selenium()
    {
    	$this->create_test_dir('system');
        JRequest::setVar('task', 'selenium');
    	parent::display();
    }//function

    /**
     * Creates a test directory for UnitTests.
     *
     * @return void
     */
    private function create_test_dir($type)
    {
        $ecr_project = JRequest::getCmd('ecr_project');

        JRequest::setVar('view', 'codeeye');

        if( ! $ecr_project)
        {
            ecrHTML::displayMessage(JText::_('No project selected'), 'error');

            return;
        }

        if( ! JFolder::exists(JPATH_ADMINISTRATOR.DS.'components'.DS.$ecr_project))
        {
            ecrHTML::displayMessage(JText::_('Invalid project'), 'error');

            return;
        }

        if( ! JFolder::create(JPATH_ADMINISTRATOR.DS.'components'.DS.$ecr_project.DS.'tests'.DS.$type))
        {
            ecrHTML::displayMessage(JText::_('Unable to create tests directory'), 'error');

            return;
        }

        ecrHTML::displayMessage(JText::_('The tests directory has been created'));
    }//function

}//class
