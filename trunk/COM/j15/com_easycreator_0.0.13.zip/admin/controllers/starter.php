<?php
/**
 * @version SVN: $Id: starter.php 1219 2010-05-30 02:59:41Z elkuku $
 * @package    EasyCreator
 * @subpackage Controllers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 23-Sep-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.application.component.controller');

/**
 * EasyCreator Controller
 *
 * @package    EasyCreator
 * @subpackage Controllers
 */
class EasyCreatorControllerStarter extends JController
{
    /**
     * Constructor.
     *
     * @param array $config Configuration.
     */
    function __construct($config = array())
    {
        parent::__construct($config);
    }// function

    /**
     * Standard display method.
     */
    function display()
    {
        JRequest::setVar('view', 'starter');

        parent::display();
    }// function

    /**
     * Build a new Joomla! extension from request.
     *
     * @return mixed Redirect on success | boolean false on error
     */
    public function starterstart()
    {
        ecrLoadHelper('builder');
        $EasyBuilder = new EasyBuilder();

        $type = JRequest::getCmd('tpl_type');
        $name = JRequest::getCmd('tpl_name');
        $comName = JRequest::getCmd('com_name');

        if( ! $newProject = $EasyBuilder->build($type, $name, $comName))
        {
            //-- Error
            ecrHTML::displayMessage('An error happened while creating your project', 'error');
            JError::raiseWarning(100, JText::_('An error happened while creating your project'));
            $EasyBuilder->printErrors();

            ecrHTML::easyFormEnd();

            return false;
        }

        if(JRequest::getCmd('ecr_test_mode') == 'test')
        {
            //-- Exiting in test mode
            echo '<h2>Exiting in test mode...</h2>';

            echo $EasyBuilder->printLog();

            $EasyBuilder->printErrors();

            ecrHTML::easyFormEnd();

            return true;
        }

        $ecr_project = JFile::stripExt($newProject->getEcrXmlFileName());

        $uri = 'index.php?option=com_easycreator&controller=stuffer&ecr_project='.$ecr_project;

        $this->setRedirect($uri, JText::_('Your project has been created'));
    }//function

    /**
     * Register a Joomla! extension as an EasyCreator project.
     *
     * @return mixed Redirect on success | boolean false on error
     */
    public function register_project()
    {
        ecrLoadHelper('builder');
        $EasyBuilder = new EasyBuilder();

        $type = JRequest::getCmd('ecr_project_type');
        $name = JRequest::getCmd('ecr_project_name');
        $scope = JRequest::getCmd('ecr_project_scope');

        if( ! $project = $EasyBuilder->registerProject($type, $name, $scope))
        {
            //-- Error
            JError::raiseWarning(100, 'Can not register project');
            $EasyBuilder->printErrors();

            ecrHTML::easyFormEnd();

            return false;
        }

        $ecr_project = JFile::stripExt($project->getEcrXmlFileName());

        $uri = 'index.php?option=com_easycreator&controller=stuffer&ecr_project='.$ecr_project;

        $this->setRedirect($uri, JText::_('Your project has been registered'));
    }//function

    /**
     * ! AJAX called.
     * Get extended Information for an extension temlate.
     *
     * @return string JSON encoded
     */
    public function ajGetExtensionTemplateInfo()
    {
        ecrLoadHelper('php_file_tree');

        $jsFile = '';//"onclick=\"alert('HU');\"";
        $fileTree = new phpFileTree('', '', $jsFile, '');

        $extType = JRequest::getCmd('extType');
        $folder = JRequest::getCmd('folder');

        $response = array();
        $response['status'] = 0;
        $response['text'] = '';

        if( ! $extType || ! $folder)
        {
            $response['text'] = 'Invalid options';

            echo json_encode($response);

            return;
        }

        $dir = ECRPATH_EXTENSIONTEMPLATES.DS.$extType.DS.$folder;

        $folders = JFolder::folders($dir, '.', false, true, array('.svn'));

        foreach ($folders as $folder)
        {
            $fileTree->setDir($folder);
            $response['text'] .= $fileTree->drawFullTree();
        }//foreach

        $response['status'] = 1;

        echo json_encode($response);
    }//function

}//class
