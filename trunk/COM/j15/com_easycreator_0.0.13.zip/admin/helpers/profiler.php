<?php
/**
 * @version SVN: $Id: profiler.php 1137 2010-03-26 23:34:20Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 20-Oct-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

jimport('joomla.error.profiler');

/**
 * EasyProfiler.
 *
 * @package EasyCreator
 */
class EasyProfiler extends JProfiler
{
    /**
     * Constructor.
     *
     * @param string $prefix
     */
    public function __construct($prefix='')
    {
        parent::__construct($prefix);
    }//function

    /**
     * Returns a reference to the global Profiler object, only creating it
     * if it doesn't already exist.
     *
     * This method must be invoked as:
     * 		<pre>  $profiler = EasyProfiler::getInstance( $prefix );</pre>
     *
     * @param string $prefix Prefix used to distinguish profiler objects.
     * @return object EasyProfiler The Profiler object.
     */
    public static function &getInstance($prefix = '')
    {
        static $instances;

        if( ! isset($instances) )
        {
            $instances = array();
        }

        if( empty($instances[$prefix]) )
        {
            $instances[$prefix] = new EasyProfiler($prefix);
        }

        return $instances[$prefix];
    }//function

    /**
     * Output a time mark
     *
     * The mark is returned as text enclosed in yellow <span> tags.
     *
     * @param string A label for the time mark
     * @return string Mark enclosed in <div> tags
     */
    public function mark($label)
    {
        $current = self::getmicrotime() - $this->_start;

        if (function_exists('memory_get_usage'))
        {
            $current_mem = memory_get_usage() / 1048576;
            $mark = sprintf(
                '<span style="background-color: yellow;">%.3f sec (+%.3f); %0.2f Mb (+%0.2f)</span> - ',
                $current,
                $current - $this->_previous_time,
                $current_mem,
                $current_mem - $this->_previous_mem
            );
        }
        else
        {
            $mark = sprintf(
                '<span style="background-color: yellow;">%.3f sec (+%.3f)</span> - ',
                $current,
                $current - $this->_previous_time
            );
        }

        $this->_previous_time = $current;
        $this->_previous_mem = $current_mem;
        $this->_buffer[] = $mark;

        return $mark;
    }//function

}//class
