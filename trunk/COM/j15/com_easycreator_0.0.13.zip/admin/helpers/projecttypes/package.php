<?php
/**
 * @version SVN: $Id: package.php 1221 2010-05-31 19:00:50Z elkuku $
 * @package    EasyCreator
 * @subpackage ProjectTypes
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 29-Mar-2010
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

class EasyProjectPackage extends EasyProject
{
    /**
     * Project type.
     *
     * @var string
     */
    public $type = 'package';

    /**
     * Project prefix.
     *
     * @var string
     */
    public $prefix = 'pkg_';

    /**
     * Project elements.
     *
     * @var string
     */
    public $elements = array();

    /**
     * Constructor.
     *
     * @param string $name Project name.
     */
    public function __construct($name)
    {
        parent::__construct($name);
    }//function

    /**
     * Get the path for the Joomla! XML manifest file.
     *
     * @return string
     */
    public function getJoomlaManifestPath()
    {
        return JPATH_MANIFESTS.DS.'packages';
    }//function

    /**
     * Get a Joomla! manifest XML file name.
     *
     * @return string File name.
     */
    public function getJoomlaManifestName()
    {
        return $this->comName.'.xml';
    }//function

    /**
     * Get a file name for a EasyCreator setup XML file.
     *
     * @return string
     */
    public function getEcrXmlFileName()
    {
        return $this->comName.'.xml';
    }//function

    /**
     * Find all files and folders belonging to the project.
     * @todo changes in 1.6
     *
     * @return array
     */
    public function findCopies()
    {
        return array();
    }//function

}//class
