<?php
/**
 * @version SVN: $Id: empty.php 1212 2010-05-26 20:13:35Z elkuku $
 * @package    EasyCreator
 * @subpackage ProjectTypes
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 26.05.2010
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

/**
 * Empty project for creating new projects.
 */
class EasyProjectEmpty extends EasyProject {}//class