<?php
/**
 * @version SVN: $Id: debug.php 1221 2010-05-31 19:00:50Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 23-May-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//--No direct access
defined('_JEXEC') or die('=;)');

class ecrDebugger
{

    public $log = array();

    function __construct()
    {

    }//function

    public static function dPrint($string, $title = '')
    {
        //-- Test if JDump is installed
        if(file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_dump'.DS.'helper.php'))
        {
            dump($string, $title);
        }
        else
        {
            //-- It's not ;(
            $html = '';
            $html .= '<div class="debugprint">';
            $html .=($title) ? '<h2>'.$title.'</h2>': '';
            $html .= '<pre>';
            $html .= $string;
            $html .= '</pre>';
            $html .= '</div>';
            echo $html;
        }
    }//function

    public static function dEcho($string)
    {
        echo '<span style="background-color: yellow;">'.$string.'</span>';
    }//function

    public static function printSysVars($type='all')
    {
        //-- Get debugger type
        $debug_type = JComponentHelper::getParams('com_easycreator')->get('ecr_debug_type', 'easy');

        switch($debug_type)
        {
            case 'jdump':
                //--Test if JDump is installed
                if( ! file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_dump'.DS.'helper.php'))
                {
                    ecrHTML::displayMessage(JText::_('JDump not found'), 'error');
                }
                else
                {
                    switch($type)
                    {
                        case 'get':
                            dump($_GET, 'GET');
                            break;

                        case 'post':
                            dump($_POST, 'POST');
                            break;

                        case 'request':
                            dump($_REQUEST, 'REQUEST');
                            break;

                        case 'backTrace':
                            dumpBacktrace();
                            break;

                        case 'sysInfo':
                        default:
                            dumpSysinfo();
                            break;
                    }//switch
                }

            case 'easy':
                include_once 'Var_Dump.php';

                if(class_exists('Var_Dump'))
                {
                    Var_Dump::displayInit(
                    array('display_mode' => 'HTML4_Table')
                    , array(
                        'show_caption'   => FALSE,
                        'bordercolor'    => '#ccc',
                        'bordersize'     => '2',
                        'captioncolor'   => 'black',
                        'cellpadding'    => '8',
                        'cellspacing'    => '5',
                        'color1'         => '#000',
                        'color2'         => '#000',
                        'before_num_key' => '<span style="color: #fff; font-weight: bold;">',
                        'after_num_key'  => '</span>',
                        'before_str_key' => '<span style="color: #5450cc; font-weight: bold;">',
                        'after_str_key'  => '</span>',
                        'before_value'   => '<span style="color: #5450cc;">',
                        'after_value'    => '</span>'
                        )
                        );

                        echo '<div class="ecr_debug">';

                        switch($type)
                        {
                            case 'get':
                                echo '<h3><tt>$_GET</tt></h3>';
                                Var_Dump::display($_GET);
                                break;
                            case 'post':
                                echo '<h3><tt>$_POST</tt></h3>';
                                Var_Dump::display($_POST);
                                break;
                            case 'request':
                                echo '<h3><tt>$_REQUEST</tt></h3>';
                                Var_Dump::display($_REQUEST);
                                break;
                        }//switch
                        echo '</div>';
                }
                else
                {
                    echo '<div class="ecr_debug"><pre>';
                    print_r($_REQUEST);
                    echo '</pre></div>';
                }
                break;

            case 'debugtools':
                ecrHTML::displayMessage(JText::_('DebugTools not found'), 'error');
                break;

            case 'krumo' :
                ecrLoadHelper('krumo_0_2.krumo');

                switch($type)
                {
                    case 'get':
                        krumo::get();
                        break;
                    case 'post':
                        krumo::post();
                        break;
                    case 'request':
                        krumo::request();
                        break;
                }//switch

                break;

            default:
                ecrHTML::displayMessage(JText::_('No debugger set'), 'error');
                break;
        }//switch

    }//function

    public static function addLog($string)
    {
        $this->log[] = $string;
    }//function

    public static function printLog()
    {
        $html = '';
        $html .= '<hr />';
        $html .= '<h3>LoG</h3>';
        $html .='<ul class="loglist">';

        foreach($this->log as $logentry)
        {
            $html .= '<li>'.$logentry.'</li>';
        }//foreach

        $html .= '</ul>';
        $html .= '<hr />';

        echo $html;
    }//function

    /**
     * Dumps a var with PEAR::Var_Dump.
     *
     * @param string $var
     * @param string $title
     */
    public static function varDump($var, $title='')
    {
        echo ($title) ? '<h3><tt>'.$title.'</tt></h3>' : '';

        $debug_type = JComponentHelper::getParams('com_easycreator')->get('ecr_debug_type', 'easy');

        if($debug_type == 'krumo')
        {
            ecrLoadHelper('krumo_0_2.krumo');

            krumo::dump($var);

            return;
        }

        include_once 'Var_Dump.php';


        if(class_exists('Var_Dump'))
        {
            Var_Dump::displayInit(
            array('display_mode' => 'HTML4_Table')
            , array(
                'show_caption'   => FALSE,
                'bordercolor'    => '#ccc',
                'bordersize'     => '2',
                'captioncolor'   => 'black',
                'cellpadding'    => '8',
                'cellspacing'    => '5',
                'color1'         => '#000',
                'color2'         => '#000',
                'before_num_key' => '<span style="color: #fff; font-weight: bold;">',
                'after_num_key'  => '</span>',
                'before_str_key' => '<span style="color: #5450cc; font-weight: bold;">',
                'after_str_key'  => '</span>',
                'before_value'   => '<span style="color: #5450cc;">',
                'after_value'    => '</span>'
                )
                );

                Var_Dump::display($var);
        }
        else
        {
            echo '<pre>'.print_r($var, true).'</pre>';
        }
    }//function

}//class
