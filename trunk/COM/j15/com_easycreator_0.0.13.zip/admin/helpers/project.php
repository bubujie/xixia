<?php
/**
 * @version SVN: $Id: project.php 1221 2010-05-31 19:00:50Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 10-Mar-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Project definitions.
 */
abstract class EasyProject extends JObject
{
    public $legacy = false;//removed in 1.6
    public $method = '';
    public $JCompat = '1.5';
    public $phpVersion = '4';
    public $fromTpl = '';

    public $dbId = 0;

    public $name = '';
    public $comName = '';
    public $scope = '';
    public $group = '';

    public $version = '';
    public $description = '';
    public $author = '';
    public $authorEmail = '';
    public $authorUrl = '';
    public $license = '';
    public $copyright = '';
    public $creationDate = '';

    public $menu = array('text' => '', 'link' => '', 'img' => '', 'menuid' => '');
    public $submenu = array();

    public $langs = array();

    public $modules = array();
    public $plugins = array();
    public $tables = array();
    public $autoCodes = array();

    public $listPostfix = 'List';

    public $entryFile = '';

    public $copies = array();

    public $buildPath = false;

    public $buildOpts = array();

    private $_substitutes = array();

    private $basePath = '';

    /**
     * Constructor.
     *
     * @param string $name Project name.
     */
    public function __construct($name = '')
    {
        ecrLoadHelper('languagehelper');

        if( ! $name
        || ! $this->readProjectXml($name))
        {
            return;
        }

        $this->copies = $this->findCopies();
        $this->langs = EasyLanguageHelper::discoverLanguages($this);
        if($this->type == 'component') $this->readMenu();
        $this->readJoomlaXml();
        $this->dbId = $this->getId();
    }//function

    public function findCopies() {}//function

    public function getLanguageScopes() {}//function
    public function getLanguagePaths() {}//function
    public function getLanguageFileName() {}//function
    public function getJoomlaManifestPath() {}//function
    public function getJoomlaManifestName() {}//function
    public function getDTD($jVersion) {}//function
    public function getEcrXmlFileName() {}//function
    public function getId() {}//function

    /**
     * Get the credits from XML file
     *
     * @param string $xmlFileName full path
     * @return mixed JObject / false on error
     */
    private function readJoomlaXml()
    {
        $fileName = EasyProjectHelper::findManifest($this);

        if($data = EasyProjectHelper::parseXMLInstallFile(JPATH_ROOT.DS.$fileName))
        {
            foreach($data as $key => $value)
            {
                $this->$key = $value;
            }//foreach

            return true;
        }

        return false;
    }//function

    public function update($testMode = false)
    {
        return $this->writeProjectXml($testMode);
    }

    /**
     * This will update the config file.
     *
     * @return boolean true on success
     */
    public function updateProjectFromRequest()
    {
        $buildVars = JRequest::getVar('buildvars', array());
        $buildOpts = JRequest::getVar('buildopts', array());

        if( ! $this->type)
        {
            JError::raiseWarning(100, JText::_('Unable to load project %s', $ecr_project));

            return false;
        }

        //--Package modules
        $this->modules = array();
        $items = JRequest::getVar('package_module', array(), 'post');

        foreach($items as $item)
        {
            $m = new stdClass();
            $m->scope = $item['client'];
            $m->name = $item['name'];
            $m->title = $item['title'];
            $m->position = $item['position'];
            $m->ordering = $item['ordering'];

            $this->modules[] = $m;
        }//foreach

        //--Package plugins
        $this->plugins = array();
        $items = JRequest::getVar('package_plugin', array(), 'post');

        foreach($items as $item)
        {
            $m = new stdClass();
            $m->name = $item['name'];
            $m->title = $item['title'];
            $m->scope = $item['client'];
            $m->ordering = $item['ordering'];

            $this->plugins[] = $m;
        }//foreach

        $packageElements = (array)JRequest::getVar('package_elements');

        if(count($packageElements))
        {
            $this->elements = $packageElements;
        }

        //-- Process credit vars
        foreach($buildVars as $name => $var)
        {
            if(property_exists($this, $name))
            {
                $this->$name = $var;
            }

        }//foreach

        //-- Method special treatment for checkboxes
        $this->method =(isset($buildVars['method'])) ? $buildVars['method'] : '';

        //-- Build options
        $this->buildOpts['archive_zip'] =(in_array('archive_zip', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['archive_tgz'] =(in_array('archive_tgz', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['archive_bz2'] =(in_array('archive_bz2', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['create_indexhtml'] =(in_array('create_indexhtml', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['create_md5'] =(in_array('create_md5', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['include_ecr_projectfile'] =(in_array('include_ecr_projectfile', $buildOpts)) ? 'ON' : 'OFF';
        $this->buildOpts['remove_autocode'] =(in_array('remove_autocode', $buildOpts)) ? 'ON' : 'OFF';

        $this->JCompat = JRequest::getString('jcompat');

        if( ! $this->writeProjectXml())
        {
            JError::raiseWarning(100, JText::_('Can not update EasyCreator manifest'));

            return false;
        }

        if( ! $this->writeJoomlaManifest())
        {
            JError::raiseWarning(100, JText::_('Can not update Joomla manifest'));

            return false;
        }

        if( ! $this->updateAdminMenu())
        {
            JError::raiseWarning(100, JText::_('Can not update Admin menu'));

            return false;
        }

        return true;
    }//function

    /**
     *
     */
    private function writeJoomlaManifest()
    {
        $installXML = EasyProjectHelper::findManifest($this);

        $xmlBuildVars = array(
        'version'
        , 'description'
        , 'author'
        , 'authorEmail'
        , 'authorUrl'
        , 'license'
        , 'copyright'
        );

        $manifest = EasyProjectHelper::getXML(JPATH_ROOT.DS.$installXML);

        if( ! $manifest)// = simplexml_load_file(JPATH_ROOT.DS.$installXML))
        {
            JError::raiseWarning(100, JText::sprintf('Can not load xml file %s', $installXML));

            return false;
        }

        if($this->method)
        {
            if($manifest->attributes()->method)
            {
                $manifest->attributes()->method = $this->method;
            }
            else
            {
                $manifest->addAttribute('method', $this->method);
            }
        }
        else
        {
            if($manifest->attributes()->method)
            {
                $manifest->attributes()->method = '';
            }
        }

        //--Process credit vars
        foreach ($xmlBuildVars as $xmlName)
        {
            $manifest->$xmlName = $this->$xmlName;
        }//foreach

//        $doc = new DOMDocument('1.0', 'utf-8');
//        $doc->formatOutput = true;
//        $domnode = dom_import_simplexml($manifest);
//        $domnode = $doc->importNode($domnode, true);
//        $domnode = $doc->appendChild($domnode);

        //--Write XML file to disc
        #if( ! JFile::write(JPATH_ROOT.DS.$installXML, $doc->saveXML()))
        if( ! JFile::write(JPATH_ROOT.DS.$installXML, $manifest->asFormattedXML()))
        {
            JError::raiseWarning(100, JText::_('Unable to write file'));
            JError::raiseWarning(100, JPATH_ROOT.DS.$installXML);

            return false;
        }

        if(ECR_DEBUG)
        {
            #$screenOut = $doc->saveXML();
            $screenOut = $manifest->asFormattedXML();
            $screenOut = str_replace('<', '&lt;', $screenOut);
            $screenOut = str_replace('>', '&gt;', $screenOut);
            echo '<div class="ecr_debug">';
            echo '<pre>'.$screenOut.'</pre>';
            echo '</div>';
        }

        return true;
    }// function

    /**
     * Updates the administration main menu
     */
    private function updateAdminMenu()
    {
        if(ECR_JVERSION == '1.6')
        {
            JError::raiseNotice(100, 'Admin menus are still strange in J! 1.6 - not saving..');

            return true;
        }

        $menu = JRequest::getVar('menu', array());

        if(isset($menu['text']) && $menu['text'])
        {
            $menu['ordering'] = 0;
            $this->setDbMenuItem($menu);
        }

        //--Submenu
        $submenu = JRequest::getVar('submenu', array());

        foreach ($submenu as $menu)
        {
            if(isset($menu['text']) && $menu['text'])
            {
                $this->setDbMenuItem($menu);
            }
        }//foreach

        return true;
    }//function

    /**
     * Updates the EasyCreator configuration file for the project.
     *
     * @param boolean $testMode if set to 'true' xml file will be generated but not written to disk
     *
     * @return mixed [string xml string on success | boolean false on error]
     */
    public function writeProjectXml($testMode = false)
    {
        $type = 'type="'.$this->type.'" ';
        $scope =($this->scope) ? 'scope="'.$this->scope.'" ' : '';

        $xml = new SimpleXMLElement('<easyproject '.$type.$scope.' version="'.ECR_VERSION.'" tpl="'.$this->fromTpl.'"/>');

        $xml->addChild('name', $this->name);
        $xml->addChild('comname', $this->comName);
        $xml->addChild('JCompat', $this->JCompat);

        //-- Package Modules
        if(count($this->modules))
        {
            $modsElement = $xml->addChild('modules');

            foreach ($this->modules as $module)
            {
                $modElement = $modsElement->addChild('module');
                $modElement->addAttribute('name', $module->name);
                $modElement->addAttribute('title', $module->title);

                if($module->scope)
                {
                    $modElement->addAttribute('scope', $module->scope);
                }

                if($module->position)
                {
                    $modElement->addAttribute('position', $module->position);
                }

                if($module->ordering)
                {
                    $modElement->addAttribute('ordering', $module->ordering);
                }
            }//foreach
        }

        //-- Package Plugins
        if(count($this->plugins))
        {
            $modsElement = $xml->addChild('plugins');

            foreach ($this->plugins as $plugin)
            {
                $modElement = $modsElement->addChild('plugin');
                $modElement->addAttribute('name', $plugin->name);
                $modElement->addAttribute('title', $plugin->title);

                if($plugin->scope)
                {
                    $modElement->addAttribute('scope', $plugin->scope);
                }

                if($plugin->ordering)
                {
                    $modElement->addAttribute('ordering', $plugin->ordering);
                }
            }//foreach
        }

        //-- Tables
        if(count($this->tables))
        {
            $tablesElement = $xml->addChild('tables');

            foreach($this->tables as $table)
            {
                $tableElement = $tablesElement->addChild('table');
                $tableElement->addChild('name', $table->name);

                if($table->getRelations())
                {
                    $relsElement = $tableElement->addChild('relations');

                    foreach($table->getRelations() as $relation)
                    {
                        $relElement = $relsElement->addChild('relation');

                        $relElement->addChild('type', $relation->type);
                        $relElement->addChild('field', $relation->field);
                        $relElement->addChild('onTable', $relation->onTable);
                        $relElement->addChild('onField', $relation->onField);

                        $aliasesElement = $relElement->addChild('aliases');

                        foreach($relation->aliases as $alias)
                        {

                            $aliasElement = $aliasesElement->addChild('alias');

                            $aliasElement->addChild('name', $alias->alias);
                            $aliasElement->addChild('field', $alias->aliasField);
                        }//foreach
                    }//foreach
                }
            }//foreach
        }

        //-- AutoCodes
        if(count($this->autoCodes))
        {
            $autoCodesElement = $xml->addChild('autoCodes');

            foreach($this->autoCodes as $autoCode)
            {
                $autoCodeElement = $autoCodesElement->addChild('autoCode');
                $autoCodeElement->addAttribute('scope', $autoCode->scope);
                $autoCodeElement->addAttribute('group', $autoCode->group);
                $autoCodeElement->addAttribute('name', $autoCode->name);
                $autoCodeElement->addAttribute('element', $autoCode->element);

                if(count($autoCode->options))
                {
                    $optionsElement = $autoCodeElement->addChild('options');

                    foreach ($autoCode->options as $key => $option)
                    {
                        $option = (string)$option;
                        $optionElement = $optionsElement->addChild('option', $option);
                        $optionElement->addAttribute('name', $key);
                    }//foreach
                }

                if(count($autoCode->fields))
                {
                    foreach ($autoCode->fields as $key => $fields)
                    {
                        $fieldsElement = $autoCodeElement->addChild('fields');
                        $fieldsElement->addAttribute('key', $key);

                        foreach ($fields as $field)
                        {
                            $fieldElement = $fieldsElement->addChild('field');

                            $oVars = get_object_vars($field);

                            $k = $oVars['name'];

                            $fieldElement->addAttribute('name', $k);

                            foreach ($oVars as $oKey => $oValue)
                            {
                                if( ! $oValue) continue;

                                $fieldElement->addChild($oKey, $oValue);
                            }//foreach
                        }//foreach
                    }//foreach
                }
            }//foreach
        }

        if($this->type == 'package')
        {
            //-- J! 1.6 Package
        	$filesElement = $xml->addChild('elements');

        	foreach($this->elements as $element)
        	{
        		$filesElement->addChild('element', $element->name);
        	}//foreach
        }

        //-- Buildopts
        if(count($this->buildOpts))
        {
            $buildElement = $xml->addChild('buildoptions');

            foreach($this->buildOpts as $k => $opt)
            {
                $buildElement->addChild($k, $opt);
            }//foreach
        }

        $doc = new DOMDocument('1.0', 'utf-8');
        $doc->formatOutput = true;
        $domnode = dom_import_simplexml($xml);
        $domnode = $doc->importNode($domnode, true);
        $domnode = $doc->appendChild($domnode);

        if(ECR_DEBUG) echo '<pre>'.htmlentities($doc->saveXML()).'</pre>';

        $path = ECRPATH_SCRIPTS.DS.$this->getEcrXmlFileName();

        if( ! $testMode)
        {
            if( ! JFile::write(JPath::clean($path), $doc->saveXML()))
            {
                $this->setError('Could not save XML file!');

                return false;
            }
        }

        return $doc->saveXML();
    }//function

    /**
     *
     * @param $project
     * @return unknown_type
     */
    private function readProjectXml($projectName)
    {
        ecrLoadHelper('table');

        $fileName = ECRPATH_SCRIPTS.DS.$projectName.'.xml';

        if( ! JFile::exists($fileName))
        {
            JError::raiseWarning(100, JText::_('Project manifest not found'));

            return false;
        }

        $manifest = simplexml_load_file($fileName);

        if( ! $manifest instanceof SimpleXMLElement
        || $manifest->getName() != 'easyproject')
        {
            JError::raiseWarning(100, JText::_('Invalid project manifest'));

            return false;
        }

        $this->type = (string)$manifest->attributes()->type;
        $this->scope = (string)$manifest->attributes()->scope;
        $this->name = (string)$manifest->name;
        $this->comName = (string)$manifest->comname;
        $this->JCompat = ((string)$manifest->JCompat) ? (string)$manifest->JCompat : '1.5';

        $this->fromTpl = (string)$manifest->attributes()->tpl;

        /*
         * Modules
         */
        if(isset($manifest->modules->module))
        {
            foreach ($manifest->modules->module as $e)
            {
                $c = new stdClass();

                foreach ($e->attributes() as $k => $a)
                {
                    $c->$k = (string)$a;
                }//foreach

                $c->scope = (string)$e->attributes()->scope;
                $c->position = (string)$e->attributes()->position;
                $c->ordering = (string)$e->attributes()->ordering;

                $this->modules[] = $c;
            }//foreach
        }

        /*
         * Plugins
         */
        if(isset($manifest->plugins->plugin))
        {
            foreach ($manifest->plugins->plugin as $e)
            {
                $c = new stdClass();

                foreach ($e->attributes() as $k => $a)
                {
                    $c->$k = (string)$a;
                }//foreach

                $c->scope = (string)$e->attributes()->scope;
                $c->ordering = (string)$e->attributes()->ordering;

                $this->plugins[] = $c;
            }//foreach
        }

        /*
         * Tables
         */
        if(isset($manifest->tables->table))
        {
            foreach ($manifest->tables->table as $e)
            {
                $table = new EasyTable((string)$e->name);

                $t = new stdClass();
                $t->name = (string)$e->name;

                if(isset($e->relations->relation))
                {
                    foreach ($e->relations->relation as $r)
                    {
                        $relation = new EasyTableRelation();
                        $relation->type = (string)$r->type;
                        $relation->field = (string)$r->field;
                        $relation->onTable = (string)$r->onTable;
                        $relation->onField = (string)$r->onField;

                        if(isset($r->aliases->alias))
                        {
                            foreach ($r->aliases->alias as $elAlias)
                            {
                                $alias = new EasyTableRelationAlias();
                                $alias->alias = (string)$elAlias->name;
                                $alias->aliasField = (string)$elAlias->field;

                                $relation->addAlias($alias);
                            }//foreach
                        }

                        $table->addRelation($relation);
                    }//foreach
                    $t->relations = $e->relations;
                }
                else
                {
                    $t->relations = array();
                }

                $this->tables[$table->name] = $table;
            }//foreach
        }

        /*
         * AutoCodes
         */
        if(isset($manifest->autoCodes->autoCode))
        {
            ecrLoadHelper('autocode');
            ecrLoadHelper('table');

            foreach ($manifest->autoCodes->autoCode as $code)
            {
                $group = (string)$code->attributes()->group;
                $name = (string)$code->attributes()->name;
                $element = (string)$code->attributes()->element;
                $scope = (string)$code->attributes()->scope;

                $key = "$scope.$group.$name.$element";

                $EasyAutoCode = EasyProjectHelper::getAutoCode($key);

                if( ! $EasyAutoCode)
                {
                    continue;
                }

                if(isset($code->options->option))
                {
                    foreach($code->options->option as $o)
                    {
                        $option = (string)$o;
                        $k = (string)$o->attributes()->name;
                        $EasyAutoCode->options[$k] = (string)$option;
                    }//foreach
                }

                if(isset($code->fields))
                {
                    foreach($code->fields as $fieldsElement)
                    {
                        $key = (string) $fieldsElement->attributes()->key;
                        $fields = array();

                        if(isset($fieldsElement->field))
                        {
                            foreach($fieldsElement->field as $field)
                            {
                                $f = new EasyTableField($field);

                                $k = '';

                                if($field->attributes()->name)
                                {
                                    $k = (string)$field->attributes()->name;
                                }
                                else if(isset($field->name))
                                {
                                    $k = (string)$field->name;
                                }

                                $fields[$k] = $f;
                            }//foreach
                        }

                        $EasyAutoCode->fields[$key] = $fields;
                    }//foreach
                }

                $this->addAutoCode($EasyAutoCode);
            }//foreach
        }

        /*
         * Package elements - 1.6
         */
        if(isset($manifest->elements->element))
        {
            foreach ($manifest->elements->element as $e)
            {
                $eL = new stdClass();
                $eL->name = (string)$e;

                $this->elements[] = $eL;
            }//foreach
        }


        /*
         * BuildOptions
         */
        foreach($manifest->buildoptions as $opt)
        {
            foreach($opt as $k => $v)
            {
                $this->buildOpts[$k] = (string)$v;
            }//foreach
        }//foreach

        return true;
    }//function

    /**
     * Adds AutoCode to the project.
     *
     * @param EasyAutoCode $autoCode
     *
     * @return void
     */
    public function addAutoCode(EasyAutoCode $AutoCode)
    {
        $this->autoCodes[$AutoCode->getKey()] = $AutoCode;
    }//function

    /**
     * Deletes a project.
     *
     * @param boolean $complete
     *
     * @return boolean true on success
     */
    public function remove($complete = false)
    {
        if( ! $this->dbId)
        {
            echo ecrHTML::displayMessage(JText::_('Invalid Project'), 'error');

            return false;
        }

        if($complete)
        {
            //-- Just remove the EasyCreator part - finish here
            return true;

            $clientId =($this->scope == 'admin') ? 1 : 0;

            jimport('joomla.installer.installer');

            //-- Get an installer object
            $installer = JInstaller::getInstance();

            //-- Uninstall the extension
            if( ! $installer->uninstall($this->type, $this->dbid, $clientId))
            {
                echo ecrHTML::displayMessage(JText::_('JInstaller: Unable to remove project'), 'error');

                return false;
            }
        }

        //-- Remove the config script
        $fileName = $this->getEcrXmlFileName();

        if( ! JFile::exists(ECRPATH_SCRIPTS.DS.$fileName))
        {
            echo ecrHTML::displayMessage(JText::sprintf('File not found %s', ECRPATH_SCRIPTS.DS.$fileName), 'error');
            return false;
        }

        if( ! JFile::delete(ECRPATH_SCRIPTS.DS.$fileName))
        {
            echo ecrHTML::displayMessage(JText::_('Unable to delete file'), 'error');
            echo ecrHTML::displayMessage(ECRPATH_SCRIPTS.DS.$fileName, 'error');

            return false;
        }

        return true;
    }// function

    public function insertPart($options, EasyLogger $logger, $overwrite = false)
    {
        $element_scope = JRequest::getVar('element_scope');
        $element_name = JRequest::getVar('element_name', NULL);
        $element = JRequest::getVar('element', NULL);

        if( ! isset($options->pathSource)
        || ! $options->pathSource)
        {
            JError::raiseWarning(100, JText::_('Invalid options'));
            $logger->log('Invalid options');

            return false;
        }

        /*
         * Define substitutes
         */
        $this->addSubstitute('_ECR_ELEMENT_NAME_', $element_name);

        /*
         * Process files
         */
        // @TODO ...
        $basePathDest =($element_scope == 'admin') ? JPATH_ADMINISTRATOR : JPATH_SITE;
        $basePathDest .= DS.'components'.DS.$options->ecr_project;

        $files = JFolder::files($options->pathSource, '.', true, true, array('options', '.svn'));

        foreach($files as $file)
        {
            $fName = str_replace($options->pathSource.DS, '', $file);
            $fName = str_replace('ecr_element_name', strtolower($element_name), $fName);
            $fName = str_replace('ecr_list_postfix', strtolower($this->listPostfix), $fName);

            //--Check if file exists
            if(JFile::exists($basePathDest.DS.$fName) && ! $overwrite)
            {
                //-- Replace AutoCode
                $ACName = "$element_scope.$options->group.$options->part.$element";

                if(array_key_exists($ACName, $this->autoCodes))
                {
                    //-- Replace AutoCode
                    $fileContents = JFile::read($basePathDest.DS.$fName);

                    foreach ($this->autoCodes as $AutoCode)
                    {
                        foreach ($AutoCode->codes as $key => $code)
                        {
                            $fileContents = $AutoCode->replaceCode($fileContents, $key);
                        }//foreach
                    }//foreach
                }
                else
                {
                    JError::raiseWarning(100, JText::sprintf('Autocode key %s not found', $ACName));

                    return false;
                }
            }
            else
            {
                //-- Add new file(s)
                $fileContents = JFile::read($file);

                $subPackage = explode(DS, str_replace($options->pathSource.DS, '', $file));
                $subPackage = $subPackage[0];
                $subPackage = str_replace(JFile::getName($file), '', $subPackage);
                $subPackage =($subPackage) ? $subPackage : 'Base';

                $this->addSubstitute('_ECR_SUBPACKAGE_', ucfirst($subPackage));

            }

            $this->substitute($fileContents);

            if( ! JFile::write($basePathDest.DS.$fName, $fileContents))
            {
                JError::raiseWarning(100, JText::_('Unable to write file'));

                return false;
            }

            $logger->logFileWrite($file, $basePathDest.DS.$fName, $fileContents);
        }//foreach

        if( ! $this->writeProjectXml())
        {
            return false;
        }

        return true;
    }//function

    /**
     * Adds a table to the project.
     *
     * @param string $name
     */
    public function addTable(EasyTable $table)
    {
        if( ! in_array($table->name, $this->tables))
        {
            $this->tables[$table->name] = $table;
        }

        return true;
    }//function

    /**
     *
     * @param $ecr_project
     * @param $substitutes
     * @return unknown_type
     */
    public function prepareAddPart($ecr_project, $substitutes = array())
    {
        if( ! $project = EasyProjectHelper::getProject($ecr_project))
        {
            JError::raiseWarning(100, JText::sprintf('Unable to load the project %s', $ecr_project));
            return false;
        }

        $this->addSubstitute('_ECR_COM_NAME_', $project->name);
        $this->addSubstitute('_ECR_COM_COM_NAME_', $project->comName);
        $this->addSubstitute('ECR_AUTHOR', $project->author);
        $this->addSubstitute('AUTHORURL', $project->authorUrl);
        $this->addSubstitute('_ECR_ACT_DATE_', date('d-M-y'));

        foreach($substitutes as $key => $value)
        {
            $this->addSubstitute($key, $value);
        }//foreach

        //-- Read the header file
        $header = JFile::read(ECRPATH_EXTENSIONTEMPLATES.DS.'std'.DS.'header.php');

        //-- Replace vars in header
        $this->substitute($header);
        $this->addSubstitute('##*HEADER*##', $header);

        return true;
    }//function

    /**
     * Add a string to the substitution array.
     *
     * @param string $key
     * @param string $value
     *
     * @return void
     */
    public function addSubstitute($key, $value)
    {
        $this->_substitutes[$key] = $value;
    }//function

    /**
     * Get a subvstitute by key.
     *
     * @param string $key
     *
     * @return string
     */
    public function getSubstitute($key)
    {
        if(array_key_exists($key, $this->_substitutes))
        {
            return $this->_substitutes[$key];
        }

        return '';
    }//function

    /**
     * Replaces tags in a string with values from the substitution array.
     *
     * @param $string string
     *
     * @return string string
     */
    public function substitute( & $string)
    {
        foreach($this->_substitutes as $key => $value)
        {
            $string = str_replace($key, $value, $string);
        }//foreach

        return $string;
    }//function

}//class
