<?php
/**
 * @version $Id: file.php 1199 2010-05-14 10:16:01Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 07-Mar-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Provides operation on files.
 */
class EasyFile
{
    /**
     * Save a file.
     * File name and path set from request.
     *
     * @return string - 'saved' on success / error string
     */
    public static function saveFile()
    {
        $file_path = JRequest::getVar('file_path', NULL);
        $file_name = JRequest::getVar('file_name', NULL);
        $insertstring = JRequest::getVar('c_insertstring', '', 'post', 'string', JREQUEST_ALLOWRAW );

        if( ! $file_path || ! $file_name )
        {
            return JText::_('Empty values in save');
        }

        if( ! $insertstring )
        {
            return JText::_('Empty content');
        }

        $file_path = JPath::clean(JPATH_ROOT.DS.$file_path);

        /*
         * as for now.. the file must exist for save !
         */
        if( ! JFile::exists($file_path.DS.$file_name))
        {
            return JText::_('The file must exist for save');
        }

        if( ! JFile::write($file_path.DS.$file_name, $insertstring))
        {
            return JText::sprintf('The file %s could NOT be saved at PATH: %s', $file_name, $file_path);
        }

        return true;
    }//function

    /**
     * Saves a backup of a file apending a postfix .rXX
     *
     * @param string $fileName
     * @return bool true on success
     */
    public static function saveVersion($fileName)
    {
        if( ! JFile::exists($fileName))
        {
            JError::raiseWarning(100, JText::_('File not found'));

            return false;
        }

        $r = 1;

        $found = false;

        while ( ! $found)
        {
            $versionedFileName = $fileName.'.r'.$r;

            if( ! JFile::exists($versionedFileName))
            {
                $found = true;
            }
            else
            {
                $r++;
            }
        }//while

        if( ! JFile::copy($fileName, $versionedFileName))
        {
            JError::raiseWarning(100,JText::sprintf('Unable to copy file %s', $fileName));

            return false;
        }

        return true;
    }//function

    /**
     * Delete a file.
     * File name and path set from request.
     *
     * @return string Message.
     */
    public static function deleteFile()
    {
        $file_path = JRequest::getVar('file_path');
        $file_name = JRequest::getVar('file_name');

        $file_path = JPath::clean(JPATH_ROOT.DS.$file_path);

        if( ! JFile::exists($file_path.DS.$file_name))
        {
            return JText::_('The file does not exist');
        }

        if( JFile::delete($file_path.DS.$file_name))
        {
            return true;
        }

        return JText::sprintf('The file %s could NOT be deleted at PATH: %s', $file_name, $file_path);
    }//function

}//class
