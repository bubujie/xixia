<?php
/**
 * @version SVN: $Id: selenium.php 1218 2010-05-29 04:28:27Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 28-May-2010
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

ecrLoadHelper('pearhelpers.consolehelper');

/**
 * Selenium test Helper.
 *
 * @package    EasyCreator
 */
class EasySeleniumTest extends EasyPearConsole
{
    public $logPath = '';

    public function __construct()
    {
        parent::__construct();
    }//function

    public function test($arguments = array())
    {
        if( ! count($arguments))
        {
            return '';
        }

        $results = $this->cliExec('phpunit', $arguments);

        return $results;
    }//function

}//class
