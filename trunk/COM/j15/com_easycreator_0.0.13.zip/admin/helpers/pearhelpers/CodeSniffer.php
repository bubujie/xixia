<?php
/**
 * @version SVN: $Id: CodeSniffer.php 1054 2009-11-13 02:46:27Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author		EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author		Nikolai Plath {@link http://www.nik-it.de}
 * @author		Created on 10.09.2009

 * Usage: phpcs [-nwlsvi] [--report=<report>] [--report-file=<reportfile>]
 [--config-set key value] [--config-delete key] [--config-show]
 [--standard=<standard>] [--sniffs=<sniffs>]
 [--extensions=<extensions>] [--ignore=<patterns>]
 [--generator=<generator>] [--tab-width=<width>] <file> ...
 -n           Do not print warnings
 -w           Print both warnings and errors (on by default)
 -l           Local directory only, no recursion
 -s           Show sniff codes in all reports
 -v[v][v]     Print verbose output
 -i           Show a list of installed coding standards
 --help       Print this help message
 --version    Print version information
 <file>       One or more files and/or directories to check
 <extensions> A comma separated list of file extensions to check
 (only valid if checking a directory)
 <patterns>   A comma separated list of patterns that are used
 to ignore directories and files
 <sniffs>     A comma separated list of sniff codes to limit the check to
 (all sniffs must be part of the specified standard)
 <standard>   The name of the coding standard to use
 <width>      The number of spaces each tab represents
 <generator>  The name of a doc generator to use
 (forces doc generation instead of checking)
 <report>     Print either the "full", "xml", "checkstyle",
 "csv", "emacs", "source" or "summary" report
 (the "full" report is printed by default)
 <reportfile> Write the report to the specified file path
 (report is also written to screen)

 * @author elkuku
 *
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

ecrLoadHelper('pearhelpers.consolehelper');

/**
 * PHP Code Sniffer helper.
 *
 * @package EasyCreator
 */
class EasyCodeSniffer extends EasyPearConsole
{
    public $standard = 'PEAR';

    public $sniffFormat = 'full';

    public $verboseLevel = '';

    public $sniffs = array();

    /**
     * Constructor.
     */
    public function __construct()
    {
        parent::__construct();
    }//function

    public function showConfig()
    {
        //does not work...
        $cmd = $this->cliBase.'/phpcs --config-show';
        echo $cmd;
        $results = shell_exec($cmd);

        return $results;
    }//function

    public function setStandard($standard)
    {
        $this->standard = $standard;
    }//function

    public function setFormat($format)
    {
        $this->format = $format;
    }//function

    /**
     * Execute a sniff on a single file.
     *
     * @param string $fullPath
     *
     * @return string Results
     */
    public function sniffFile($fullPath)
    {
        $args = array();

        if(count($this->sniffs))
        {
            $args[] = '--sniffs='.implode(',', $this->sniffs);
        }

        $args[] = '--report='.$this->format;
        $args[] = '--standard='.$this->standard;

        /*
         * Parse directories
         * clean path
         */
        $args[] = str_replace('/', DS, $fullPath);

        $args[] = $this->verboseLevel;

        $results = $this->cliExec('phpcs', $args);

        /**
         * @todo save to file
         */

        return $results;
    }//function

    /**
     * Get the PEAR installed coding standards.
     *
     * @return array
     */
    public function getStandards()
    {
        if( ! $this->validEnv )
        {
            return array();
        }

        //--Expected response: e.g.
        //-- The installed coding standards are PEAR, PHPCS, Squiz, Zend and MySource
        $s = $this->cliExec('phpcs', array('-i'));

        $s = trim($s);
        $s = str_replace('The installed coding standards are ', '', $s);
        $s = str_replace(' and ', ', ', $s);

        return explode(', ', $s);
    }//function

}//class
