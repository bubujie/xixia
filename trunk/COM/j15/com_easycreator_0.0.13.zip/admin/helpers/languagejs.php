<?php
/**
 * @version SVN: $Id: languagejs.php 1198 2010-05-14 05:25:58Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 26.04.2010
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/*
 * JText definitions for Javascript
 */

$js = "
//-- EasyCreator language definitions
var JSLNG_SELECT_A_PACKAGE_TO_UPLOAD = '".JText::_('Please select a package to upload')."'
var JSLNG_PLEASE_REVIEW_YOUR_INPUT='".JText::_('Please review your input')."'
var JSLNG_INSERT_A_DESCRIPTION='".JText::_('Error Insert a description for the element')."'
var JSLNG_TRANSLATING='".JText::_('Translating')."'
var JSLNG_LOADING='".JText::_('Loading')."'
var JSLNG_MUST_PROVIDE_VERSION='".JText::_('You must provide a version')."'
var JSLNG_MUST_PROVIDE_NAME='".JText::_('You must provide a name')."'
var JSLNG_MUST_PROVIDE_LIST_POSTFIX='".JText::_('You must provide a list postfix')."'
var JSLNG_PLEASE_ADD_ONE_FIELD='".JText::_('Please add at least one field')."'
var JSLNG_NOT_A_NUMBER='".JText::_('This is not a number')."'
";

JFactory::getDocument()->addScriptDeclaration($js);
