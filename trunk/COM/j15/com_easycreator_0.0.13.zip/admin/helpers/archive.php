<?php
/**
 * @version SVN: $Id: archive.php 1137 2010-03-26 23:34:20Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 18-Oct-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Creates archive files.
 *
 * @package    EasyCreator
 */
class EasyArchive
{
    /**
     * Creates a tgz archive.
     *
     * @param   string  The name of the archive
     * @param   array   The name of an array of files
     * @param   string  The compression for the archive
     * @param   string  Path to remove within the archive
     *
     * @return object Archive_Tar
     */
    public static function createTgz($archive, $files, $compress = 'tar', $removePath = '')
    {
        ecrLoadHelper('pear.archive.Tar');

        $tar = new Archive_Tar($archive, $compress);
        $tar->setErrorHandling(PEAR_ERROR_PRINT);
        $tar->createModify($files, '', $removePath);

        return $tar;
    }//function

    /**
     * Creates a ZIP package.
     *
     * @param string $fileName
     * @param array $files
     * @param string $removePath Path to remove within the archive
     *
     * @return object Archive_Zip
     */
    public static function createZip($fileName, $files, $removePath='')
    {
        ecrLoadHelper('pear.archive.Zip');

        $archive = new Archive_Zip($fileName);

        return $archive->create($files, array('remove_path'=>$removePath));
    }//function

}//class
