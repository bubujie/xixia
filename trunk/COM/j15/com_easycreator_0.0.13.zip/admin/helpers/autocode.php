<?php
/**
 * @version SVN: $Id: autocode.php 1155 2010-04-04 20:51:17Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author	   EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author	   Nikolai Plath {@link http://www.nik-it.de}
 * @author	   Created on 04-Sep-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

//-- No direct access
defined('_JEXEC') or die('=;)');

/**
 * Adds AutoCode to the project.
 */
class EasyAutoCode
{
    public $group = '';
    public $name = '';
    public $element = '';
    public $scope = '';

    public $options = array();

    public $table = null;
    public $fields = array();
    public $codes = array();

    protected $key = '';

    protected $tags = array();

    protected $enclose = false;

    private $_startTag = '//*** ECR AUTOCODE START [TTTT] ***//';
    private $_endTag = '//*** ECR AUTOCODE END [TTTT] ***//';


    /**
     * Constructor.
     *
     * @param string $group
     * @param string $name
     * @param string $element
     * @param string $scope
     */
    public function __construct($scope, $group, $name, $element)
    {
    	$this->group = $group;
    	$this->name = $name;
    	$this->element = $element;
    	$this->scope = $scope;

    	$this->key = "$scope.$group.$name.$element";
    }//function

    public function getKey()
    {
    	return $this->key;
    }//function

    /**
     * To be overridden.
     *
     * Subsequent classes will define text strings to be inserted.
     *
     * @param string $type
     * @param EasyTableField $field
     */
    public function getCode($type, EasyTableField $field) { }

    /**
     * Encloses a string in AutoCode tags.
     *
     * @param string $text The text to enclose.
     * @param string $title Title to be used in tag.
     * @param boolean $addPHPTags Enclose in PHP tags
     *
     * @return string
     */
    public function enclose($text, $tag, blubber $addPHPTags = null)
    {
        if( ! $this->enclose) return $text;
//        $addPHPTags = $this->enclose;
        $pOpen =($this->enclose === 'php') ? '<?php ' : '';
        $pClose =($this->enclose === 'php') ? ' ?>' : '';
        $start = $pOpen.str_replace('TTTT', $tag, $this->_startTag).$pClose;
        $end = $pOpen.str_replace('TTTT', $tag, $this->_endTag).$pClose;

        return $start.NL.$text.$end;
    }//function

    public function getFormattedKey($key)
    {
    	return $this->tags['start'].$key.$this->tags['end'];
    }//function

    public function replaceCode($string, $key)
    {
        if( ! isset($this->codes[$key]))
        {
            JError::raiseWarning(100, JText::sprintf('AutoCode %s not found', $key));

            return $string;
        }

        $sA = explode(NL, $string);
        $result = array();

        $started = false;

        foreach ($sA as $s)
        {
            if( strpos($s, str_replace('TTTT', $key, $this->_endTag)) !== false)
            {
                //-- End tag found
                if( ! $started)
                {
                    JError::raiseWarning(100, JText::sprintf('Match mismatch on %s', $key));

                    return $string;
                }

                $started = false;

                continue;
            }

            if(strpos($s, str_replace('TTTT', $key, $this->_startTag)) !== false)
            {
                //-- Start tag found
                $result = array_merge($result, explode(NL, $this->codes[$key]));

                $started = true;

                continue;
            }

            if( ! $started)
            {
                $result[] = $s;
            }
        }//foreach

        return implode(NL, $result);
    }//function

    /**
     * Get the contents.
     *
     * @param string $string
     *
     * @return mixed [string Autocode | boolean false on errors]
     */
    public function getContents($string)
    {

        $results = array();

        $startExp = '%'.$this->getRegEx($this->_startTag, array('TTTT')).'%';
        $endExp = '%'.$this->getRegEx($this->_endTag, array('TTTT')).'%';

        $aString = explode("\n", $string);
        $actItem = '';

        foreach($aString as $str)
        {
            preg_match($startExp, $str, $startMatch);
            preg_match($endExp, $str, $endMatch);

            if($startMatch)
            {
                if( ! $actItem)
                {
                    $actItem = $startMatch[1];
                    $results[$actItem] = '';

                    continue;
                }
                else
                {
                    echo '<h3 style="color: red;">Match mismatch..</h3>missing end tag';

                    return false;
                }
            }

            if($endMatch)
            {
                if($actItem)
                {
                    $actItem = '';

                    continue;
                }
                else
                {
                    echo '<h3 style="color: red;">Match mismatch..</h3>missing start tag';

                    return false;
                }

            }

            if($actItem)
            {
                $results[$actItem] .= $str.NL;
            }
        }//foreach

        return $results;
    }//function

    /**
     *
     * @param $pattern
     * @param $string
     * @param $keys
     *
     * @return unknown_type
     */
    public function getFields($pattern, $string, $keys)
    {
        $fields = array();

        if( ! count($keys))
        {
            return;
        }

        $testExp = '%'.$this->getRegEx($pattern, $keys).'%';

        preg_match_all($testExp, $string, $matches);

        array_shift($matches);

        return $matches;
    }//function

    /**
     * Convert a string into a regular expression.
     *
     * @param string $string The string to convert.
     * @param array $tags Expected tags and values.
     *
     * @return string
     */
    function getRegEx($string, $tags)
    {
        $escapes = array('*', '[', ']', '.', '$', '?', '(', ')');

        foreach($escapes as $escape)
        {
            $string = str_replace($escape, "\\".$escape, $string);
        }//foreach

        foreach($tags as $t)
        {
            $string = str_replace($t, "([\#_A-Za-z0-9]*)", $string);
        }//foreach

        if(strpos($string, NL))
        {
            $ss = explode(NL, $string);
            $sa = array();

            foreach($ss as $s)
            {
                if($s) $sa[] = trim($s);
            }//foreach

            $string = implode('[\s]*+', $sa);
        }

        $string = str_replace(' ', '\s', $string);

        return $string;
    }//function

    protected function getElement($name, $path)
    {
        static $elements = array();

        if(isset($elements[$name]))
        {
            return $elements[$name];
        }

        $fileName = $path.DS.'elements'.DS.$name.'.php';

        if( ! JFile::exists($fileName))
        {
            JError::raiseWarning(100, sprintf('Element %s not found', $name));

            $elements[$name] = false;

            return false;
        }

        require_once $fileName;

        $className = get_class($this).'Element'.ucfirst($name);

        if ( ! class_exists($className))
        {
            JError::raiseWarning(100, sprintf('Required class %s not found', $className));

            return false;
        }

        $elements[$name] = new $className();

        return $elements[$name];
    }//function

}//class
