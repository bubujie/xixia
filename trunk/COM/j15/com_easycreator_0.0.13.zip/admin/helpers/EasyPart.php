<?php
/**
 * @version SVN: $Id: EasyPart.php 1137 2010-03-26 23:34:20Z elkuku $
 * @package    EasyCreator
 * @subpackage Helpers
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath {@link http://www.nik-it.de}
 * @author     Created on 16-Sep-2009
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

class EasyPart extends JObject
{
    public $group = '';
    public $name = '';
    public $key = '';

    public $basePath = '';

    private $_element = '';
    private $_scope = '';

    private $_name = '';

    public function __construct($group, $name, $element, $scope)
    {
        $this->key = "$group.$name.$element.$scope";
    }//function

    private function getName()
    {
    	return $this->group.'.'.$this->name.'.'.$this->_element.'.'.$this->_scope;
    }//function

}//class
