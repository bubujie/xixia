<?php
/**
 * @version SVN: $Id: admin.easycreator.php 1105 2010-02-13 18:29:28Z elkuku $
 * @package    EasyCreator
 * @subpackage Base
 * @author     EasyJoomla {@link http://www.easy-joomla.org Easy-Joomla.org}
 * @author     Nikolai Plath (elkuku) {@link http://www.nik-it.de NiK-IT.de}
 * @author     Created on 06-Mar-2008
 * @license    GNU/GPL, see JROOT/LICENSE.php
 */

/*
 This is our SQL INSERT query (for manual install):
 J! 1.5
 INSERT INTO `#__components`
 (`name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`
 , `iscore`, `params`, `enabled`)
 VALUES
 ('EasyCreator', 'option=com_easycreator', 0, 0, 'option=com_easycreator', 'EasyCreator', 'com_easycreator', 0
 , 'components/com_easycreator/assets/images/easy-joomla-favicon.ico', 0, '', 1);

 J! 1.6
 INSERT INTO `jos_extensions` (`name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`
 , `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`)
 VALUES
 ('easycreator', 'component', 'com_easycreator', '', 0, 1, 0, 0
 , 'a:11:{s:6:"legacy";b:1;s:4:"name";s:11:"EasyCreator";s:4:"type";s:9:"component";s:12:"creationDate";s:11:"13-May-2010";s:6:"author";s:13:"Nikolai Plath";s:9:"copyright";s:51:"Copyright (C) Easy-Joomla.org. All rights reserved.";s:11:"authorEmail";s:20:"easy@easy-joomla.org";s:9:"authorUrl";s:22:"http://easy-joomla.org";s:7:"version";s:10:"0.0.13_SVN";s:11:"description";s:48:"EasyCreator helps creating Extensions for Joomla";s:5:"group";s:0:"";}', '{"cred_author":"Der dummy","cred_author_email":"dummy@example.com","cred_author_url":"http:\\/\\/dummy.com","cred_license":"http:\\/\\/www.gnu.org\\/licenses\\/gpl-2.0.html GNU\\/GPL","cred_copyright":"nonono","archive_zip":"on","custom_name_1":"_*VERSION*_*SVNREV*_*DATETIMEymd_Hi*","custom_name_2":"_*VERSION*_*DATETIMEymd_Hi*","custom_name_3":"_*VERSION*","logging":"1","profile":"1","files":"1","ecr_help":"none","editarea_type":"edit_area_full.js","local_api_copy":"","warn_livesite":"1","use_google_trans_api":"1","langfiles_chk_utf8":"0","langfiles_chk_bom":"1","ecr_debug":"0","ecr_debug_type":"krumo"}'
 , '', '', 0, '0000-00-00 00:00:00', 0, 0)

INSERT INTO `jos_menu` (`menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `ordering`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`)
 VALUES
 ('_adminmenu', 'com_easycreator', 'easycreator', '', '', 'index.php?option=com_easycreator', 'component', 0, 1, 1, XXX, 0, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_easycreator/assets/images/easy-joomla-favicon.ico', 0, '', 47, 48, 0, '')

 */

//-- No direct access
defined('_JEXEC') or die('=;)');

global $_PROFILER;
JDEBUG ? $_PROFILER->mark('EasyCreator starting...') : null;

error_reporting(E_ALL);
#error_reporting(E_STRICT);//...when ¿

//-- Dev mode - internal use =;)
define('ECR_DEV_MODE', 1);

//-- import JFile
jimport('joomla.filesystem.file');

// --Global functions
require_once 'functions.php';

//-- Load helpers
ecrLoadHelper('html');
ecrLoadHelper('project');
ecrLoadHelper('projecthelper');
ecrLoadHelper('languagehelper');
ecrLoadHelper('languagejs');

//-- Add CSS
ecrStylesheet('default');
ecrStylesheet('toolbar');
ecrStylesheet('icon');

//-- Add javascript
ecrScript('easycreator');

//-- Global constants
require_once 'defines.php';

//-- Setup debugger
if (ECR_DEV_MODE && JComponentHelper::getParams('com_easycreator')->get('ecr_debug'))
{
    ecrLoadHelper('debug');
    //-- Set debugging ON
    define('ECR_DEBUG', 1);
}
else
{
    define('ECR_DEBUG', 0);
}

//-- Setup tooltips - used almost everywhere..
JHTML::_('behavior.tooltip');
JHTML::_('behavior.tooltip', '.hasEasyTip', array('className' => 'easy'));

//-- Joomla! 1.6 compat
if(version_compare(JVERSION, '1.6', '>'))
{
    //-- Mootools compat 1.2
    ecrScript('moocompat');
}
else
{
    //-- J! 1.6 stuff not present in J! 1.5
    ecrLoadHelper('databasequery');
}

//-- Require the base controller
require_once JPATH_COMPONENT.DS.'controller.php';

//-- Require specific controller if requested
if($controller = JRequest::getWord('controller'))
{
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';

    if (file_exists($path))
    {
        require_once $path;
    }
    else
    {
        $controller = '';
    }
}

//-- Create the controller
$classname = 'EasyCreatorController'.$controller;
$controller = new $classname();

if(JRequest::getCmd('tmpl') == 'component')
{
    //-- Perform the Request task only - raw view
    $controller->execute(JRequest::getCmd('task'));
}
else
{
    //-- Display the menu
    ecrHTML::easyMenu();

    //-- Perform the Request task
    $controller->execute(JRequest::getCmd('task'));

    //-- Display the footer
    ecrHTML::footer();
}

JDEBUG ? $_PROFILER->mark('EasyCreator finished') : null;

#error_reporting(E_ALL);

//-- Redirect if set by the controller
$controller->redirect();
