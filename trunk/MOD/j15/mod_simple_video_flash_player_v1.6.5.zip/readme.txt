##ENGLISH ###

This Module is a Simple Video Flash Player for Joomla 1.5.x and is based on the JW player. Is easy to use!

Features:
	-Plays a single video file from a URL or unlimited video files from a playlist
	-Plays youtube videos
	-It supports playback of any format the Adobe Flash Player can handle (FLV, MP4, MP3, AAC, JPG, PNG and GIF)

Settings:
	-Player (Version 5.6)
	-Change player settings
	-Playlist settings
	-Display a preview image
	-Dispaly a fallback image
	-Url to an external page
	-Autostart settings
	-Shuffle settings
	-Repeat settings
	-Controlbar settings
	-Skin settings
	-Plugin settings
	-Color settings (new)
	-Stretching settings (new)
	-Streamer settings (new)

Update Version 1.6.5
    -Player Update (Version 5.6)
	-Update to JW Embedder no SWFObject  
	-Color settings (backcolor, screencolor, lightcolor, frontcolor)
	-Stretching settings
	-Streamer settings
	-IE9 Update 
	-IE Bugfix 

Update version 1.6.1
	-player update (Version 5.2)
	-controllbar update (None,Top)
	-player background-color

Update version 1.6
	-player update (Version 4.4)
	-fallback image
	-controllbar (Over,Bottom)
	-skin settings
	-plugin settings

Tests with rhuk_milkyway-Template (Firefox 3, Firefox 4, IE7, IE8, IE9)!

###GERMAN###

Dieses Modul ist ein einfacher Flash Video Player f�r Joomla 1.5.x und basiert auf den JW Player. Es ist sehr leicht zu bedienen!

Features:
    Spielt einzelne Videos von einer URL oder mehrere Videos aus einer XML Playlist ab
    Unterst�tzung folgender Formate FLV, MP4, MP3, AAC, JPG, PNG, GIF und YouTube Videos

	
Einstellungen:
    -Player (Version 5.6)
    -Player-Einstellungen
    -Playlist-Einstellungen
    -Vorschaubild
    -Fallback-Image
    -Verlinkung auf eine externe Seite
    -Autostart-Einstellungen
    -Shuffle-Einstellungen
    -Repeat-Einstellungen
    -Controllbar-Einstellungen
    -Skin-Einstellung
    -Plugin-Einstellung
	-Farbeinstellungen (Neu)
	-Stretching-Einstellung (Neu)
	-Streamer-Einstellung (Neu)

Update Version 1.6.5
    -Player Update (Version 5.6)
	-Update Funktion auf JW Embedder kein SWFObject  
	-Farbeeinstellungen (backcolor, screencolor, lightcolor, frontcolor)
	-Stretching-Einstellung 
	-Streamer-Einstellung
	-IE9 Update 
	-IE Bugfix 
	
Update Version 1.6.1
    -Player Update (Version 5.2)
    -Controllbar-Einstellungen (None,Top)
    -Player Hintergrundfarbe
 
Update Version 1.6
    -Player Update (Version 4.4)
    -Fallback Image
    -Controllbar (Over/Bottom)
    -Skin-Einstellung
    -Plugin-Einstellung

Getestet mit rhuk_milkyway-Template (Firefox 3, Firefox 4, IE7, IE8, IE9)!

	
Frontend:
http://www.time2online.de/download/frontend1.jpg
http://www.time2online.de/download/frontend2.jpg

Parameter:
http://www.time2online.de/download/parameter.jpg
	
Demo: 
http://www.time2online.de/joomla-extensions.html