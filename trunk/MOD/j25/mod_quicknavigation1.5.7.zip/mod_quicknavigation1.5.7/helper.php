<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_quicknavigation
 * @copyright	Copyright (C) 2012 Webbati - webbati@gmail.com. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

require_once JPATH_SITE.'/components/com_content/helpers/route.php';
jimport('joomla.application.categories');
jimport('joomla.application.component.helper');
			
			
class modQuickNavigationHelper
{
	
	
  public static function getMainCats(& $params)
  {		
	  $app = JFactory::getApplication();
	  $db  = JFactory::getDbo();
	  $cats = JCategories::getInstance('Content');
	  
	  
	  $show_root = $params->get('show_root') ;
	  
	  
	  if(($params->get('show_root') == 0) && (count($params->get('categories')) > 1)) {
		  
		  $show_root = 1;
		  
	  }
	  $app->setUserState('show_root', $show_root);
	  
	  
	  	if(($params->get('pre_selected', 0) == 1) && ($params->get('preselected_category', '') != '')) {
		
			if(($params->get('usecat')) && (count($params->get('categories')) > 0) && (in_array($params->get('preselected_category'), $params->get('categories')))){
				$preselect = $params->get('preselected_category');
				$app->setUserState('preselect', $preselect );

			}
			else if(!$params->get('usecat')) {
				$preselect = $params->get('preselected_category');
				$app->setUserState('preselect', $preselect );
				
			}
			 else  { 
					$preselect = $params->get('categories');
					$app->setUserState('preselect', $preselect[0]);
		 
	  }
		}
	  else {
		  
		 $app->setUserState('preselect', '');
	  }
	  
	  

	  $query = $db->getQuery(true);
	
		$query->select('*');
		$query->from('#__categories');
		if(($params->get('usecat')) && (count($params->get('categories')) > 0)){
			
			$wherein = 'id IN (';
			
			
			foreach($params->get('categories') as $category){
				
				$wherein .= $db->Quote($category).',';
				
			}
			$wherein = trim($wherein,',');
			$wherein .= ') ';
			
			$query->where($wherein);
		}
		
		$query->where('level = 1');
		$query->where('published = 1');
		
		$query->where('extension = "com_content"');
	  
	 
		$db->setQuery( $query );
		return $db->loadObjectList();
  }
  
 
static function    getCategoriesList($cid, & $params){
	
		
		$app = JFactory::getApplication();
		
			  
		$show_root = $params->get('show_root') ;
	  
	  
		if(($params->get('show_root') == 0) && (count($params->get('categories')) > 1)) {
		  
		  $show_root = 1;
		  
		}
		$app->setUserState('show_root', $show_root);
	  
		
		$setList = array();
		$catarray = array();
		
		$tmpcid = $cid;
	
		$html = '';
	 
		do{
			array_unshift($catarray, $tmpcid);
			$tmpcid = self::getCategory(intval($tmpcid))->parent_id; 
			if(!$tmpcid) $tmpcid  = 1;
				

		}
	  
		while($tmpcid != 1 );
		
	 
		
		$html .= self::getCategories($catarray, $params);
		

	  $formArticles = self::getArticles($catarray, $params);
	   

		$html .= $formArticles;
		return $html;

}
 
static  function   getCategory($cid){
	  
		$db			= JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__categories');
		$query->where('id = '.$cid);
		$query->where('published = 1');
		$query->where('extension = "com_content"');
	 
	  
		$db->setQuery( $query );
		return $db->loadObject();
  }
  
static function getCategories($cats = array(), & $params){
	
		$html = '';
		$nform = 0;
		$level = $params->get('limit_deep_stop');
		$app = JFactory::getApplication();
		$db			= JFactory::getDbo();
		$fixed = ($params->get('qn_fixed_size') > 1) ? 'size="'.$params->get('qn_fixed_size').'"' : '';
		$showemptyopt = (bool) $params->get('qn_show_empty_option');
			foreach($cats as $catid){
		  
				  
				
				$query = $db->getQuery(true);
				$query->select('*');
				$query->from('#__categories');
				$query->where('parent_id = '.$catid);
				
					if($level > 0 ){
						$query->where('level <='.$level);
					}
				$query->where('published = 1'); 	
				
				$query->where('extension = "com_content"');
				
				
				$db->setQuery( $query );
				
				$html .= '<div id="qnSubDiv_'.$nform.'" class="qnSubDiv'.$params->get('qn_style').' qnSubDiv'.$params->get('subclass_sfx').' " ><form name="qnSubForm_'.$nform.'" id="qnSubForm_'.$nform.'" method="post" action="" >';
				$categories = $db->loadObjectList();
				if( $categories){
				
				
				$html .= '<select name="catid" '.$fixed.' onChange="getCategoriesFromSub(this.value, '.$nform.', document.qnSubForm_'.$nform.'.maincat.value);">';
				
				if($showemptyopt):
					$html .= '<option  value="" >'.$params->get('first_opt_level_'.$nform).'</option>';
				endif;
				
					foreach( $categories as $cat){
						$sel = '';
							if(in_array($cat->id, $cats))  { $sel = 'selected="selected"'; $setList[] = $cat->id ;}
							if($nform == 0 ) { $app->setUserState('mainlist', $cat->id );}
						$html .='<option '.$sel.' value="'.$cat->id.' ">'.htmlentities($cat->title, ENT_QUOTES, 'UTF-8').'</option>';
				
					}
				$html .= '</select>';
				$html .= JHTML::_('form.token')
						.'<input type="hidden" name="qnTask" value="elencat" />
						<input type="hidden" name="maincat" value="'.$cat->parent_id.'" /></form></div>';
				}
				$db->clear();
				$nform++;
			}
	return $html;
}
static function getArticles($cats = array(), & $params){
		
		$isArticles = (bool) $params->get('qn_show_empty_articlesbox');
		$html = '';
		$fixed = ($params->get('qn_fixed_size') > 1) ? 'size="'.$params->get('qn_fixed_size').'"' : '';
		$showemptyopt = (bool) $params->get('qn_show_empty_option');
		$formArticles = '<div class="qnArtDiv'.$params->get('qn_style').' qnArtDiv'.$params->get('articlesclass_sfx').'"> <form name="qnArtForm" id="qnArtForm" method="post" action="" ><select '.$fixed.' name="aid"   onChange="readArticle(this.value);">';
		if($showemptyopt):
			$formArticles .= '<option  value="" >'.$params->get('articles_text').'</option>';
		endif;
		
		$db			= JFactory::getDbo();
		$nullDate		= $db->Quote($db->getNullDate());
		$date			= JFactory::getDate();
		$nowDate		= $db->Quote($date->toSql());
			foreach($cats as $cid){
		  
		  
			
			$query = $db->getQuery(true);
			$query->select('*');
			$query->from('#__content AS a');
			$query->where('catid = '.$cid);
			$query->where('state = 1');
			$query->where(' ( publish_down >='.$nowDate.' OR publish_down ='.$nullDate.')');
			
			
			/* start order by parameter from com_content */
			$componentParams = JComponentHelper::getParams('com_content');
			$articleOrderby		= $componentParams->get('orderby_sec', 'rdate'); 
			$articleOrderDate	= $componentParams->get('order_date');
			$articleOrder		= ContentHelperQuery::orderbySecondary($articleOrderby, $articleOrderDate) . ', ';
			$orderby = $db->escape($articleOrder) . ' a.created ';
			/* end order by parameter from com_content */
			
			$query->order($orderby);
			
			$db->setQuery( $query );
			$articles = $db->loadObjectList();
			
				if($articles){
					$isArticles = (bool) true;
					if($params->get('qn_show_optgroup')){
						$formArticles .= '<optgroup label="'.ucfirst(htmlentities(self::getCategory($cid)->title, ENT_QUOTES, 'UTF-8')).'" >';
					}
					
					foreach( $articles as $art){
						
						
						$url = JRoute::_(ContentHelperRoute::getArticleRoute($art->id, $art->catid));
						$formArticles .='<option value="'.$url.'" >'. htmlentities($art->title, ENT_QUOTES, 'UTF-8').'</option>';
					}
					$formArticles .= '</optgroup>';
				}
			$db->clear();
		}
		$formArticles .= '</select>';
		$formArticles .= JHTML::_('form.token').'<input type="hidden" name="qnTask" value="getart" /></form></div>';
	 
		if($isArticles) $html = $formArticles;
	return $html;
}
  

} //end class
?>
