<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_quicknavigation
 * @copyright	Copyright (C) 2012 Webbati - webbati@gmail.com. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;


require_once dirname(__FILE__).DS.'helper.php'; 
$live_site = JURI::base(true);
$app = JFactory::getApplication();
$document = JFactory::getDocument();
$document->addStyleSheet( $live_site . '/modules/mod_quicknavigation/asset/css/qn'.$params->get('qn_style').'_style.css');
$document->addStyleSheet( $live_site . '/modules/mod_quicknavigation/asset/css/qn_'.$params->get('qn_color_style').'_style.css');

if ($task = JRequest::getCmd('qnTask', '', 'post')) {
	$select = '';
	
	switch ($task) {
		case 'elencat':
			$select = modQuickNavigationHelper::getCategoriesList(JRequest::getInt('catid', '', 'post'), $params);
			break;

		default:
			break;
	}
	
	if ($select) {
		$app->close($select);
	}

	
}


$categories = modQuickNavigationHelper::getMainCats($params);


require JModuleHelper::getLayoutPath('mod_quicknavigation');


?>
