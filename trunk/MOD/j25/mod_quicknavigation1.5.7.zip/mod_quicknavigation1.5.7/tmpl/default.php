<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_quicknavigation
 * @copyright	Copyright (C) 2012 Webbati - webbati@gmail.com. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */


defined('_JEXEC') or die;
?>
	<script type="text/javascript">

		
		
	function getCategories(cid, ps){
		if(cid == '' ){ $('subcatlist').empty(); return false;}
			new Request.HTML( {
					
					url: '<?php echo JURI::current(); ?>', 
					
					urlEncoded: true,
					encoding: 'utf-8',
					evalResponse: true,
					<?php if($params->get('qn_show_loader')): ?>
					onRequest: function(){
						$('qnloader').show('block')},
					onSuccess: function(){$('qnloader').hide()},
					<?php endif; ?>
					update: $('subcatlist'),
					
				}).post($('qnMainForm'+ps));
	}

	function getCategoriesFromSub(subcid, nform , maincat){
		
		if(subcid == ''){
			if(nform == 0){
				
				getCategories(maincat, '');
			}
			else {
			getCategoriesFromSub(maincat, --nform);
			}
			
			 return true;
		}
			new Request.HTML( {
					url: '<?php echo JURI::current(); ?>', 
					urlEncoded: true,
					encoding: 'utf-8',
					<?php if($params->get('qn_show_loader')): ?>
					onRequest: function(){
						$('qnloader').show('block')},
					onSuccess: function(){$('qnloader').hide()},
					<?php endif; ?>
					update: $('subcatlist'),
					evalResponse: true,
					
				}).post($('qnSubForm_'+nform));
	}



	function readArticle(url){
			if(url){
				document.location.href = url;
				return true;
			}
			return false;
		}

	</script>
	<?php
	
	?>
	<div id="qnMaincontainer" class="qnmodule<?php echo $params->get('moduleclass_sfx'); ?>"  <?php //echo $style; ?> >
	<?php 

	$app = JFactory::getApplication();


	if( ($app->getUserState('preselect')) && ($app->getUserState('preselect') != '')){

		$preselect = $app->getUserState('preselect');
		
		?>
		
		<form id="qnMainFormPS" name="qnMainFormPS" action=""  method="post" >
		<input type="hidden" name="catid" value="<?php echo $preselect; ?>" />
		<?php echo JHTML::_('form.token'); ?> <input type="hidden" name="qnTask" value="elencat" /></form>
		</form>
		
		<?php
		
		echo	"<script type=\"text/javascript\">
		window.addEvent('domready', function(){
					getCategories(".$preselect.", 'PS');
				});
				</script>	
		";

	}


	if( ($app->getUserState('sublist')) && ($app->getUserState('sublist') != '')){

		$sublist = $app->getUserState('sublist');
		$app->setUserState('sublist', 'fromState') ;

		?>
		
		<form id="qnSubForm_state" name="qnSubForm_state" action=""  method="post" >
		<input type="hidden" name="catid" value="<?php echo $sublist; ?>" />
		<?php echo JHTML::_('form.token'); ?> <input type="hidden" name="qnTask" value="elencat" /></form>
		</form>
		
		<?php
		
		echo	"<script type=\"text/javascript\">
		window.addEvent('domready', function(){
					getCategoriesFromSub(".$sublist.", 'state');
				});
				</script>	
		";


	}
	?>
<div id="pretext"  >
<?php echo $before = ($params->get('before_text')) ? '<span id="txtbefore" >'.$params->get('before_text').'</span>' : '' ; ?>
</div>
	<?php

	
	if($app->getUserState('show_root') == 1) :
	$fixed = ($params->get('qn_fixed_size') > 1) ? 'size="'.$params->get('qn_fixed_size').'"' : '';
	?>
	
	<div id="divMainForm" class="<?php echo 'qnSubDiv'.$params->get('qn_style'); ?>" >
	
	<form id="qnMainForm" name="qnMainForm" action=""  method="post" >
	<select name="catid" onChange="getCategories(this.value, '');" <?php echo $fixed; ?>> 
	<?php if(!isset($preselect) || $preselect == '' ){ ?>
			<option  value=""><?php echo $params->get('categories_text'); ?></option>
			<?php 
	}
				foreach($categories as $category){
				
				$sel = '';
				if(isset($preselect) && $preselect == $category->id) { $sel = 'selected="selected"';}
			
				echo '<option '.$sel.' value="'.$category->id.'">'.$category->title.'</option>';
				}
				?>

	</select>
						<?php echo JHTML::_('form.token'); ?>
					
						<input type="hidden" name="qnTask" value="elencat" />
	</form>
	</div>

	<?php
	elseif($app->getUserState('show_root') == 0) :

	?>

	<form id="qnMainForm" name="qnMainForm" action=""  method="post" >
	<input type="hidden" name="catid"  value="<?php echo $preselect; ?>" /> 

						<?php echo JHTML::_('form.token'); ?>
					
						<input type="hidden" name="qnTask" value="elencat" />
	</form>

	<?php
	endif;
	?>




	<div id="subcatlist" class="qnSubcontainer<?php echo $params->get('selectclass_sfx'); ?>"></div>
<?php if($params->get('qn_show_loader')) : ?>
	<div id="qnloader"></div>
<?php endif; ?>
	<div id="postext">
		<?php
			echo $after = ($params->get('after_text')) ? '<span id="txtafter" >'.$params->get('after_text').'</span>' : '';
		?>
	</div>
	</div>
