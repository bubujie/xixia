<?php
/**
* @version 2.13
* @package DJ-Catalog2
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

defined ('_JEXEC') or die('Restricted access'); ?>
<?php $item = $this->item; ?>
<?php if ($this->params->get( 'show_page_title', 1) && $this->params->get('page_title') != $this->item->name) : ?>
<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<?php echo $this->escape($this->params->get('page_title')); ?>
</div>
<?php endif; ?>

<div id="djcatalog" class="djcatalog<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
<div class="djcat_item">
	<div class="djcat_item_in">
		<div class="clear"><?php if($item->event->beforeDJCatalogDisplayContent) { echo $item->event->beforeDJCatalogDisplayContent; } ?></div>
		<?php if ($item->images = $this->images->getImages($item->image_url)) { ?>
        	<div class="djcat_image" style="width: <?php echo ($this->params->get('th_width') + 10); ?>px;">
				<a rel="lightbox-djitem" title="<?php echo $item->name?>" href="<?php echo $item->images[0]['original']?>"><img alt="<?php echo $item->name; ?>" src="<?php echo $item->images[0]['medium']; ?>"/></a>
				<?php if (count($item->images) > 1) {?>
					<div class="djcat_thumbnails">
						<?php for($i = 1; $i < count($item->images); $i++) {?>
							<a rel="lightbox-djitem" title="<?php echo $item->name?>" href="<?php echo $item->images[$i]['original']?>"><img alt="<?php echo $item->name; ?>" src="<?php echo $item->images[$i]['small']; ?>" style="width: <?php echo ($this->params->get('smallth_width') - 4); ?>px; margin-left: 2px; margin-right: 2px;"/></a>
						<?php } ?>
					</div>
					<?php } ?>
        	</div>
		<?php } ?>
		<div class="djcat_title">
	        <h3><?php
	          echo $item->name;
	        ?></h3>
	    </div>
		<?php if($item->event->afterDJCatalogDisplayTitle) { echo $item->event->afterDJCatalogDisplayTitle; } ?>
        <div class="djcat_text">
        	<?php if ($this->params->get('show_category_name_item')) { ?>
			<div class="djcat_category">
			 <?php 
				if ($this->params->get('show_category_name_item') == 2) {
        			echo JText::_('COM_DJCATALOG2_CATEGORY').': '?><span class="djcat_category"><?php echo $item->category; ?></span> 
				<?php }
				else {
					echo JText::_('COM_DJCATALOG2_CATEGORY').': ';?><a href="<?php echo DJCatalogHelperRoute::getCategoryRoute($item->catslug);?>"><span class="djcat_category"><?php echo $item->category; ?></span></a> 
				<?php } ?>
        	</div>
			<?php } ?>
			<?php if ($this->params->get('show_producer_name_item') > 0 && $item->prod_pub == '1' && $item->producer) { ?>
			<div class="djcat_producer">
        		<?php 
					if ($this->params->get('show_producer_name_item') == 2) {
            			echo JText::_('COM_DJCATALOG2_PRODUCER').': '; ?><span class="djcat_producer"><?php echo $item->producer;?></span>
					<?php }
					else if(($this->params->get('show_producer_name_item') == 3)) {
						echo JText::_('COM_DJCATALOG2_PRODUCER').': ';?><a class="modal" rel="{handler: 'iframe', size: {x: 800, y: 600}}" href="<?php echo JRoute::_(DJCatalogHelperRoute::getProducerRoute($item->prodslug).'&tmpl=component'); ?>"><span class="djcat_producer"><?php echo $item->producer; ?></span></a> 
					<?php }
					else {
						echo JText::_('COM_DJCATALOG2_PRODUCER').': ';?><a href="<?php echo JRoute::_(DJCatalogHelperRoute::getProducerRoute($item->prodslug)); ?>"><span class="djcat_producer"><?php echo $item->producer; ?></span></a>
					<?php } ?>
        	</div>
			<?php } ?>
        	<?php 
				if ($this->params->get('show_price_item') == 2 || ( $this->params->get('show_price_item') == 1 && $item->price > 0.0)) { 
					if ($this->params->get('unit_side')== 1) $item->price = number_format($item->price, 2, $this->price_decimal_separator, $this->price_thousands_separator).' '.$this->params->get('price_unit');
					else $item->price = $this->params->get('price_unit').' '.number_format($item->price, 2, $this->price_decimal_separator, $this->price_thousands_separator);
			?>
        	<div class="djcat_price">
        		<?php echo JText::_('COM_DJCATALOG2_PRICE').': ';?><span class="djcat_price_value"><?php echo $item->price; ?></span>
        	</div>
			<?php } ?>
			<?php if ($item->files = $this->files->getFiles($item->files_url)) { ?>
				<div class="djcat_files">
					<?php foreach($item->files as $file) { ?>
						<div class="djcat_file"><a target="_blank" href="<?php echo $file['path']; ?>"><?php echo '['.strtoupper(end(explode(".", $file['name']))).'] '.$file['name'] ?></a></div>
					<?php } ?>
				</div>
			<?php } ?>
            <div class="djcat_description">
                <?php
                echo JHTML::_('content.prepare', $item->description);
                ?>
            </div>
        </div>
		<div class="clear"><?php if($item->event->afterDJCatalogDisplayContent) { echo $item->event->afterDJCatalogDisplayContent; } ?></div>
    </div>
	<div class="clearfix clr clear"> </div>
</div>
<?php 
if ($this->params->get('show_footer')) echo DJCATFOOTER;
?>
</div>
