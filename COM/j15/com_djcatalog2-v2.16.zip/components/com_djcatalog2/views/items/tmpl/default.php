<?php
/**
* @version 2.13
* @package DJ-Catalog2
* @subpackage DJ-Catalog2 Component
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

defined ('_JEXEC') or die('Restricted access');
JHTML::_('behavior.modal');
$Itemid = JRequest::getVar('Itemid');

?>
<?php if ($this->params->get( 'show_page_title', 1) && ($this->params->get( 'page_title')) != @$this->category->name ) : ?>
<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<?php echo $this->escape($this->params->get('page_title')); ?>
</div>
<?php endif; ?>
<div id="djcatalog" class="djcatalog<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<?php if ($this->params->get('showcatdesc') && $this->category) {?>
	<div id="djcat_blog_category">
		<div class="djcat_blog_category-in">
			<?php if ($this->category->images = $this->images->getImages($this->category->image_url)) { ?>
	        	<div class="djcat_image" style="width: <?php echo ($this->params->get('th_width') + 10); ?>px;">
					<a rel="lightbox-djcategory" title="<?php echo $this->category->name?>" href="<?php echo $this->category->images[0]['original']?>"><img alt="<?php echo $this->category->name; ?>" src="<?php echo $this->category->images[0]['medium']; ?>"/></a>
					<?php if (count($this->category->images) > 1) {?>
						<div class="djcat_thumbnails">
							<?php for($i = 1; $i < count($this->category->images); $i++) {?>
								<a rel="lightbox-djcategory" title="<?php echo $category->name?>" href="<?php echo $this->category->images[$i]['original']?>"><img alt="<?php echo $this->category->name; ?>" src="<?php echo $this->category->images[$i]['small']; ?>" style="width: <?php echo ($this->params->get('smallth_width') - 4); ?>px; margin-left: 2px; margin-right: 2px;"/></a>
							<?php } ?>
						</div>
						<?php } ?>
	        	</div>
			<?php } ?>
			<div class="djcat_blog_category_title">
				<h3><?php echo $this->category->name; ?></h3>
			</div>
			<div class="djcat_blog_category_desc">
				<?php echo JHTML::_('content.prepare', $this->category->description); ?>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<?php } ?>
	<?php if ($this->params->get('showsubcategories') && $this->subcategories) {?>
	<div id="djcat_blog_subcategories">
		<?php if ($this->params->get('showsubcategories_label')) { ?><h3><?php echo JText::_('COM_DJCATALOG2_SUBCATEGORIES'); ?></h3><?php } ?>
		<div class="djcat_blog_subcategories_in">
			<?php
			$k = 0; $i = 1;
	        foreach($this->subcategories as $subcategory) {
				$newrow_open = $newrow_close = false;
				if ($k % $this->params->get('category_columns',4) == 0) $newrow_open = true;
				if (($k+1) % $this->params->get('category_columns',4) == 0 || count($this->subcategories) <= $k+1) $newrow_close = true;
	        	
				$rowClassName = 'djcat_subcategory_row';
				if ($k == 0) $rowClassName .= '_first';
				if (count($this->subcategories) <= ($k + $this->params->get('category_columns',4))) $rowClassName .= '_last';
				
				$colClassName ='djcat_subcategory_col';
				if ($k % $this->params->get('category_columns',4) == 0) { $colClassName .= '_first'; }
				else if (($k+1) % $this->params->get('category_columns',4) == 0) { $colClassName .= '_last'; }
				else {$colClassName .= '_'.($k % $this->params->get('category_columns',4));}
				
				if ($newrow_open) { $i = 1 - $i; ?><div class="<?php echo $rowClassName.'_'.$i; ?>"><?php }
				$k++;
			?>
			<div class="djcat_blog_subcategory <?php echo $colClassName; ?>" style="width:<?php echo (100/$this->params->get('category_columns',4)-0.1); ?>%">
				<div class="djcat_blog_subcategory_bg">
					<div class="djcat_blog_subcategory_in">
						<?php if ($subcategory->images = $this->images->getImages($subcategory->image_url)) { ?>
				        	<div class="djcat_blog_image">
				        		<?php if ($this->params->get('image_link_subcategory')) { ?>
									<a rel="lightbox-djsubcategory" title="<?php echo $subcategory->name?>" href="<?php echo $subcategory->images[0]['original']?>"><img alt="<?php echo $subcategory->name; ?>" src="<?php echo $subcategory->images[0]['medium']; ?>"/></a>
				        		<?php } else { ?>
				        			<a href="<?php echo JRoute::_(DJCatalogHelperRoute::getCategoryRoute($subcategory->catslug, 'items'));?>"><img alt="<?php echo $subcategory->name; ?>" src="<?php echo $subcategory->images[0]['medium']; ?>"/></a>
				        		<?php } ?>
							</div>
						<?php } ?>
						<div class="djcat_blog_subcategory_title">
							<h3><a href="<?php echo JRoute::_(DJCatalogHelperRoute::getCategoryRoute($subcategory->catslug, 'items'));?>"><?php echo $subcategory->name; ?></a></h3>
						</div>
						<?php if ($this->params->get('category_show_intro')) {?>
						<div class="djcat_blog_subcategory_desc">
							<?php if ($this->params->get('category_intro_length') > 0 ) {
									echo DJCatalogHelper::trimText($subcategory->description, $this->params->get('category_intro_length'));
								}
								else {
									echo $subcategory->description; 
								}
							?>
						</div>
						<?php } ?>
						<?php if ($this->params->get('showreadmore_subcategory')) { ?>
							<div class="clear"></div>
							<div class="djcat_subcategory_readmore">
								<a href="<?php echo JRoute::_(DJCatalogHelperRoute::getCategoryRoute($subcategory->catslug, 'items')); ?>" class="readon"><?php echo JText::_('COM_DJCATALOG2_BROWSE'); ?></a>
							</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<?php if ($newrow_close) { ?></div><?php } ?>
			<?php } ?>
		</div>
	</div>
	<div class="clear"></div>
	<?php } ?>
	<?php if ($this->params->get('show_category_filter') > 0 || $this->params->get('show_producer_filter') > 0 || $this->params->get('show_search') > 0) { ?>
	<div class="djcat_toolbar" id="tlb">
		<div class="djcat_toolbar_in">
			<div class="djcat_toolbar_filter">
				<form name="djcatalogForm" id="djcatalogForm" method="post" action="index.php">
					<?php if ($this->params->get('show_category_filter') > 0 || $this->params->get('show_producer_filter') > 0 || $this->params->get('show_search') > 0) { ?>
						<ul>
							<li><span><?php echo JText::_('COM_DJCATALOG2_FILTER'); ?></span></li>
							<?php if ($this->params->get('show_category_filter') > 0) { ?>
								<li><?php echo $this->lists['categories'];?></li>
							<?php } ?>
							<?php if ($this->params->get('show_producer_filter') > 0) { ?>
								<li><?php echo $this->lists['producers'];?></li>
							<?php } ?>
						</ul>
					<?php } ?>
					<?php if ($this->params->get('show_search') > 0) { ?>
						<ul>
							<li><span><?php echo JText::_('COM_DJCATALOG2_SEARCH'); ?></span></li>
							<li><input type="text" name="search" id="djcatsearch" value="<?php echo $this->lists['search'];?>" /></li>
							<li><input type="submit" class="button" onclick="document.djcatalogForm.submit();" value="<?php echo JText::_( 'COM_DJCATALOG2_GO' ); ?>" /></li>
							<li><input type="submit" class="button" onclick="document.getElementById('djcatsearch').value='';document.djcatalogForm.submit();" value="<?php echo JText::_( 'COM_DJCATALOG2_RESET' ); ?>" /></li>
						</ul>
					<?php } ?>
				<?php if (!($this->params->get('show_category_filter') > 0)) { ?>
					<input type="hidden" name="cid" value="<?php echo JRequest::getVar('cid'); ?>" />
				<?php } ?>
				<?php if (!($this->params->get('show_producer_filter') > 0)) { ?>
					<input type="hidden" name="pid" value="<?php echo JRequest::getVar('pid'); ?>" />
				<?php } ?>
				<input type="hidden" name="option" value="com_djcatalog2" />
				<input type="hidden" name="view" value="items" />
				<input type="hidden" name="limitstart" value="0" />
				<input type="hidden" name="order" value="<?php echo JRequest::getVar('order','i.ordering'); ?>" />
				<input type="hidden" name="dir" value="<?php echo (JRequest::getVar('dir','asc')); ?>" />
				<input type="hidden" name="task" value="search" />
				<input type="hidden" name="Itemid" value="<?php echo JRequest::getVar('Itemid'); ?>" />
				</form>
			</div>
		</div>
	</div>
	<div class="clear"></div>
	<?php } ?>
	<?php if ($this->params->get('show_category_orderby') > 0 || $this->params->get('show_producer_orderby') > 0 || $this->params->get('show_name_orderby') > 0 || $this->params->get('show_price_orderby') > 0) { ?>
	<div class="djcat_toolbar">
		<?php $orderUrl = DJCatalogHelperRoute::getCategoryRoute(JRequest::getVar('cid',null,'defalut','string'), 'items').'&pid='.JRequest::getVar('pid',null,'defalut','string'); ?>
		<div class="djcat_toolbar_in">
			<div class="djcat_toolbar_order">
					<ul>
						<li><span><?php echo JText::_('COM_DJCATALOG2_ORDERBY'); ?></span></li>
						<?php if ($this->params->get('show_name_orderby') > 0) { ?>
							<li><a href="<?php echo JRoute::_( $orderUrl.'&order=i.name&dir='.$this->lists['order_Dir'].'#tlb'); ?>"><?php echo JText::_('COM_DJCATALOG2_NAME'); ?></a><?php echo $this->_orderDirImage($this->lists['order'], 'i.name', $this->lists['order_Dir']); ?></li>
						<?php } ?>
						<?php if ($this->params->get('show_category_orderby') > 0) { ?>
							<li><a href="<?php echo JRoute::_( $orderUrl.'&order=category&dir='.$this->lists['order_Dir'].'#tlb'); ?>"><?php echo JText::_('COM_DJCATALOG2_CATEGORY'); ?></a><?php echo $this->_orderDirImage($this->lists['order'], 'category', $this->lists['order_Dir']); ?></li>
						<?php } ?>
						<?php if ($this->params->get('show_producer_orderby') > 0) { ?>
							<li><a href="<?php echo JRoute::_( $orderUrl.'&order=producer&dir='.$this->lists['order_Dir'].'#tlb'); ?>"><?php echo JText::_('COM_DJCATALOG2_PRODUCER'); ?></a><?php echo $this->_orderDirImage($this->lists['order'], 'producer', $this->lists['order_Dir']); ?></li>
						<?php } ?>
						<?php if ($this->params->get('show_price_orderby') > 0) { ?>
							<li><a href="<?php echo JRoute::_( $orderUrl.'&order=i.price&dir='.$this->lists['order_Dir'].'#tlb'); ?>"><?php echo JText::_('COM_DJCATALOG2_PRICE'); ?></a><?php echo $this->_orderDirImage($this->lists['order'], 'i.price', $this->lists['order_Dir']); ?></li>
						<?php } ?>
					</ul>
				</div>
		</div>
	</div>
	<div class="clear"></div>
	<?php } ?>
    <div id="djcat_blog">
        <?php
		if (count($this->items) < 1){
			?><p style="text-align: center;"><?php echo JText::_('COM_DJCATALOG2_NO_ITEMS_FOUND');?></p><?php
		} else {
			$k = 0; $i = 1;
	        foreach ($this->items as $item) {
				$newrow_open = $newrow_close = false;
				if ($k % $this->params->get('items_columns',2) == 0) $newrow_open = true;
				if (($k+1) % $this->params->get('items_columns',2) == 0 || count($this->items) <= $k+1) $newrow_close = true;
	        	
				$rowClassName = 'djcat_blog_row';
				if ($k == 0) $rowClassName .= '_first';
				if (count($this->items) <= ($k + $this->params->get('items_columns',2))) $rowClassName .= '_last';
				
				$colClassName ='djcat_blog_col';
				if ($k % $this->params->get('items_columns',2) == 0) { $colClassName .= '_first'; }
				else if (($k+1) % $this->params->get('items_columns',2) == 0) { $colClassName .= '_last'; }
				else {$colClassName .= '_'.($k % $this->params->get('items_columns',2));}
				$k++;
				
				if ($newrow_open) { $i = 1 - $i; ?><div class="<?php echo $rowClassName.'_'.$i; ?>"><?php }
			?>
	        <div class="djcat_blog_item <?php echo $colClassName; ?>" style="width:<?php echo (100/$this->params->get('items_columns',2)-0.1); ?>%">
	        	<div class="djcat_blog_item_bg">
					<div class="djcat_blog_item_in">
		        		<?php if ($item->images = $this->images->getImages($item->image_url)) { ?>
				        	<div class="djcat_blog_image">
				        		<?php if ($this->params->get('image_link_item')) { ?>
									<a rel="lightbox-djitem" title="<?php echo $item->name?>" href="<?php echo $item->images[0]['original']?>"><img alt="<?php echo $item->name; ?>" src="<?php echo $item->images[0]['medium']; ?>"/></a>
								<?php } else { ?>
									<a href="<?php echo JRoute::_(DJCatalogHelperRoute::getItemRoute($item->slug, $item->catslug)); ?>"><img alt="<?php echo $item->name; ?>" src="<?php echo $item->images[0]['medium']; ?>"/></a>
					        	<?php } ?>
				        	</div>
						<?php } ?>
						<div class="djcat_blog_title">
					        <h3><?php
					          echo (JHTML::link(JRoute::_(DJCatalogHelperRoute::getItemRoute($item->slug, $item->catslug)), $item->name));
					        ?></h3>
					    </div>
			            <div class="djcat_blog_text">
							<?php if ($this->params->get('show_category_name') > 0) { ?>
							<div class="djcat_category">
			            		<?php 
								if ($this->params->get('show_category_name') == 2) {
			            			echo JText::_('COM_DJCATALOG2_CATEGORY').': '?><span class="djcat_category"><?php echo $item->category; ?></span> 
								<?php }
								else {
									echo JText::_('COM_DJCATALOG2_CATEGORY').': ';?><a href="<?php echo DJCatalogHelperRoute::getCategoryRoute($item->catslug,'items');?>"><span class="djcat_category"><?php echo $item->category; ?></span></a> 
								<?php } ?>
			            	</div>
							<?php } ?>
							<?php if ($this->params->get('show_producer_name') > 0 && $item->producer) { ?>
							<div class="djcat_producer">
								<?php 
								if ($this->params->get('show_producer_name') == 2) {
			            			echo JText::_('COM_DJCATALOG2_PRODUCER').': '; ?><span class="djcat_producer"><?php echo $item->producer;?></span>
								<?php }
								else if(($this->params->get('show_producer_name') == 3)) {
									echo JText::_('COM_DJCATALOG2_PRODUCER').': ';?><a class="modal" rel="{handler: 'iframe', size: {x: 800, y: 600}}" href="<?php echo JRoute::_(DJCatalogHelperRoute::getProducerRoute($item->prodslug).'&tmpl=component'); ?>"><span class="djcat_producer"><?php echo $item->producer; ?></span></a> 
								<?php }
								else {
									echo JText::_('COM_DJCATALOG2_PRODUCER').': ';?><a href="<?php echo JRoute::_(DJCatalogHelperRoute::getProducerRoute($item->prodslug)); ?>"><span class="djcat_producer"><?php echo $item->producer; ?></span></a> 
								<?php } ?>
			            	</div>
							<?php } ?>
			            	<?php 
								if ($this->params->get('show_price') == 2 || ( $this->params->get('show_price') == 1 && $item->price > 0.0)) { 
									if ($this->params->get('unit_side')==1) $item->price = number_format($item->price, 2, $this->price_decimal_separator, $this->price_thousands_separator).' '.$this->params->get('price_unit');
									else $item->price = $this->params->get('price_unit').' '.number_format($item->price, 2, $this->price_decimal_separator, $this->price_thousands_separator);
							?>
			            	<div class="djcat_price">
			            		<?php echo JText::_('COM_DJCATALOG2_PRICE').': ';?><span class="djcat_price_value"><?php echo $item->price; ?></span>
			            	</div>
							<?php } ?>
							<?php if ($this->params->get('items_show_intro')) {?>
							<div class="djcat_intro_blog">
								<?php if ($this->params->get('items_intro_length') > 0 ) {
										echo DJCatalogHelper::trimText($item->intro_desc, $this->params->get('items_intro_length'));
									}
									else {
										echo $item->intro_desc; 
									}
								?>
							</div>
							<?php } ?>
							<?php if ($this->params->get('showreadmore_item')) { ?>
								<div class="clear"></div>
								<div class="djcat_intro_readmore">
									<a href="<?php echo JRoute::_(DJCatalogHelperRoute::getItemRoute($item->slug, $item->catslug)); ?>" class="readon"><?php echo JText::sprintf('COM_DJCATALOG2_READMORE'); ?></a>
								</div>
							<?php } ?>
			            </div>
			         </div>
				 </div>
				<div class="clear"> </div>
				</div>
				<?php if ($newrow_close) { ?></div><?php } ?>
		        <?php
		        }
			}
	       ?>
		   <div class="clear"></div>
    </div>
    <div class="djcat_blog_pagination">
        <?php
        echo $this->pagination->getPagesLinks();
        ?>
    </div>
	<div class="clearfix clr clear"> </div>
	<?php 
		if ($this->params->get('show_footer')) echo DJCATFOOTER;
	?>
</div>


