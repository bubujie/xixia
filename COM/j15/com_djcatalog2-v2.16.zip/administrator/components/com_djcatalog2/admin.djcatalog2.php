<?php
/**
* @version $Id: admin.djcatalog2.php 8 2011-12-15 10:02:29Z michal $
* @package DJ-Catalog2
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
//error_reporting(E_ALL);

// DJ-Catalog2 version no.
define ('DJCATVERSION', 2.16);

require_once (JPATH_COMPONENT.DS.'controller.php');
require_once(JPATH_COMPONENT.DS.'lib'.DS.'cattree.php');
require_once(JPATH_COMPONENT.DS.'lib'.DS.'image.php');
require_once(JPATH_COMPONENT.DS.'lib'.DS.'file.php');

define('DJCATFOOTER', '<div style="text-align: center; margin: 10px 0;">DJ-Catalog2 (ver. '.DJCATVERSION.'), &copy; 2009-2010 Copyright by <a target="_blank" href="http://design-joomla.eu">design-joomla.eu</a>, All Rights Reserved.<br /><a target="_blank" href="http://design-joomla.eu"><img src="'.JURI::base().'components/com_djcatalog2/images/designjoomla.jpg" alt="design-joomla.eu" style="height: 30px;"/></a></div>');

$controller	= new DJCatalog2Controller( );

$task =  JRequest::getCmd('task');

if($task == 'cpanel' || $task=='') {
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CPANEL'), 'index.php?option=com_djcatalog2&task=cpanel', true);
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CATEGORIES'), 'index.php?option=com_djcatalog2&task=showCategories');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_PRODUCERS'), 'index.php?option=com_djcatalog2&task=showProducers');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_ITEMS'), 'index.php?option=com_djcatalog2&task=showItems');
}
elseif($task == 'showCategories') {
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CPANEL'), 'index.php?option=com_djcatalog2&task=cpanel');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CATEGORIES'), 'index.php?option=com_djcatalog2&task=showCategories', true);
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_PRODUCERS'), 'index.php?option=com_djcatalog2&task=showProducers');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_ITEMS'), 'index.php?option=com_djcatalog2&task=showItems');
}
elseif($task == 'showItems') {
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CPANEL'), 'index.php?option=com_djcatalog2&task=cpanel');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CATEGORIES'), 'index.php?option=com_djcatalog2&task=showCategories');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_PRODUCERS'), 'index.php?option=com_djcatalog2&task=showProducers');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_ITEMS'), 'index.php?option=com_djcatalog2&task=showItems', true);
} 
elseif($task == 'showProducers') {
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CPANEL'), 'index.php?option=com_djcatalog2&task=cpanel');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CATEGORIES'), 'index.php?option=com_djcatalog2&task=showCategories');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_PRODUCERS'), 'index.php?option=com_djcatalog2&task=showProducers',true);
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_ITEMS'), 'index.php?option=com_djcatalog2&task=showItems');
}
else {
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CPANEL'), 'index.php?option=com_djcatalog2&task=cpanel', true);
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_CATEGORIES'), 'index.php?option=com_djcatalog2&task=showCategories');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_PRODUCERS'), 'index.php?option=com_djcatalog2&task=showProducers');
	JSubMenuHelper::addEntry(JText::_('COM_DJCATALOG2_ITEMS'), 'index.php?option=com_djcatalog2&task=showItems');
}

$controller->execute($task);
$controller->redirect();
?>