<?php 
/**
* @version 2.1
* @package DJ-Catalog2
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

defined('_JEXEC') or die('Restricted access'); ?>

<?php JHTML::_('behavior.tooltip'); ?>
<?php $editor =& JFactory::getEditor(); ?>
<?php
	$edit		= JRequest::getVar('edit',true);
	$text = !$edit ? JText::_( 'COM_DJCATALOG2_NEW' ) : JText::_( 'COM_DJCATALOG2_EDIT' );
	JToolBarHelper::title(   JText::_( 'COM_DJCATALOG2_CATEGORY' ).': <small><small>[ ' . $text.' ]</small></small>' );
	JToolBarHelper::save('saveCategory');
	JToolBarHelper::apply();
	if (!$edit)  {
		JToolBarHelper::cancel();
	} else {
		JToolBarHelper::cancel( 'cancel', 'Close' );
	}
?>

<script language="javascript" type="text/javascript">
	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.name.value == ""){
			alert( "<?php echo JText::_( 'COM_DJCATALOG2_CATEGORY_MUST_HAVE_NAME', true ); ?>" );
		} else {
			$('upload_loading').setStyle('display', 'inline');
			$('loader_alert').innerHTML = "<?php echo JText::_('COM_DJCATALOG2_SAVING_PLEASE_WAIT');?>";
			submitform( pressbutton );
		}
	}
</script>
<style type="text/css">
	table.paramlist td.paramlist_key {
		width: 92px;
		text-align: left;
		height: 30px;
	}
</style>

<div style="text-align: center;"><img src="<?php echo JURI::base().'/components/com_djcatalog2/images/long_loader.gif' ?>" alt="LOADING" style="display: none;" id="upload_loading" /><br /><span id="loader_alert"></span></div>
<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col width-100">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_DJCATALOG2_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_NAME' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->item->name;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_ALIAS' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="alias" id="alias" size="32" maxlength="250" value="<?php echo $this->item->alias;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="parent_id">
					<?php echo JText::_( 'COM_DJCATALOG2_PARENT' ); ?>:
				</label>
			</td>
			<td>
				<?php
					echo JHTML::_('select.genericlist', $this->categories, 'parent_id', null, 'id', 'treename', $this->item->parent_id);
				?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				<?php echo JText::_( 'COM_DJCATALOG2_PUBLISHED' ); ?>:
			</td>
			<td>
				<?php echo $this->lists['published']; ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				<label for="ordering">
					<?php echo JText::_( 'COM_DJCATALOG2_ORDERING' ); ?>:
				</label>
			</td>
			<td>
				<?php echo $this->lists['ordering']; ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_DESCRIPTION' ); ?>:
				</label>
			</td>
			<td>
				<?php echo $editor->display( 'description', $this->item->description, '100%', '300', '50', '20',true);?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key"><?php echo JText::_('COM_DJCATALOG2_NOTICE') ?>
			<td>
				<p><?php echo JText::_('COM_DJCATALOG2_ABOUT_PAGEBREAK'); ?></p>
			</td>
		</tr>
		<tr>
			<?php
				$field = new stdClass;
				$field->name = 'image_url';
				$field->value = $this->item->image_url;
				
				$field_controller	= new DJCatalogImage();
				$label = JText::_('COM_DJCATALOG2_IMAGES');
				echo $field_controller->renderInput($field,$label);
			?>
			<input type="hidden" name="image_url" value="<?php echo $this->item->image_url; ?>" />
		</tr>
	</table>
	</fieldset>
</div>

<div class="clr"></div>

	<input type="hidden" name="option" value="com_djcatalog2" />
	<input type="hidden" name="view" value="categories" />
	<input type="hidden" name="cid[]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="task" value="" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>
<?php echo DJCATFOOTER; ?>