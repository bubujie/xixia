<?php 
/**
* @version 2.1
* @package DJ-Catalog2
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

defined('_JEXEC') or die('Restricted access'); ?>

<?php JHTML::_('behavior.tooltip'); ?>
<?php $editor =& JFactory::getEditor(); ?>

<?php
	$edit		= JRequest::getVar('edit',true);
	$text = !$edit ? JText::_( 'COM_DJCATALOG2_NEW' ) : JText::_( 'COM_DJCATALOG2_EDIT' );
	JToolBarHelper::title(   JText::_( 'COM_DJCATALOG2_ITEM' ).': <small><small>[ ' . $text.' ]</small></small>' );
	JToolBarHelper::save('saveItem');
	JToolBarHelper::apply();
	if (!$edit)  {
		JToolBarHelper::cancel();
	} else {
		JToolBarHelper::cancel( 'cancel', 'Close' );
	}
?>

<script language="javascript" type="text/javascript">
	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.name.value == ""){
			alert( "<?php echo JText::_( 'COM_DJCATALOG2_ITEM_MUST_HAVE_NAME', true ); ?>" );
		} else if (form.cat_id.value == "" || form.cat_id.value == "0") {
			alert( "<?php echo JText::_( 'COM_DJCATALOG2_ITEM_MUST_HAVE_CATEGORY', true ); ?>" );
		}else {
			$('upload_loading').setStyle('display', 'inline');
			$('loader_alert').innerHTML = "<?php echo JText::_('COM_DJCATALOG2_SAVING_PLEASE_WAIT');?>";
			document.adminForm.price.value = Math.round(document.adminForm.price.value * Math.pow(10, 2)) / Math.pow(10, 2);
			submitform( pressbutton );
		}
	}
	function validatePrice() {
	if( document.adminForm.price.value != '' ) {
		var r = new RegExp("\,", "i");
		var t = new RegExp("[^0-9\,\.]+", "i");
		document.adminForm.price.value = document.adminForm.price.value.replace( r, "." );
		document.adminForm.price.value = document.adminForm.price.value.replace( t, "" );
	}
}
</script>
<style type="text/css">
	table.paramlist td.paramlist_key {
		width: 92px;
		text-align: left;
		height: 30px;
	}
</style>
<div style="text-align: center;"><img src="<?php echo JURI::base().'/components/com_djcatalog2/images/long_loader.gif' ?>" alt="LOADING" style="display: none;" id="upload_loading" /><br /><span id="loader_alert"></span></div>
<form action="index.php" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col width-70">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_DJCATALOG2_DETAILS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_NAME' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="name" id="name" size="32" maxlength="250" value="<?php echo $this->item->name;?>" />
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_ALIAS' ); ?>:
				</label>
			</td>
			<td>
				<input class="text_area" type="text" name="alias" id="alias" size="32" maxlength="250" value="<?php echo $this->item->alias;?>" />
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				<?php echo JText::_( 'COM_DJCATALOG2_PUBLISHED' ); ?>:
			</td>
			<td>
				<?php echo $this->lists['published']; ?>
			</td>
		</tr>
		<tr>
			<td valign="top" align="right" class="key">
				<label for="ordering">
					<?php echo JText::_( 'COM_DJCATALOG2_ORDERING' ); ?>:
				</label>
			</td>
			<td>
				<?php echo $this->lists['ordering']; ?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="cat_id">
					<?php echo JText::_( 'COM_DJCATALOG2_CATEGORY' ); ?>:
				</label>
			</td>
			<td>
				<?php
					echo $this->categories;
				?>
			</td>
		</tr>
		<tr>
            <td width="100" align="right" class="key">
                <?php echo JText::_('COM_DJCATALOG2_PRODUCER');?>
            </td>
            <td>
                <?php
						$options = array();
						$options[] = JHTML::_('select.option', 0,JText::_('COM_DJCATALOG2_SELECT_PRODUCER') );
						foreach($this->producers as $producer){
							$options[] = JHTML::_('select.option', $producer->id, $producer->name);
							
						}
						echo JHTML::_('select.genericlist', $options, 'producer_id', null, 'value', 'text', $this->item->producer_id);
					?>
            </td>
        </tr>
		<tr>
            <td width="100" align="right" class="key">
                <?php echo JText::_('COM_DJCATALOG2_PRICE');?>
            </td>
            <td>
                <input class="text_area" type="text" name="price" id="price" size="32" maxlength="250" value="<?php echo $this->item->price;?>" onkeyup="validatePrice();"/>
            </td>
        </tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_INTRO_DESCRIPTION' ); ?>:
				</label>
			</td>
			<td>
				<?php echo $editor->display( 'intro_desc', $this->item->intro_desc, '100%', '300', '50', '20',false);?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key">
				<label for="title">
					<?php echo JText::_( 'COM_DJCATALOG2_DESCRIPTION' ); ?>:
				</label>
			</td>
			<td>
				<?php echo $editor->display( 'description', $this->item->description, '100%', '300', '50', '20',true);?>
			</td>
		</tr>
		<tr>
			<td width="100" align="right" class="key"><?php echo JText::_('COM_DJCATALOG2_NOTICE') ?>
			<td>
				<p><?php echo JText::_('COM_DJCATALOG2_ABOUT_PAGEBREAK'); ?></p>
			</td>
		</tr>
		<tr>
			<?php
				$field = new stdClass;
				$field->name = 'image_url';
				$field->value = $this->item->image_url;
				
				$field_controller	= new DJCatalogImage();
				$label = JText::_('COM_DJCATALOG2_IMAGES');
				echo $field_controller->renderInput($field,$label);
			?>
			<input type="hidden" name="image_url" value="<?php echo $this->item->image_url; ?>" />
		</tr>
		<tr>
			<?php
				$field = new stdClass;
				$field->name = 'files_url';
				$field->value = $this->item->files_url;
				
				$field_controller	= new DJCatalogFile();
				$label = JText::_('COM_DJCATALOG2_FILES');
				echo $field_controller->renderInput($field,$label);
			?>
			<input type="hidden" name="files_url" value="<?php echo $this->item->files_url; ?>" />
		</tr>
	</table>
	</fieldset>
</div>
<div class="col width-30">
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_DJCATALOG2_PARAMETERS' ); ?></legend>

		<table class="admintable">
		<tr>
			<td colspan="2">
				<?php if ($this->params)
					echo $this->params->render();?>
			</td>
		</tr>
		</table>
	</fieldset>
	<fieldset class="adminform">
		<legend><?php echo JText::_( 'COM_DJCATALOG2_META_DATA' ); ?></legend>

		<table class="admintable">
		<tr>
			<td width="30%"  class="key">
				<?php echo JText::_('COM_DJCATALOG2_META_KEY'); ?>
			</td>
			<td>
				<textarea name="metakey" id="metakey" rows="5" cols="30"><?php echo $this->item->metakey; ?></textarea>
			</td>
		</tr>
		<tr>
			<td width="30%"  class="key">
				<?php echo JText::_('COM_DJCATALOG2_META_DESCRIPTION'); ?>
			</td>
			<td>
				<textarea name="metadesc" id="metadesc" rows="5" cols="30"><?php echo $this->item->metadesc; ?></textarea>
			</td>
		</tr>
		</table>
	</fieldset>
</div>

<div class="clr"></div>

	<input type="hidden" name="option" value="com_djcatalog2" />
	<input type="hidden" name="view" value="items" />
	<input type="hidden" name="cid[]" value="<?php echo $this->item->id; ?>" />
	<input type="hidden" name="task" value="" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>
<?php echo DJCATFOOTER; ?>