CREATE TABLE IF NOT EXISTS `#__djc2_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `image_url` text,
  `parent_id` int(11) NOT NULL,
  `published` int(11) NOT NULL default '1',
  `ordering` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__djc2_items` (
  `id` int(11) NOT NULL auto_increment,
  `cat_id` int(11) NOT NULL default '0',
  `producer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `intro_desc` text,
  `price` decimal(12,2) default NULL,
  `image_url` text,
  `files_url` text,
  `metakey` text,
  `metadesc` text,
  `published` int(11) NOT NULL default '1',
  `ordering` int(11) NOT NULL default '0',
  `params` text,
  PRIMARY KEY  (`id`)
) DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__djc2_producers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `image_url` text,
  `published` int(11) NOT NULL default '0',
  `ordering` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) DEFAULT CHARSET=utf8;