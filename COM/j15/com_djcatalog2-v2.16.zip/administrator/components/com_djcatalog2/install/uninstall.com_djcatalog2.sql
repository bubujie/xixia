DROP TABLE IF EXISTS `#__djc2_items`;
DROP TABLE IF EXISTS `#__djc2_categories`;
DROP TABLE IF EXISTS `#__djc2_producers`;

