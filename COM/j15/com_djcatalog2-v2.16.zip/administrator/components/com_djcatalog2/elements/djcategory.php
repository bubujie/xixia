<?php 
/**
* @version 2.1
* @package DJ-Catalog2
* @copyright Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.
* @license http://www.gnu.org/licenses GNU/GPL
* @author url: http://design-joomla.eu
* @author email contact@design-joomla.eu
* @developer Michal Olczyk - michal.olczyk@design-joomla.eu
*
*
* DJ-Catalog2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* DJ-Catalog2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with DJ-Catalog2. If not, see <http://www.gnu.org/licenses/>.
*
*/

require_once(dirname(__FILE__).DS.'..'.DS.'lib'.DS.'cattree.php');

class JElementDjcategory extends JElement {
	function fetchElement($name, $value, &$node, $control_name)
	{
		$class		= $node->attributes('class');
		
		if (!$class) {
			$class = "inputbox";
		}
		
		$db = &JFactory::getDBO();
	
		$query = "SELECT * FROM #__djc2_categories ORDER BY parent_id";
		$db->setQuery($query);
		$categories = $db->loadObjectList();
	
		$tree = new CatTree();
        $tree->buildTree($categories);
        $root = & $tree->getRoot();

		$options = renderOptionList($root);
		$list = JHTML::_('select.genericlist', $options, $control_name.'['.$name.']', null, 'value', 'text', $value);
		return $list;
	}
}
?>