<?php
/**
 * @version 1.0 $Id: flexicontent_types.php 1694 2013-07-12 09:42:03Z ggppdk $
 * @package Joomla
 * @subpackage FLEXIcontent
 * @copyright (C) 2009 Emmanuel Danan - www.vistamedia.fr
 * @license GNU/GPL v2
 * 
 * FLEXIcontent is a derivative work of the excellent QuickFAQ component
 * @copyright (C) 2008 Christoph Lukes
 * see www.schlu.net for more information
 *
 * FLEXIcontent is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

defined('_JEXEC') or die('Restricted access');

if (FLEXI_J16GE) {
	jimport('joomla.database.tableasset');
	jimport('joomla.access.accessrules');
}
/**
 * FLEXIcontent table class
 *
 * @package Joomla
 * @subpackage FLEXIcontent
 * @since 1.0
 */
class flexicontent_types extends JTable
{
	/** @var int */
	var $id 					= null;
	/** @var string */
	var $name					= '';
	/** @var string */
	var $alias				= '';
	/** @var int */
	var $published			= null;
	/** @var int */
	var $itemscreatable	= 0;
	/** @var int */
	var $checked_out		= 0;
	/** @var date */
	var $checked_out_time	= '';
	/** @var int */
	var $access 			= 0;
	/** @var string */
	var $attribs	 		= null;

	function flexicontent_types(& $db) {
		parent::__construct('#__flexicontent_types', 'id', $db);
	}
	
	// overloaded check function
	function check()
	{
		// Not typed in a name?
		if (trim( $this->name ) == '') {
			$this->_error = JText::_( 'FLEXI_ADD_NAME' );
			JError::raiseWarning('SOME_ERROR_CODE', $this->_error );
			return false;
		}
		
		$alias = JFilterOutput::stringURLSafe($this->name);

		if(empty($this->alias) || $this->alias === $alias ) {
			$this->alias = $alias;
		}
		
		/** check for existing name */
		$query = 'SELECT id'
				.' FROM #__flexicontent_types'
				.' WHERE name = '.$this->_db->Quote($this->name)
				;
		$this->_db->setQuery($query);

		$xid = intval($this->_db->loadResult());
		if ($xid && $xid != intval($this->id)) {
			JError::raiseWarning('SOME_ERROR_CODE', JText::sprintf('FLEXI_TYPE_NAME_ALREADY_EXIST', $this->name));
			return false;
		}
	
		return true;
	}
}
?>