DROP TABLE  `#__spidercatalog_params`;
DROP TABLE  `#__spidercatalog_products` ;DROP TABLE  `#__spidercatalog_product_categories` ;
DROP TABLE  `#__spidercatalog_product_reviews` ;DROP TABLE  `#__spidercatalog_product_votes` ;DROP TABLE  `#__spidercatalog_id` ;