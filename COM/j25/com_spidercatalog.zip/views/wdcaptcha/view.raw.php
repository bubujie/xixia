<?php

/**
 * @package Spider Contacts
 * @author Web-Dorado
 * @copyright (C) 2012 Web-Dorado. All rights reserved.
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 **/

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class spidercatalogViewwdcaptcha extends JView



{



    function display($tpl = null)



    {

		

  

        parent::display($tpl);

    }

}

?>